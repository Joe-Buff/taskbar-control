# Changelog

## 1.10

- Refreshed interface with a collapsible sidebar and refined light/dark themes.
- Actual app icons and scrollbars that match the selected theme.
- Complete app rows while scrolling and resizing; corrected collapsed-sidebar clipping.
- Latest-error preview, plain-language explanations, diagnostic codes, and full reports in Activity.
- Manual GitHub update checks with installation confirmation and saved-setting preservation.

## 1.0

First public release.
