TASKBAR CONTROL - QUICK GUIDE

Choose which running apps appear on your taskbar. Hidden apps stay open,
keep their existing tray icons, and remain accessible through Alt+Tab on
supported Windows taskbar builds.

QUICK START
1. Open Taskbar Control from its EXE, desktop, or Start menu shortcut.
2. Choose Pick a window, then click the app whose taskbar button you want
   to hide. Escape cancels. The click is not sent to the selected app.
3. Turn its Show switch ON whenever you want its taskbar button back.

SIDEBAR
Apps: your visibility rules and quick controls.
Folders: optional tools for finding executables inside chosen folders.
Activity: recent errors explained in plain language, plus diagnostics.
Settings: theme, startup, Taskbar Control's own icon, and manual updates.
Collapse: reduce the sidebar to icons. Press the menu icon to expand it.

APPS PAGE - ADDING APPS
Pick a window: choose an open window. Its taskbar button hides immediately.
Add executable: browse to one or more .exe files. These start with Show ON.
Add running apps: add recognized open apps; existing choices are preserved.
Adding an executable does not open or close the app.

APP LIST CONTROLS
Show ON: show the app's taskbar button. Show OFF: hide the button.
The switch does not close the app or prevent it from launching.
Real executable icons are shown when readable; a simple window outline
is used when an icon is unavailable. There are no letter placeholders.

Search: filter by app name, executable path, or app identity.
Only hidden apps: show only rules with Show OFF.
Remove selected: remove rules and restore buttons; no programs are deleted.
Show all apps: turn every Show switch ON while retaining your app list.
Pause hiding: temporarily restore buttons without forgetting your choices.
Turn Pause hiding OFF to reapply the hidden rules.

The three summary cards count saved rules, including apps not running.
The bottom status reports how many taskbar buttons are actually hidden.

FOLDERS PAGE
Add folder: scan that folder and subfolders for executables. New entries
start with Show ON. Useful for a collection of portable apps; large folders
may also add installers and helper executables.
Saved folders: view or remove scan locations. Removing a folder does not
remove app rules already discovered inside it.
Rescan folders: find newly added executables while preserving your rules.
Cancel scan stops an ongoing scan. There is no continuous folder scanning.

SETTINGS
Dark theme / Light theme: choose the appearance. Your choice saves locally.
Start with Windows: open quietly in the tray when you sign in. The same
choice is available during installation.
Hide my taskbar icon: hide Taskbar Control's own button while retaining tray
access. This separate setting may also hide Taskbar Control from Alt+Tab.

MANUAL UPDATES
Open Settings > Check for updates. No checks happen at startup, on a timer,
or while the app sits in the tray. A failed check displays an error.
If a newer stable release is available, choose Download and install, Not
now, or Release notes. Downloading starts only after your confirmation.
The installer is verified against GitHub's SHA-256 checksum and file size.
A release without a verifiable installer is not installed automatically.

Setup replaces the app in its current folder. In update mode it keeps your
shortcut/startup choices and does not rewrite your settings file. It asks
the running app to exit normally and restores hidden buttons before
replacing the EXE. Finish setup to reopen Taskbar Control.
Canceling a check or download leaves the installed app unchanged.
Official releases: https://github.com/Joe-Buff/taskbar-control/releases

ACTIVITY AND DIAGNOSTICS
The bottom-right Error Log shows the latest error in plain language.
Click its message, or choose Activity in the sidebar, for the full log
and suggested next steps. No errors to report means the log is empty.
Each error has a diagnostic code, such as AE0001 for a missing app/file
or AE0002 for access denied. Include that code when asking for help.
Copy details includes those codes, original Windows error details, the
app version, and Windows version. Consecutive identical errors are counted
together. The log keeps up to 50 entries in memory and clears on exit.
Clear log empties both the full log and the preview without changing rules.
Save diagnostics opens a detailed local report and Reconnect taskbar tool.
Review any report before sharing it. A small dot on Activity indicates an
error was recorded.

Unsupported Windows taskbar builds leave affected buttons visible instead
of switching to a hiding method that removes them from Alt+Tab.

WINDOW AND TRAY
Minimize or Close: put the window in the tray and keep rules active.
Open the shortcut/EXE again or double-click the tray icon to reopen the
existing window. A second running copy is not created.
To exit completely: use Exit and restore taskbar buttons in the tray menu.

UNINSTALLING
Run Uninstaller.exe or Uninstall Taskbar Control in the installation folder,
or use Windows Settings > Apps > Installed apps. A Start menu uninstall
shortcut is also included if you selected Start menu shortcuts in setup.
The uninstaller closes the app normally and restores taskbar buttons. It
removes installed files, shortcuts, and its matching startup entry. It
preserves saved rules and unrelated files in the installation folder.

SAVED SETTINGS
%LOCALAPPDATA%\TaskbarControl\settings.json
Updates and reinstallations preserve this file. Customer downloads contain
no saved personal rules. See PRIVACY.md and Estimated System Resource Use.txt
for privacy and performance details.
