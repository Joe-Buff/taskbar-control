using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

// A message-only window survives MainForm handle recreation (ShowInTaskbar).
// It uses the UI message loop: no listener thread or idle polling is needed.
internal sealed class InstanceActivation : NativeWindow, IDisposable
{
    const int ActivateMessage=0x8000+117;
    const int ExitMessage=0x8000+118;
    static readonly IntPtr MessageParent=new IntPtr(-3);
    Action activate;
    Action exit;
    bool pending;
    [DllImport("user32.dll")] static extern bool PostMessage(IntPtr window,int message,IntPtr w,IntPtr l);
    [DllImport("user32.dll")] static extern bool AllowSetForegroundWindow(uint pid);
    [DllImport("user32.dll")] static extern bool ChangeWindowMessageFilterEx(IntPtr window,uint message,uint action,IntPtr change);
    [DllImport("user32.dll")] internal static extern bool SetForegroundWindow(IntPtr window);
    [DllImport("user32.dll")] static extern IntPtr GetLastActivePopup(IntPtr window);
    internal InstanceActivation(string name)
    {
        CreateHandle(new CreateParams{Caption=name+".Activation",Parent=MessageParent});
        // This one data-free request is safe from an unelevated shortcut too.
        ChangeWindowMessageFilterEx(Handle,ActivateMessage,1,IntPtr.Zero);
    }
    internal void Ready(Action action,Action exitAction=null)
    {
        activate=action;exit=exitAction;
        if(pending){pending=false;activate();}
    }
    protected override void WndProc(ref Message message)
    {
        if(message.Msg==ActivateMessage)
        {
            if(activate==null)pending=true;else activate();
            message.Result=new IntPtr(1);return;
        }
        if(message.Msg==ExitMessage&&exit!=null){exit();message.Result=new IntPtr(1);return;}
        base.WndProc(ref message);
    }
    internal static bool Request(string name,bool startInTray)
    {
        if(startInTray)return true; // A second sign-in launch must not open the UI.
        var wait=Stopwatch.StartNew();
        do
        {
            var window=Native.FindWindowEx(MessageParent,IntPtr.Zero,null,name+".Activation");
            if(window!=IntPtr.Zero)
            {
                uint pid;Native.GetWindowThreadProcessId(window,out pid);
                if(pid!=0)AllowSetForegroundWindow(pid);
                if(PostMessage(window,ActivateMessage,IntPtr.Zero,IntPtr.Zero))return true;
            }
            Thread.Sleep(50); // Only the short-lived second process waits for startup.
        }while(wait.ElapsedMilliseconds<5000);
        return false;
    }
    internal static void RequestExit(string name)
    {
        var window=Native.FindWindowEx(MessageParent,IntPtr.Zero,null,name+".Activation");
        if(window!=IntPtr.Zero)PostMessage(window,ExitMessage,IntPtr.Zero,IntPtr.Zero);
    }
    internal static void Focus(Form form)
    {
        IntPtr window=form.Handle;
        // Keep an open file picker or other owned dialog in front of its owner.
        for(int i=0;i<16;i++)
        {
            IntPtr popup=GetLastActivePopup(window);
            if(popup==window||popup==IntPtr.Zero||!Native.IsWindowVisible(popup))break;
            window=popup;
        }
        var target=Control.FromHandle(window) as Form;
        if(target!=null)target.Activate();
        SetForegroundWindow(window);
    }
    public void Dispose(){activate=null;DestroyHandle();}
}
