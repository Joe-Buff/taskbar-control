using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

namespace TaskbarStyling
{
    internal static class Theme
    {
        static readonly string bodyFamily=FontFamily.Families.Any(f=>f.Name=="Segoe UI Variable Text")?"Segoe UI Variable Text":"Segoe UI";
        static readonly string headingFamily=FontFamily.Families.Any(f=>f.Name=="Segoe UI Variable Display")?"Segoe UI Variable Display":"Segoe UI";
        static readonly string mediumFamily=FontFamily.Families.Any(f=>f.Name=="Segoe UI Variable Text Semibold")?"Segoe UI Variable Text Semibold":"Segoe UI Semibold";
        internal static Font Body(float size){return new Font(bodyFamily,size,FontStyle.Regular);}
        internal static Font Medium(float size){return new Font(mediumFamily,size,FontStyle.Regular);}
        internal static Font Heading(float size){return new Font(headingFamily,size,FontStyle.Bold);}
        internal static bool Light;
        internal static Color Background {get{return Light?Color.FromArgb(245,245,247):Color.FromArgb(12,12,12);}}
        internal static Color Surface {get{return Light?Color.White:Color.FromArgb(22,22,22);}}
        internal static Color AppRow {get{return Light?Color.FromArgb(252,252,253):Color.FromArgb(29,29,29);}}
        internal static Color Text {get{return Light?Color.FromArgb(25,25,25):Color.FromArgb(242,242,242);}}
        internal static Color Muted {get{return Light?Color.FromArgb(73,73,73):Color.FromArgb(165,165,165);}}
        internal static Color Button {get{return Light?Color.White:Color.FromArgb(33,33,33);}}
        internal static Color Hover {get{return Light?Color.FromArgb(244,244,247):Color.FromArgb(43,43,43);}}
        internal static Color Selected {get{return Light?Color.FromArgb(238,238,243):Color.FromArgb(39,39,39);}}
        internal static Color CardEdge {get{return Light?Color.FromArgb(30,30,30):Color.FromArgb(52,52,52);}}
        [DllImport("dwmapi.dll")]static extern int DwmSetWindowAttribute(IntPtr h,int key,ref int val,int size);
        internal static void Frame(IntPtr handle){int dark=Light?0:1,round=2;DwmSetWindowAttribute(handle,20,ref dark,4);DwmSetWindowAttribute(handle,33,ref round,4);}
        internal static void Paint(Control c)
        {
            c.ForeColor=Text;
            if(c is TextBox||c is ComboBox||c is ListBox||c is NumericUpDown)c.BackColor=Surface;else if(c is SoftCard)c.BackColor=Background;else c.BackColor=c.Parent is SoftCard?Surface:c.Parent==null?Background:c.Parent.BackColor;
            foreach(Control child in c.Controls)Paint(child);
            var field=c as ModernTextField;if(field!=null)field.ApplyTheme();
            c.Invalidate();
        }
    }
    internal sealed class FlatButton:Button
    {
        bool hover;
        internal bool Primary;
        internal bool Navigation=false;
        internal FlatButton(){Font=Theme.Medium(9.75f);FlatStyle=FlatStyle.Flat;FlatAppearance.BorderSize=0;UseVisualStyleBackColor=false;AutoSize=true;MinimumSize=new Size(0,34);Margin=new Padding(0,0,8,0);SetStyle(ControlStyles.UserPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.AllPaintingInWmPaint|ControlStyles.ResizeRedraw,true);}
        public override Size GetPreferredSize(Size size){return new Size(TextRenderer.MeasureText(Text,Font).Width+28,36);}
        protected override void OnMouseEnter(EventArgs e){hover=true;Invalidate();base.OnMouseEnter(e);}
        protected override void OnMouseLeave(EventArgs e){hover=false;Invalidate();base.OnMouseLeave(e);}
        protected override void OnPaint(PaintEventArgs e)
        {
            using(var background=new SolidBrush(Parent==null?Theme.Background:Parent.BackColor))e.Graphics.FillRectangle(background,ClientRectangle);e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;var r=new Rectangle(1,1,Width-3,Height-3);
            bool solid=Primary&&Enabled&&!Navigation&&!Theme.Light;
            using(var p=ModernPaint.Round(r,10)){using(var b=new SolidBrush(solid?ModernPaint.Accent:hover?Theme.Hover:Primary?Theme.Selected:Theme.Button))e.Graphics.FillPath(b,p);if(Focused||Theme.Light&&!solid)using(var pen=new Pen(Focused?ModernPaint.Accent:ModernPaint.Edge,Theme.Light?(Primary||Focused?2f:1.5f):1f))e.Graphics.DrawPath(pen,p);}
            TextRenderer.DrawText(e.Graphics,Text,Font,ClientRectangle,Enabled?(solid?ModernPaint.OnAccent:Theme.Text):Theme.Muted,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.NoPrefix);
        }
    }
}
