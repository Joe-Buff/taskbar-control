using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

internal sealed class WindowTarget
{
    internal IntPtr Window;
    internal uint OwnerPid;
    internal string Path, AppId, Name;
    internal string Key { get { return String.IsNullOrEmpty(AppId) ? "exe:" + Path : "app:" + AppId; } }
    internal bool SameWindowApp(WindowTarget other)
    { return other != null && OwnerPid == other.OwnerPid && String.Equals(Key, other.Key, StringComparison.OrdinalIgnoreCase); }
}
internal sealed class ProcessIdentity
{
    internal uint Pid;
    internal string Path, AppId;
    internal string Key { get { return String.IsNullOrEmpty(AppId) ? "exe:" + Path : "app:" + AppId; } }
}
internal static class WindowIdentity
{
    [DllImport("user32.dll")] static extern bool EnumChildWindows(IntPtr window, Native.EnumProc callback, IntPtr data);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr window, StringBuilder text, int count);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] static extern int GetApplicationUserModelId(IntPtr process, ref uint length, StringBuilder text);
    [DllImport("shell32.dll")] static extern int SHGetPropertyStoreForWindow(IntPtr window, ref Guid iid, out IPropertyStore store);
    [DllImport("ole32.dll")] static extern int PropVariantClear(ref PropertyValue value);
    [StructLayout(LayoutKind.Sequential)] internal struct PropertyKey { internal Guid Format; internal uint Id; }
    [StructLayout(LayoutKind.Explicit, Size=24)] internal struct PropertyValue
    { [FieldOffset(0)] internal ushort Type; [FieldOffset(8)] internal IntPtr Pointer; }
    [ComImport, Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IPropertyStore
    {
        [PreserveSig] int GetCount(out uint count);
        [PreserveSig] int GetAt(uint index, out PropertyKey key);
        [PreserveSig] int GetValue(ref PropertyKey key, out PropertyValue value);
        [PreserveSig] int SetValue(ref PropertyKey key, ref PropertyValue value);
        [PreserveSig] int Commit();
    }
    internal static bool SharedHost(string path)
    { return !String.IsNullOrEmpty(path) && String.Equals(System.IO.Path.GetFileName(path), "ApplicationFrameHost.exe", StringComparison.OrdinalIgnoreCase); }
    internal static string WindowClass(IntPtr window)
    { var name=new StringBuilder(256); Native.GetClassName(window,name,name.Capacity); return name.ToString(); }
    internal static ProcessIdentity Process(uint pid, Dictionary<uint,ProcessIdentity> cache)
    {
        ProcessIdentity info;
        if(cache!=null && cache.TryGetValue(pid,out info))return info;
        info=new ProcessIdentity{Pid=pid,Path=Native.ProcessPath(pid)};
        IntPtr handle=Native.OpenProcess(0x1000,false,pid);
        if(handle!=IntPtr.Zero)
        {
            try
            {
                uint length=0;
                if(GetApplicationUserModelId(handle,ref length,null)==122 && length>1 && length<=4096)
                { var text=new StringBuilder((int)length); if(GetApplicationUserModelId(handle,ref length,text)==0)info.AppId=text.ToString(); }
            }
            catch(EntryPointNotFoundException) { }
            finally { Native.CloseHandle(handle); }
        }
        if(cache!=null)cache[pid]=info; return info;
    }
    internal static string WindowAppId(IntPtr window)
    {
        IPropertyStore store=null; var value=new PropertyValue();
        try
        {
            var iid=typeof(IPropertyStore).GUID;
            if(SHGetPropertyStoreForWindow(window,ref iid,out store)!=0 || store==null)return null;
            var key=new PropertyKey{Format=new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3"),Id=5};
            if(store.GetValue(ref key,out value)==0 && value.Type==31 && value.Pointer!=IntPtr.Zero)return Marshal.PtrToStringUni(value.Pointer);
            return null;
        }
        catch(COMException){return null;}
        finally { PropVariantClear(ref value); if(store!=null)Marshal.ReleaseComObject(store); }
    }
    // Never select the first unrelated child: an ambiguous host must not create
    // a rule covering every app that happens to share its Windows host process.
    internal static ProcessIdentity ChooseChild(IEnumerable<ProcessIdentity> children, string appId)
    {
        var choices=children.Where(p=>p!=null && !SharedHost(p.Path) && (!String.IsNullOrEmpty(p.Path)||!String.IsNullOrEmpty(p.AppId))).GroupBy(p=>p.Key,StringComparer.OrdinalIgnoreCase).Select(g=>g.First()).ToList();
        if(!String.IsNullOrEmpty(appId))
        { var matching=choices.Where(p=>String.Equals(p.AppId,appId,StringComparison.OrdinalIgnoreCase)).ToList(); if(matching.Count==1)return matching[0]; }
        return choices.Count==1 ? choices[0] : null;
    }
    internal static WindowTarget Resolve(IntPtr window, Dictionary<uint,ProcessIdentity> cache=null)
    {
        if(window==IntPtr.Zero || !Native.IsWindow(window))return null;
        window=Native.GetAncestor(window,2); string name=WindowClass(window);
        if(new[]{"Shell_TrayWnd","Shell_SecondaryTrayWnd","Progman","WorkerW"}.Contains(name))return null;
        uint owner; Native.GetWindowThreadProcessId(window,out owner);
        var info=Process(owner,cache); string appId=info.AppId;
        bool hosted=name=="ApplicationFrameWindow" || SharedHost(info.Path);
        if(hosted)
        {
            appId=WindowAppId(window);
            var children=new List<ProcessIdentity>(); var core=new List<ProcessIdentity>();
            EnumChildWindows(window,delegate(IntPtr child,IntPtr unused)
            {
                uint pid; Native.GetWindowThreadProcessId(child,out pid);
                if(pid!=0 && pid!=owner)
                { var candidate=Process(pid,cache); children.Add(candidate); if(WindowClass(child)=="Windows.UI.Core.CoreWindow")core.Add(candidate); }
                return true;
            },IntPtr.Zero);
            info=core.Count>0?ChooseChild(core,appId):ChooseChild(children,appId);
            if(info==null && String.IsNullOrEmpty(appId))return null;
            if(String.IsNullOrEmpty(appId) && info!=null)appId=info.AppId;
        }
        string path=info==null?null:info.Path;
        if(String.IsNullOrEmpty(path) && String.IsNullOrEmpty(appId))return null;
        if(SharedHost(path))return null;
        string label=String.IsNullOrEmpty(path)?appId:System.IO.Path.GetFileName(path);
        if(hosted || !String.IsNullOrEmpty(appId))
        { var title=new StringBuilder(256); if(GetWindowText(window,title,title.Capacity)>0)label=title.ToString(); }
        return new WindowTarget{Window=window,OwnerPid=owner,Path=path??"",AppId=appId,Name=label};
    }
}
