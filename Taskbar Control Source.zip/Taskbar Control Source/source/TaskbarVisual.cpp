#include <windows.h>
#include <dbghelp.h>
#include <tlhelp32.h>
#include <atomic>
#include <map>
#include <set>
#include <string>
#include <vector>
#undef GetCurrentTime
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.UI.Xaml.h>
#include <winrt/Windows.UI.Xaml.Media.h>
#include <winrt/Windows.UI.Xaml.Automation.h>
using namespace winrt::Windows::UI::Xaml;

// IPC: uint magic, uint version, ulong heartbeat, uint length, uint reserved,
// uint built-in helperStatus, uint hiddenButtons, ulong built-in helperHeartbeat,
// then UTF-16, newline-delimited exact shell application IDs (maximum 60 KiB).
// Access is protected by a session-local named mutex. A dead publisher never
// leaves persistent visibility rules behind.
#ifdef TC_VISUAL_TEST
constexpr wchar_t MapName[]=L"Local\\TaskbarControl.VisualRules.Standalone.v2.NativeSelfTest";
constexpr wchar_t MutexName[]=L"Local\\TaskbarControl.VisualRules.Standalone.Lock.v2.NativeSelfTest";
#else
constexpr wchar_t MapName[]=L"Local\\TaskbarControl.VisualRules.Standalone.v2";
constexpr wchar_t MutexName[]=L"Local\\TaskbarControl.VisualRules.Standalone.Lock.v2";
#endif
constexpr size_t MapBytes=65536;
HANDLE ruleMap=nullptr, ruleMutex=nullptr;
BYTE* shared=nullptr;
std::atomic<bool> unloading=false;
std::set<std::wstring> wanted;
bool applying=false;
std::atomic<bool> cleanupComplete=false;
ULONGLONG lastRead=0;
UINT_PTR timerId=0;
void *primaryVtable=nullptr, *secondaryVtable=nullptr, *heightCode=nullptr;
using HostFn=void*(WINAPI*)(void*,void**);
HostFn primaryHost=nullptr,secondaryHost=nullptr;
using ReleaseFn=void(WINAPI*)(void*);
ReleaseFn releaseShared=nullptr;
size_t hostOffset=0;
HMODULE helperModule=nullptr;
bool pinned=false;

struct Button {
    winrt::weak_ref<FrameworkElement> element;
    winrt::Windows::Foundation::IInspectable previous{nullptr};
    bool changed=false;
    int64_t identityToken=0;
};
// All XAML state and these containers are accessed only from Explorer's UI thread.
std::map<void*,Button> buttons;

void Restore(Button& record, FrameworkElement const& element) {
    if (!record.changed) return;
    // Restore the local value (or clear our override), preserving style bindings.
    if (element.Visibility()==Visibility::Collapsed) {
        if (record.previous==DependencyProperty::UnsetValue())
            element.ClearValue(UIElement::VisibilityProperty());
        else element.SetValue(UIElement::VisibilityProperty(),record.previous);
    }
    record.changed=false;
    record.previous=nullptr;
}
bool IdentityMatches(std::wstring_view id) {
    constexpr std::wstring_view prefix=L"Appid: ";
    return id.starts_with(prefix) && wanted.contains(std::wstring(id.substr(prefix.size())));
}
bool Match(FrameworkElement const& element) {
    return IdentityMatches(Automation::AutomationProperties::GetAutomationId(element));
}
void Apply(Button& record, FrameworkElement const& element) {
    if (!unloading && Match(element)) {
        if (!record.changed) {
            record.previous=element.ReadLocalValue(UIElement::VisibilityProperty());
            record.changed=true;
        }
        element.Visibility(Visibility::Collapsed);
    } else Restore(record,element);
}
void Inspect(DependencyObject const& node,int depth,int& budget) {
    if (!node || depth>30 || --budget<0) return;
    auto element=node.try_as<FrameworkElement>();
    if (element) {
        auto name=winrt::get_class_name(element);
        if (name==L"Taskbar.TaskListButton" || name==L"Taskbar.TaskListLabeledButton") {
            auto key=winrt::get_abi(element);
            auto it=buttons.find(key);
            if (it==buttons.end()) {
                Button record;record.element=element;
                record.identityToken=element.RegisterPropertyChangedCallback(
                    Automation::AutomationProperties::AutomationIdProperty(),
                    [](DependencyObject const& sender,DependencyProperty const&) {
                        if (applying) return;
                        try {
                            auto button=sender.try_as<FrameworkElement>();
                            if (!button) return;
                            auto found=buttons.find(winrt::get_abi(button));
                            if(found!=buttons.end()) {
                                applying=true;Apply(found->second,button);applying=false;
                            }
                        } catch(...) {applying=false;}
                    });
                it=buttons.emplace(key,std::move(record)).first;
            }
            Apply(it->second,element);
            return;
        }
    }
    int count=Media::VisualTreeHelper::GetChildrenCount(node);
    for(int i=0;i<count && budget>0;i++) Inspect(Media::VisualTreeHelper::GetChild(node,i),depth+1,budget);
}
bool Readable(void* pointer,size_t bytes) {
    MEMORY_BASIC_INFORMATION info{};
    if(!pointer || !VirtualQuery(pointer,&info,sizeof(info)) || info.State!=MEM_COMMIT ||
       (info.Protect&(PAGE_NOACCESS|PAGE_GUARD)))return false;
    auto start=reinterpret_cast<uintptr_t>(pointer);
    return start+bytes>=start && start+bytes<=reinterpret_cast<uintptr_t>(info.BaseAddress)+info.RegionSize;
}
XamlRoot Root(HWND taskbar,bool secondary) {
    HWND child=secondary ? FindWindowExW(taskbar,nullptr,L"WorkerW",nullptr)
                         : reinterpret_cast<HWND>(GetPropW(taskbar,L"TaskbandHWND"));
    if(!child)return nullptr;
    auto object=reinterpret_cast<void**>(GetWindowLongPtrW(child,0));
    auto expected=secondary?secondaryVtable:primaryVtable;
    if(!Readable(object,21*sizeof(void*)))return nullptr;
    int slot=0;for(;slot<20 && object[slot]!=expected;slot++);
    if(slot==20)return nullptr;
    void* host[2]{};
    (secondary?secondaryHost:primaryHost)(object+slot,host);
    struct ReleaseHost {void* counter;~ReleaseHost(){if(counter)releaseShared(counter);}} release{host[1]};
    if(!host[0] || !host[1])return nullptr;
    XamlRoot result=nullptr;
    if(Readable(static_cast<BYTE*>(host[0])+hostOffset,sizeof(void*))) {
        auto objectUnknown=*reinterpret_cast<IUnknown**>(static_cast<BYTE*>(host[0])+hostOffset);
        if(Readable(objectUnknown,sizeof(void*))) {
            FrameworkElement element=nullptr;
            if(SUCCEEDED(objectUnknown->QueryInterface(winrt::guid_of<FrameworkElement>(),winrt::put_abi(element))) && element)
                result=element.XamlRoot();
        }
    }
    return result;
}
bool ReadRules() {
    if(!ruleMutex)ruleMutex=CreateMutexW(nullptr,FALSE,MutexName);
    if(!shared) {
        if(!ruleMap)ruleMap=OpenFileMappingW(FILE_MAP_ALL_ACCESS,FALSE,MapName);
        if(ruleMap)shared=static_cast<BYTE*>(MapViewOfFile(ruleMap,FILE_MAP_ALL_ACCESS,0,0,MapBytes));
    }
    if(!shared || !ruleMutex){wanted.clear();return false;}
    DWORD wait=WaitForSingleObject(ruleMutex,0);
    if(wait!=WAIT_OBJECT_0 && wait!=WAIT_ABANDONED){if(GetTickCount64()-lastRead>=3500)wanted.clear();return false;}
    wanted.clear();
    bool valid=false;
    auto now=GetTickCount64();
    auto heartbeat=*reinterpret_cast<ULONGLONG*>(shared+8);
    DWORD bytes=*reinterpret_cast<DWORD*>(shared+16);
    if(*reinterpret_cast<DWORD*>(shared)==0x54435631 && *reinterpret_cast<DWORD*>(shared+4)==1 &&
       heartbeat>0 && now>=heartbeat && now-heartbeat<3500 && bytes<=60000 && bytes%2==0) {
        std::wstring data(reinterpret_cast<wchar_t*>(shared+40),bytes/2);
        size_t begin=0;
        while(begin<data.size()) {
            size_t end=data.find(L'\n',begin);if(end==data.npos)end=data.size();
            auto id=data.substr(begin,end-begin);
            if(!id.empty() && id.size()<=4096 && id.find(L'\0')==id.npos)wanted.insert(id);
            begin=end+1;
        }
        valid=true;
        lastRead=heartbeat;
    }
    ReleaseMutex(ruleMutex);return valid;
}
void Report(DWORD status,DWORD count) {
    if(!shared || !ruleMutex)return;
    DWORD wait=WaitForSingleObject(ruleMutex,0);
    if(wait!=WAIT_OBJECT_0 && wait!=WAIT_ABANDONED)return;
    *reinterpret_cast<DWORD*>(shared+24)=status;
    *reinterpret_cast<DWORD*>(shared+28)=count;
    *reinterpret_cast<ULONGLONG*>(shared+32)=GetTickCount64();
    ReleaseMutex(ruleMutex);
}
void Tick() noexcept {
    if(applying)return;applying=true;
    try {
        if(!ReadRules() && GetTickCount64()-lastRead>=3500)unloading=true;
        if(unloading)wanted.clear();
        for(auto it=buttons.begin();it!=buttons.end();) {
            auto element=it->second.element.get();
            if(!element){it=buttons.erase(it);continue;}
            Apply(it->second,element);++it;
        }
        int roots=0;
        if(!unloading)EnumThreadWindows(GetCurrentThreadId(),[](HWND h,LPARAM l)->BOOL {
            wchar_t type[80]{};GetClassNameW(h,type,80);
            bool secondary=wcscmp(type,L"Shell_SecondaryTrayWnd")==0;
            if(secondary || wcscmp(type,L"Shell_TrayWnd")==0) {
                try {auto root=Root(h,secondary);if(root){int budget=12000;Inspect(root.Content(),0,budget);++*reinterpret_cast<int*>(l);}}
                catch(...){}
            }
            return TRUE;
        },reinterpret_cast<LPARAM>(&roots));
        DWORD count=0;for(auto const& item:buttons)if(item.second.changed)++count;
        Report(unloading?0:roots>0?1:2,count);
        if(unloading || wanted.empty()) {
            for(auto& item:buttons)if(auto element=item.second.element.get())
                element.UnregisterPropertyChangedCallback(Automation::AutomationProperties::AutomationIdProperty(),item.second.identityToken);
            buttons.clear();
            if(timerId){KillTimer(nullptr,timerId);timerId=0;}
            if(unloading)cleanupComplete=true;
        }
    }catch(...){Report(3,0);}
    applying=false;
}
void OnUiThread() {
    Tick();
    if(!unloading && !wanted.empty() && !timerId)timerId=SetTimer(nullptr,0,750,[](HWND,UINT,UINT_PTR,DWORD){Tick();});
}
// Attach uses a short-lived, thread-specific Windows hook solely to run the
// visual helper on the taskbar UI thread. It never hooks an application window.
static constexpr size_t ConfigOffset=61000;
static const char* SymbolNames[]={
    "const CTaskBand::`vftable'{for `ITaskListWndSite'}",
    "const CSecondaryTaskBand::`vftable'{for `ITaskListWndSite'}",
    "public: virtual class std::shared_ptr<class TaskbarHost> __cdecl CTaskBand::GetTaskbarHost(void)const",
    "public: virtual class std::shared_ptr<class TaskbarHost> __cdecl CSecondaryTaskBand::GetTaskbarHost(void)const",
    "public: int __cdecl TaskbarHost::FrameHeight(void)const",
    "public: void __cdecl std::_Ref_count_base::_Decref(void)"
};
extern "C" __declspec(dllexport) DWORD WINAPI ResolveTaskbarSymbols(PCWSTR directory,DWORD* config,DWORD count) {
    if(count!=8)return ERROR_INVALID_PARAMETER;
    std::wstring image=std::wstring(directory)+L"\\Taskbar.pdb";
    HANDLE context=GetCurrentProcess();
    SymSetOptions(SYMOPT_DEFERRED_LOADS|SYMOPT_FAIL_CRITICAL_ERRORS|SYMOPT_EXACT_SYMBOLS|SYMOPT_NO_PROMPTS);
    if(!SymInitializeW(context,directory,FALSE))return GetLastError();
    DWORD result=ERROR_NOT_FOUND;ZeroMemory(config+2,6*sizeof(DWORD));
    DWORD64 base=SymLoadModuleExW(context,nullptr,image.c_str(),nullptr,0x100000000,config[1],nullptr,0);
    if(base) {
        SymEnumSymbols(context,base,nullptr,[](PSYMBOL_INFO info,ULONG,void* user)->BOOL{
            char decoded[8192]{};
            if(!UnDecorateSymbolName(info->Name,decoded,sizeof(decoded),UNDNAME_COMPLETE))return TRUE;
            std::string name=decoded;
            const std::string pointer=" __ptr64";size_t at;
            while((at=name.find(pointer))!=name.npos)name.erase(at,pointer.size());
            for(int i=0;i<6;i++)if(name==SymbolNames[i])static_cast<DWORD*>(user)[i+2]=static_cast<DWORD>(info->Address-info->ModBase);
            return TRUE;
        },config);
        IMAGEHLP_MODULEW64 details{};details.SizeOfStruct=sizeof(details);
        wchar_t guid[40]{};std::wstring actual;
        bool hasDetails=SymGetModuleInfoW64(context,base,&details);
        if(hasDetails){StringFromGUID2(details.PdbSig70,guid,40);for(auto c:guid)if(iswxdigit(c))actual+=towupper(c);wchar_t age[16]{};swprintf_s(age,L"%X",details.PdbAge);actual+=age;}
        std::wstring expected=directory;auto separator=expected.find_last_of(L"\\/");if(separator!=expected.npos)expected.erase(0,separator+1);
        if(hasDetails && details.SymType==SymPdb && _wcsicmp(actual.c_str(),expected.c_str())==0 &&
           config[2]&&config[3]&&config[4]&&config[5]&&config[6]&&config[7]) {
            result=ERROR_SUCCESS;
        }
    }
    SymCleanup(context);return result;
}
extern "C" __declspec(dllexport) DWORD WINAPI ReadTaskbarIdentity(PWSTR key,DWORD capacity,DWORD* config,DWORD count) {
    if(capacity<48||count!=8)return ERROR_INVALID_PARAMETER;
    DWORD pid=0;GetWindowThreadProcessId(FindWindowW(L"Shell_TrayWnd",nullptr),&pid);
    if(!pid)return ERROR_NOT_FOUND;
    HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,pid);
    if(snapshot==INVALID_HANDLE_VALUE)return GetLastError();
    MODULEENTRY32W entry{};entry.dwSize=sizeof(entry);BYTE* base=nullptr;
    if(Module32FirstW(snapshot,&entry))do{if(_wcsicmp(entry.szModule,L"taskbar.dll")==0){base=entry.modBaseAddr;break;}}while(Module32NextW(snapshot,&entry));
    CloseHandle(snapshot);if(!base)return ERROR_NOT_FOUND;
    HANDLE process=OpenProcess(PROCESS_VM_READ|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid);
    if(!process)return GetLastError();
    auto read=[&](const void* at,void* into,size_t bytes){SIZE_T got=0;return ReadProcessMemory(process,at,into,bytes,&got)&&got==bytes;};
    IMAGE_DOS_HEADER dos{};IMAGE_NT_HEADERS64 pe{};DWORD result=ERROR_INVALID_DATA;
    if(read(base,&dos,sizeof(dos)) && dos.e_magic==IMAGE_DOS_SIGNATURE && dos.e_lfanew>0 && dos.e_lfanew<1048576 &&
       read(base+dos.e_lfanew,&pe,sizeof(pe)) && pe.Signature==IMAGE_NT_SIGNATURE && pe.FileHeader.Machine==IMAGE_FILE_MACHINE_AMD64) {
        auto debug=pe.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_DEBUG];
        if(debug.Size<=65536 && debug.VirtualAddress+debug.Size<=pe.OptionalHeader.SizeOfImage) {
            for(DWORD i=0;i<debug.Size/sizeof(IMAGE_DEBUG_DIRECTORY);i++) {
                IMAGE_DEBUG_DIRECTORY item{};
                if(!read(base+debug.VirtualAddress+i*sizeof(item),&item,sizeof(item)) || item.Type!=IMAGE_DEBUG_TYPE_CODEVIEW || item.SizeOfData<24 ||
                    item.AddressOfRawData+24>pe.OptionalHeader.SizeOfImage)continue;
                struct {DWORD signature;GUID id;DWORD age;} rsds{};
                if(!read(base+item.AddressOfRawData,&rsds,sizeof(rsds))||rsds.signature!=0x53445352)continue;
                wchar_t guid[40]{};StringFromGUID2(rsds.id,guid,40);std::wstring value;
                for(auto c:guid)if(iswxdigit(c))value+=towupper(c);
                wchar_t age[16]{};swprintf_s(age,L"%X",rsds.age);value+=age;
                wcscpy_s(key,capacity,value.c_str());config[0]=pe.FileHeader.TimeDateStamp;config[1]=pe.OptionalHeader.SizeOfImage;
                result=ERROR_SUCCESS;break;
            }
        }
    }
    CloseHandle(process);return result;
}
bool InitializeOnUiThread() {
    if(!ReadRules())return false;
    DWORD config[8]{};DWORD wait=WaitForSingleObject(ruleMutex,0);
    if(wait!=WAIT_OBJECT_0 && wait!=WAIT_ABANDONED)return false;
    memcpy(config,shared+ConfigOffset,sizeof(config));ReleaseMutex(ruleMutex);
    HMODULE module=GetModuleHandleW(L"taskbar.dll");
    if(!module)return false;
    auto bytes=reinterpret_cast<BYTE*>(module);
    auto dos=reinterpret_cast<IMAGE_DOS_HEADER*>(bytes);
    auto pe=reinterpret_cast<IMAGE_NT_HEADERS64*>(bytes+dos->e_lfanew);
    if(pe->FileHeader.TimeDateStamp!=config[0]||pe->OptionalHeader.SizeOfImage!=config[1])return false;
    for(int i=2;i<8;i++)if(config[i]==0 || config[i]>=config[1] || !Readable(bytes+config[i],8))return false;
    primaryVtable=bytes+config[2];secondaryVtable=bytes+config[3];
    primaryHost=reinterpret_cast<HostFn>(bytes+config[4]);secondaryHost=reinterpret_cast<HostFn>(bytes+config[5]);
    heightCode=bytes+config[6];releaseShared=reinterpret_cast<ReleaseFn>(bytes+config[7]);
    auto b=static_cast<const BYTE*>(heightCode);
    if(b[0]!=0x48 || b[1]!=0x83 || b[2]!=0xEC || b[4]!=0x48 || b[5]!=0x83 || b[6]!=0xC1 || b[7]>0x7F)return false;
    hostOffset=b[7];
    if(!pinned){HMODULE retained=nullptr;if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,reinterpret_cast<PCWSTR>(&InitializeOnUiThread),&retained))return false;pinned=true;}
    unloading=false;cleanupComplete=false;return true;
}
LRESULT CALLBACK AttachHook(int code,WPARAM w,LPARAM l) {
    try {
    if(code==HC_ACTION) {
        auto message=reinterpret_cast<CWPSTRUCT*>(l);
        if(message->message==RegisterWindowMessageW(L"TaskbarControl.VisualHelper.Attach.v1")) {
            if(InitializeOnUiThread())OnUiThread();else Report(4,0);
        }
    }
    } catch(...) {Report(3,0);}
    return CallNextHookEx(nullptr,code,w,l);
}
extern "C" __declspec(dllexport) DWORD WINAPI AttachTaskbarVisuals(const DWORD* config,DWORD count) {
    if(count!=8)return ERROR_INVALID_PARAMETER;
    if(!ReadRules())return ERROR_NOT_READY;
    DWORD wait=WaitForSingleObject(ruleMutex,100);
    if(wait!=WAIT_OBJECT_0 && wait!=WAIT_ABANDONED)return ERROR_BUSY;
    memcpy(shared+ConfigOffset,config,8*sizeof(DWORD));ReleaseMutex(ruleMutex);
    HWND window=FindWindowW(L"Shell_TrayWnd",nullptr);DWORD pid=0;
    DWORD thread=GetWindowThreadProcessId(window,&pid);
    if(!thread || pid==GetCurrentProcessId())return ERROR_NOT_FOUND;
    HHOOK hook=SetWindowsHookExW(WH_CALLWNDPROC,AttachHook,helperModule,thread);
    if(!hook)return GetLastError();
    DWORD_PTR ignored=0;
    bool sent=SendMessageTimeoutW(window,RegisterWindowMessageW(L"TaskbarControl.VisualHelper.Attach.v1"),0,0,SMTO_ABORTIFHUNG|SMTO_BLOCK,3000,&ignored)!=0;
    DWORD error=sent?ERROR_SUCCESS:GetLastError();UnhookWindowsHookEx(hook);return error;
}
BOOL WINAPI DllMain(HINSTANCE instance,DWORD reason,LPVOID){if(reason==DLL_PROCESS_ATTACH){helperModule=instance;DisableThreadLibraryCalls(instance);}return TRUE;}
