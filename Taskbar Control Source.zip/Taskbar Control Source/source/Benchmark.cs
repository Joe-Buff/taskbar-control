using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

internal static class Benchmark
{
    internal static void Run(string directory)
    {
        Directory.CreateDirectory(directory);
        var ui = new MainForm(new Settings(), Path.Combine(directory, "benchmark-settings.json"), true, true);
        var timer = new Timer { Interval = 5000 };
        var process = Process.GetCurrentProcess();
        TimeSpan startCpu = TimeSpan.Zero; Stopwatch elapsed = null; int phase = 0;
        timer.Tick += delegate
        {
            if (phase++ == 0) { process.Refresh(); startCpu = process.TotalProcessorTime; elapsed = Stopwatch.StartNew(); timer.Interval = 15000; return; }
            process.Refresh();
            double cpu = (process.TotalProcessorTime - startCpu).TotalMilliseconds;
            File.WriteAllLines(Path.Combine(directory, "performance.txt"), new[] {
                "Scenario: UI initialized and hidden in tray; zero hide rules; 5-second warmup.",
                "Measurement seconds: " + elapsed.Elapsed.TotalSeconds.ToString("F2"),
                "Process CPU milliseconds: " + cpu.ToString("F2"),
                "CPU % of one logical core: " + (100 * cpu / elapsed.Elapsed.TotalMilliseconds).ToString("F3"),
                "CPU % of total machine: " + (100 * cpu / elapsed.Elapsed.TotalMilliseconds / Environment.ProcessorCount).ToString("F3"),
                "Working set MiB: " + (process.WorkingSet64 / 1048576.0).ToString("F2"),
                "Private bytes MiB: " + (process.PrivateMemorySize64 / 1048576.0).ToString("F2"),
                "Logical processors: " + Environment.ProcessorCount,
                "Restricted test environment. This is not a measurement of active hiding, app launch storms or scanning."
            });
            timer.Stop(); timer.Dispose(); process.Dispose(); ui.TestExit();
        };
        timer.Start(); Application.Run(ui);
    }
}
