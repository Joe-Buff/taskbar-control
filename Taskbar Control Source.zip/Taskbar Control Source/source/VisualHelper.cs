using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

// The native component is embedded in the EXE. No Windhawk installation, mod,
// registry injection, or third-party service is involved.
internal sealed class VisualHelper
{
    [UnmanagedFunctionPointer(CallingConvention.Winapi,CharSet=CharSet.Unicode)]delegate uint ResolveSymbols(string directory,[In,Out]uint[] config,uint count);
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]delegate uint Attach(uint[] config,uint count);
    [UnmanagedFunctionPointer(CallingConvention.Winapi,CharSet=CharSet.Unicode)]delegate uint ReadIdentity(StringBuilder key,uint capacity,[Out]uint[] config,uint count);
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern IntPtr LoadLibraryEx(string file,IntPtr unused,uint flags);
    [DllImport("kernel32.dll",CharSet=CharSet.Ansi)]static extern IntPtr GetProcAddress(IntPtr module,string name);
    IntPtr module;
    uint[] config;
    string preparedKey;
    Attach attach;
    internal static uint[] KnownOffsets(string key)
    {
        // Public build metadata verified against the corresponding Microsoft PDBs.
        if(key=="483327DB5FAC66CA1D844F9D8F5054CB1")return new uint[]{0x1cbf50,0x1bffb8,0x1097a0,0x169180,0x8aefc,0x27ca0};
        if(key=="6C3AA9496CD5913CBF5AE8A6F3B506AA1")return new uint[]{0x1c9ff0,0x1bdf68,0x107c60,0x166c80,0x8b44c,0x27bb0};
        return null;
    }
    internal static string SymbolKey(byte[] image)
    {
        using(var reader=new BinaryReader(new MemoryStream(image)))
        {
            reader.BaseStream.Position=0x3c;int pe=reader.ReadInt32();reader.BaseStream.Position=pe;
            if(reader.ReadUInt32()!=0x4550)throw new InvalidDataException("Invalid taskbar image.");
            reader.ReadUInt16();ushort sections=reader.ReadUInt16();reader.BaseStream.Position=pe+20;ushort optionalSize=reader.ReadUInt16();
            int optional=pe+24;reader.BaseStream.Position=optional;
            if(reader.ReadUInt16()!=0x20b)throw new NotSupportedException("This build requires Windows 11 x64.");
            reader.BaseStream.Position=optional+112+6*8;uint debugRva=reader.ReadUInt32(),debugSize=reader.ReadUInt32();
            Func<uint,long> offset=rva=>{
                for(int i=0;i<sections;i++){
                    reader.BaseStream.Position=optional+optionalSize+i*40+8;
                    uint virtualSize=reader.ReadUInt32(),address=reader.ReadUInt32(),rawSize=reader.ReadUInt32(),raw=reader.ReadUInt32();
                    if(rva>=address&&(ulong)rva-address<Math.Max(virtualSize,rawSize))return (long)raw+rva-address;
                }
                throw new InvalidDataException("Missing taskbar debug directory.");
            };
            long debugOffset=offset(debugRva);
            if(debugSize>65536)throw new InvalidDataException("Invalid taskbar debug directory.");
            for(int i=0;i<debugSize/28;i++){
                reader.BaseStream.Position=debugOffset+i*28+12;uint type=reader.ReadUInt32(),size=reader.ReadUInt32();reader.ReadUInt32();uint pointer=reader.ReadUInt32();
                if(type!=2||size<24||pointer>(long)image.Length-size)continue;
                reader.BaseStream.Position=pointer;if(reader.ReadUInt32()!=0x53445352)continue;
                var id=new Guid(reader.ReadBytes(16));uint age=reader.ReadUInt32();
                return id.ToString("N").ToUpperInvariant()+age.ToString("X");
            }
            throw new InvalidDataException("This Windows taskbar has no matching Microsoft symbols.");
        }
    }
    internal async Task Prepare()
    {
        if(module==IntPtr.Zero)
        {
            byte[] binary;
            using(var resource=typeof(VisualHelper).Assembly.GetManifestResourceStream("TaskbarControl.Visual.dll"))
            {
                if(resource==null)throw new InvalidOperationException("The embedded taskbar helper is missing. Download a complete build.");
                using(var data=new MemoryStream()){resource.CopyTo(data);binary=data.ToArray();}
            }
            string digest;using(var hash=SHA256.Create())digest=BitConverter.ToString(hash.ComputeHash(binary)).Replace("-","");
            string directory=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TaskbarControl","Runtime",digest.Substring(0,16));
            Directory.CreateDirectory(directory);string path=Path.Combine(directory,"TaskbarVisual.dll");
            bool valid=false;
            if(File.Exists(path))using(var hash=SHA256.Create())valid=BitConverter.ToString(hash.ComputeHash(File.ReadAllBytes(path))).Replace("-","")==digest;
            if(!valid)File.WriteAllBytes(path,binary);
            module=LoadLibraryEx(path,IntPtr.Zero,0x1100);
            if(module==IntPtr.Zero)throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error(),"Could not load the built-in taskbar helper.");
            attach=(Attach)Marshal.GetDelegateForFunctionPointer(GetProcAddress(module,"AttachTaskbarVisuals"),typeof(Attach));
        }
        var values=new uint[8];var identity=new StringBuilder(48);
        var readIdentity=(ReadIdentity)Marshal.GetDelegateForFunctionPointer(GetProcAddress(module,"ReadTaskbarIdentity"),typeof(ReadIdentity));
        uint identityError=readIdentity(identity,48,values,8);
        if(identityError!=0)throw new System.ComponentModel.Win32Exception((int)identityError,"Could not identify the current Windows taskbar.");
        string key=identity.ToString();
        if(key.Length<33||key.Length>40||key.Any(c=>!Uri.IsHexDigit(c)))throw new InvalidDataException("Invalid taskbar symbol identity.");
        if(config!=null&&preparedKey==key)return;
        var known=KnownOffsets(key);
        if(known!=null){Array.Copy(known,0,values,2,known.Length);config=values;preparedKey=key;return;}
        string cache=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TaskbarControl","Symbols",key);
        Directory.CreateDirectory(cache);string pdb=Path.Combine(cache,"Taskbar.pdb");
        if(!File.Exists(pdb))
        {
            string temporary=pdb+"."+Guid.NewGuid().ToString("N")+".tmp";
            try
            {
                ServicePointManager.SecurityProtocol|=SecurityProtocolType.Tls12;
                using(var client=new WebClient())await client.DownloadFileTaskAsync(new Uri("https://msdl.microsoft.com/download/symbols/Taskbar.pdb/"+key+"/Taskbar.pdb"),temporary);
                if(new FileInfo(temporary).Length<32)throw new InvalidDataException("Microsoft returned an incomplete symbol file.");
                if(!File.Exists(pdb))File.Move(temporary,pdb);
            }
            finally{if(File.Exists(temporary))File.Delete(temporary);}
        }
        var resolve=(ResolveSymbols)Marshal.GetDelegateForFunctionPointer(GetProcAddress(module,"ResolveTaskbarSymbols"),typeof(ResolveSymbols));
        uint error=await Task.Run(()=>resolve(cache,values,8));
        if(error!=0)throw new InvalidOperationException("This Windows taskbar build is not supported by the taskbar-only helper ("+error+"). Buttons have been left visible.");
        config=values;
        preparedKey=key;
    }
    internal void Connect()
    {
        if(config==null)throw new InvalidOperationException("Taskbar helper is still preparing.");
        uint error=attach(config,8);
        if(error!=0)throw new System.ComponentModel.Win32Exception((int)error,"Could not connect the built-in taskbar helper.");
    }
}
