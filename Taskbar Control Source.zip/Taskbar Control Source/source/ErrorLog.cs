using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using TaskbarStyling;

internal sealed class ErrorExplanation
{
    internal string Code,Summary,Next;
    internal ErrorExplanation(string code,string summary,string next){Code=code;Summary=summary;Next=next;}
}
internal static class ErrorHelp
{
    internal static string Technical(Exception error)
    {
        var win32=error as System.ComponentModel.Win32Exception;
        uint code=win32!=null&&win32.NativeErrorCode>0&&win32.NativeErrorCode<=65535?0x80070000u|(uint)win32.NativeErrorCode:unchecked((uint)error.HResult);
        return "HRESULT: 0x"+code.ToString("X8",CultureInfo.InvariantCulture)+Environment.NewLine+error;
    }
    internal static bool IsProgress(string message)
    {
        return message.StartsWith("Preparing taskbar-only hiding",StringComparison.OrdinalIgnoreCase)
            ||message.StartsWith("Waiting for the taskbar-only helper",StringComparison.OrdinalIgnoreCase)
            ||message.IndexOf("helper is still preparing",StringComparison.OrdinalIgnoreCase)>=0;
    }
    internal static ErrorExplanation Explain(string message)
    {
        string text=(message??"").ToLowerInvariant();uint code=0;
        var match=Regex.Match(text,@"\b0x([0-9a-f]{8})\b");
        if(match.Success)UInt32.TryParse(match.Groups[1].Value,NumberStyles.HexNumber,CultureInfo.InvariantCulture,out code);
        if((code&0xffff0000)==0x80070000)code&=0xffff;
        if(text.StartsWith("update failed:"))
            return new ErrorExplanation("AE0014","Taskbar Control could not complete the update.","Check the message in Settings > Updates, then try again. Your installed app and saved rules are kept.");
        if(text.Contains("not supported")||text.Contains("matching microsoft symbols"))
            return new ErrorExplanation("AE0003","This Windows taskbar version or layout is not supported.","Check for a newer Taskbar Control release. The affected buttons stay visible.");
        if(text.Contains("application frame host is shared"))
            return new ErrorExplanation("AE0011","This rule points to a shared Windows host, not a specific app.","Use Pick a window on the app to create a specific rule.");
        if(text.Contains("did not expose a taskbar identity"))
            return new ErrorExplanation("AE0004","Windows could not identify this app's taskbar button.","Open its main window and pick it again. If this continues, copy the details and include Diagnostics in your report.");
        if(code==5||text.Contains("access is denied")||text.Contains("access denied")||text.Contains("unauthorizedaccess"))
            return new ErrorExplanation("AE0002","Windows denied access to a required file or app.","Check that your account can access the selected file or folder. If security software blocked it, review its notification.");
        if(code==2||code==3||code==126||text.Contains("cannot find the file")||text.Contains("could not find")||text.Contains("helper is missing"))
            return new ErrorExplanation("AE0001","A required app, file, or folder could not be found.","If an app moved, add its new location. If Taskbar Control's helper is missing, reinstall the app and retry.");
        if(code==32||text.Contains("used by another process"))
            return new ErrorExplanation("AE0006","Another program is using a file Taskbar Control needs.","Close the program using that file, then try again.");
        if(code==1460||text.Contains("timed out")||text.Contains("timeout"))
            return new ErrorExplanation("AE0005","Windows or the taskbar helper did not respond in time.","Wait a moment, then pause and resume hiding. If it continues, reopen Taskbar Control.");
        if(text.Contains("remote name")||text.Contains("remote server")||text.Contains("download")||text.Contains("incomplete symbol file"))
            return new ErrorExplanation("AE0009","Taskbar Control could not download Windows compatibility information.","Check your internet connection and try again. Your app rules are kept locally.");
        if(text.Contains("could not save settings"))
            return new ErrorExplanation("AE0007","Your changes are active but could not be saved.","Check free disk space and access to your local app-data folder before exiting.");
        if(text.Contains("startup could not be configured"))
            return new ErrorExplanation("AE0008","Windows did not allow the startup setting to be changed.","You can still open Taskbar Control manually. Check whether your PC administrator restricts startup apps.");
        if(text.Contains("could not start window selection"))
            return new ErrorExplanation("AE0013","The window picker could not start.","Try Pick a window again. If it continues, reopen Taskbar Control and copy these details.");
        if(text.Contains("helper")||text.Contains("taskbar connection")||text.Contains("could not restore a button")||text.Contains("could not hide a button"))
            return new ErrorExplanation("AE0012","Taskbar Control could not finish updating the taskbar.","Try Pause hiding, then resume. If it continues, copy the error details and save Diagnostics for troubleshooting.");
        if(text.Contains("scan failed"))
            return new ErrorExplanation("AE0010","The folder scan could not finish.","Check that the selected folder is still available and readable, then rescan.");
        return new ErrorExplanation("AE9999","Taskbar Control could not complete this action.","Try the action again. If it continues, copy the details and save Diagnostics. The exact cause is not known from this message.");
    }
}
internal sealed class ErrorLog : Panel
{
    sealed class Entry
    {
        internal string Raw;internal ErrorExplanation Explanation;internal int Repeats=1;internal DateTime LastSeen=DateTime.Now;
        internal string Brief {get{return Explanation.Code+" · "+Explanation.Summary;}}
        internal string Readable {get{return LastSeen.ToString("HH:mm:ss")+"  "+Brief+(Repeats>1?" (repeated "+Repeats+" times)":"")+Environment.NewLine+"Next: "+Explanation.Next;}}
    }
    readonly List<Entry> entries=new List<Entry>();
    readonly Label title=new Label{Text="ERROR LOG",AutoSize=true};
    readonly ScrollableLogTextBox body=new ScrollableLogTextBox{ReadOnly=true,Multiline=true,BorderStyle=BorderStyle.None,Dock=DockStyle.Fill,Text="No errors to report.",AccessibleName="Recent errors and suggested fixes"};
    readonly FlatButton copy=new FlatButton{Text="Copy details",Enabled=false,Visible=false};
    readonly FlatButton clear=new FlatButton{Text="Clear log",Enabled=false,Visible=false};
    internal ErrorLog()
    {
        Dock=DockStyle.Fill;Margin=new Padding(0);Padding=new Padding(3,3,10,0);
        var layout=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,RowCount=2,Margin=new Padding(0)};
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));layout.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute,23));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));
        layout.Controls.Add(title,0,0);var textArea=new Panel{Dock=DockStyle.Fill,Margin=new Padding(0)};textArea.Controls.Add(body);textArea.Controls.Add(new ThemedScrollBar(body));layout.Controls.Add(textArea,0,1);
        var actions=new FlowLayoutPanel{AutoSize=true,Dock=DockStyle.Fill,FlowDirection=FlowDirection.TopDown,WrapContents=false,Margin=new Padding(6,0,0,0)};
        actions.Controls.Add(copy);actions.Controls.Add(clear);layout.Controls.Add(actions,1,0);layout.SetRowSpan(actions,2);Controls.Add(layout);
        copy.Click+=delegate{try{Clipboard.SetText(Details);copy.Text="Copied";}catch{copy.Text="Try copy again";}};
        clear.Click+=delegate{entries.Clear();Render();};
    }
    internal int Count {get{return entries.Count;}}
    internal event Action Changed;
    internal string Latest {get{return entries.Count==0?"No errors to report.":entries[0].Readable;}}
    internal string LatestBrief {get{return entries.Count==0?"No errors to report.":entries[0].Brief;}}
    internal string Readable {get{return body.Text;}}
    internal string Details {get{return TaskbarDiagnostics.Redact("Taskbar Control "+UpdateService.CurrentVersion+Environment.NewLine+Environment.OSVersion.VersionString+Environment.NewLine+Environment.NewLine+String.Join(Environment.NewLine+Environment.NewLine,entries.Select(e=>e.Readable+Environment.NewLine+"Technical details: "+e.Raw)));}}
    internal void Report(string message)
    {
        if(String.IsNullOrWhiteSpace(message)||ErrorHelp.IsProgress(message))return;
        if(entries.Count>0&&entries[0].Raw==message){entries[0].Repeats++;entries[0].LastSeen=DateTime.Now;Render();return;}
        var explanation=ErrorHelp.Explain(message);
        entries.Insert(0,new Entry{Raw=message,Explanation=explanation});
        if(entries.Count>50)entries.RemoveAt(entries.Count-1);Render();
    }
    void Render()
    {
        body.Text=entries.Count==0?"No errors to report.":String.Join(Environment.NewLine+Environment.NewLine,entries.Select(e=>e.Readable));
        body.ScrollBars=ScrollBars.None;
        body.SelectionStart=0;body.SelectionLength=0;body.ScrollToCaret();copy.Enabled=clear.Enabled=copy.Visible=clear.Visible=entries.Count>0;copy.Text="Copy details";ApplyTheme();if(Changed!=null)Changed();
    }
    internal void ApplyTheme(){body.BackColor=BackColor;body.ForeColor=entries.Count==0?Theme.Muted:Theme.Text;title.ForeColor=Theme.Muted;}
}
