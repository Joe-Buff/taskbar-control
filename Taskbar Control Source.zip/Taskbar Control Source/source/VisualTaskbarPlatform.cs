using System;
using System.Collections.Generic;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

// Windows' shell grouping identity can differ from the packaged process ID.
// This private, read-only interface is optional: failure leaves the button visible.
internal sealed class ShellAppResolver : IDisposable
{
    [ComImport,Guid("DE25675A-72DE-44B4-9373-05170450C140"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IResolver
    {
        [PreserveSig] int UnusedShortcut();
        [PreserveSig] int UnusedShortcutObject();
        [PreserveSig] int GetAppIDForWindow(IntPtr window,out IntPtr id,IntPtr a,IntPtr b,IntPtr c);
    }
    IResolver resolver;
    internal string Resolve(IntPtr window)
    {
        IntPtr text=IntPtr.Zero;
        try
        {
            if(resolver==null)resolver=(IResolver)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("660B90C8-73A9-4B58-8CAE-355B7F55341B")));
            if(resolver.GetAppIDForWindow(window,out text,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero)==0 && text!=IntPtr.Zero)
                return Marshal.PtrToStringUni(text);
        }
        catch(COMException){} catch(InvalidCastException){}
        finally{if(text!=IntPtr.Zero)Marshal.FreeCoTaskMem(text);}
        return WindowIdentity.WindowAppId(window);
    }
    public void Dispose(){if(resolver!=null){Marshal.ReleaseComObject(resolver);resolver=null;}}
}
internal sealed class VisualRuleBridge : IDisposable
{
    internal const string MapName=@"Local\TaskbarControl.VisualRules.Standalone.v2";
    internal const string MutexName=@"Local\TaskbarControl.VisualRules.Standalone.Lock.v2";
    internal const int Capacity=65536;
    readonly MemoryMappedFile map;
    readonly MemoryMappedViewAccessor view;
    readonly Mutex gate;
    internal int HiddenButtons;
    internal string Status="Waiting for the taskbar-only helper.";
    [DllImport("kernel32.dll")] internal static extern ulong GetTickCount64();
    internal VisualRuleBridge(string suffix="")
    {
        gate=new Mutex(false,MutexName+suffix);
        map=MemoryMappedFile.CreateOrOpen(MapName+suffix,Capacity,MemoryMappedFileAccess.ReadWrite);
        view=map.CreateViewAccessor(0,Capacity,MemoryMappedFileAccess.ReadWrite);
    }
    internal static byte[] Encode(IEnumerable<string> ids)
    {
        var values=ids.Where(x=>!String.IsNullOrEmpty(x)).Distinct(StringComparer.Ordinal).OrderBy(x=>x,StringComparer.Ordinal).ToArray();
        if(values.Any(x=>x.Length>4096||x.IndexOfAny(new[]{'\0','\r','\n'})>=0))throw new ArgumentException("Invalid taskbar app identity.");
        byte[] bytes=Encoding.Unicode.GetBytes(String.Join("\n",values));
        if(bytes.Length>60000)throw new InvalidOperationException("Too many taskbar identities. Reduce the number of hidden apps.");
        return bytes;
    }
    internal void Publish(IEnumerable<string> ids)
    {
        byte[] data=Encode(ids);bool held=false;
        try
        {
            try{held=gate.WaitOne(50);}catch(AbandonedMutexException){held=true;}
            if(!held){Status="Waiting for the taskbar built-in helper to respond.";return;}
            ulong now=GetTickCount64();
            view.Write(0,0x54435631);view.Write(4,1);view.Write(8,now);
            view.Write(16,data.Length);view.Write(20,0);view.WriteArray(40,data,0,data.Length);
            ulong reply=view.ReadUInt64(32);uint state=view.ReadUInt32(24);
            bool fresh=reply>0 && now>=reply && now-reply<3500;
            HiddenButtons=fresh&&state==1?(int)view.ReadUInt32(28):0;
            Status=!fresh?"Waiting for the taskbar-only helper. Apps remain in Alt+Tab."
                :state==1?"":state==2?"This taskbar layout is not supported by the built-in helper; buttons remain visible."
                :"The taskbar built-in helper is unavailable; buttons remain visible.";
        }
        finally{if(held)gate.ReleaseMutex();}
    }
    public void Dispose(){try{Publish(new string[0]);}finally{view.Dispose();map.Dispose();gate.Dispose();}}
}
internal sealed class VisualTaskbarPlatform : ITaskbarPlatform
{
    sealed class Entry {internal WindowTarget Target;internal string Id;}
    readonly Dictionary<IntPtr,Entry> entries=new Dictionary<IntPtr,Entry>();
    readonly ShellAppResolver resolver=new ShellAppResolver();
    readonly System.Windows.Forms.Timer heartbeat=new System.Windows.Forms.Timer{Interval=750};
    VisualRuleBridge bridge;
    readonly VisualHelper helper=new VisualHelper();
    bool preparing,disposed;
    DateTime retryAfter;
    string setupStatus="";
    internal int HiddenButtons {get{return bridge==null?0:bridge.HiddenButtons;}}
    internal string Status {get{return !String.IsNullOrEmpty(setupStatus)?setupStatus:bridge==null?"Taskbar-only helper is not connected.":bridge.Status;}}
    internal VisualTaskbarPlatform(){heartbeat.Tick+=delegate{Publish();if(entries.Count>0&&DateTime.UtcNow>=retryAfter&&!preparing&&!String.IsNullOrEmpty(bridge.Status))PrepareHelper();};}
    public void Connect(){if(bridge==null)bridge=new VisualRuleBridge();heartbeat.Start();Publish();PrepareHelper();}
    async void PrepareHelper()
    {
        if(preparing||disposed)return;preparing=true;heartbeat.Start();setupStatus="Preparing taskbar-only hiding…";
        try{await helper.Prepare();if(!disposed){Publish();helper.Connect();setupStatus="";}}
        catch(Exception ex){if(!disposed)setupStatus="Taskbar buttons left visible: "+ErrorHelp.Technical(ex);}
        finally{preparing=false;retryAfter=DateTime.UtcNow.AddSeconds(60);}
    }
    public void Hide(IntPtr window)
    {
        bool wasEmpty=entries.Count==0;
        Entry entry;var target=Resolve(window,null);if(target==null)return;
        if(!entries.TryGetValue(window,out entry)||!entry.Target.SameWindowApp(target))
        {
            string id=resolver.Resolve(window);
            if(String.IsNullOrWhiteSpace(id))throw new InvalidOperationException("Windows did not expose a taskbar identity for "+target.Name+". Its window was left unchanged.");
            // Recover a DeleteTab left by an older Taskbar Control session once.
            // Never remove taskbar membership in this backend.
            using(var recovery=new WindowsTaskbarPlatform()){recovery.Connect();recovery.Show(window);}
            entries[window]=new Entry{Target=target,Id=id};
        }
        heartbeat.Start();Publish();if(wasEmpty)PrepareHelper();
    }
    public void Show(IntPtr window){entries.Remove(window);Publish();}
    void Publish()
    {
        if(bridge==null)return;
        try
        {
            foreach(var item in entries.ToArray())if(!Exists(item.Key)||!item.Value.Target.SameWindowApp(Resolve(item.Key,null)))entries.Remove(item.Key);
            bridge.Publish(entries.Values.Select(x=>x.Id));
            if(entries.Count==0&&bridge.HiddenButtons==0&&!preparing)heartbeat.Stop();
        }
        catch(Exception ex){setupStatus="Taskbar rules could not be published: "+ErrorHelp.Technical(ex);}
    }
    public bool Exists(IntPtr h){return Native.IsWindow(h);}
    public bool Eligible(IntPtr h){return Native.Eligible(h);}
    public IEnumerable<IntPtr> Windows(){return Native.TopLevelWindows();}
    public WindowTarget Resolve(IntPtr h,Dictionary<uint,ProcessIdentity> cache){return WindowIdentity.Resolve(h,cache);}
    public void Dispose(){disposed=true;heartbeat.Stop();heartbeat.Dispose();entries.Clear();if(bridge!=null){bridge.Dispose();bridge=null;}resolver.Dispose();}
}
