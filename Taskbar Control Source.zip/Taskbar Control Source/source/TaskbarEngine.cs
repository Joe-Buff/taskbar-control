using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;

internal interface ITaskbarPlatform : IDisposable
{
    void Connect(); void Hide(IntPtr window); void Show(IntPtr window);
    bool Exists(IntPtr window); bool Eligible(IntPtr window);
    IEnumerable<IntPtr> Windows();
    WindowTarget Resolve(IntPtr window,Dictionary<uint,ProcessIdentity> cache);
}
internal sealed class WindowsTaskbarPlatform : ITaskbarPlatform
{
    private ITaskbarList taskbar;
    public void Connect()
    {
        Dispose();
        try{taskbar=(ITaskbarList)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("56FDF344-FD6D-11d0-958A-006097C9A090")));taskbar.HrInit();}
        catch{Dispose();throw;}
    }
    public void Hide(IntPtr window){taskbar.DeleteTab(window);}
    public void Show(IntPtr window){taskbar.AddTab(window);}
    public bool Exists(IntPtr window){return Native.IsWindow(window);}
    public bool Eligible(IntPtr window){return Native.Eligible(window);}
    public IEnumerable<IntPtr> Windows(){return Native.TopLevelWindows();}
    public WindowTarget Resolve(IntPtr window,Dictionary<uint,ProcessIdentity> cache){return WindowIdentity.Resolve(window,cache);}
    public void Dispose(){if(taskbar!=null){Marshal.ReleaseComObject(taskbar);taskbar=null;}}
}
// Used only by developer previews/benchmarks; never touches the live taskbar.
internal sealed class InactiveTaskbarPlatform : ITaskbarPlatform
{
    public void Connect(){} public void Hide(IntPtr h){} public void Show(IntPtr h){}
    public bool Exists(IntPtr h){return false;} public bool Eligible(IntPtr h){return false;}
    public IEnumerable<IntPtr> Windows(){return new IntPtr[0];}
    public WindowTarget Resolve(IntPtr h,Dictionary<uint,ProcessIdentity> cache){return null;}
    public void Dispose(){}
}
internal sealed class TaskbarEngine : IDisposable
{
    private readonly ITaskbarPlatform platform;
    private readonly Dictionary<IntPtr,WindowTarget> removed=new Dictionary<IntPtr,WindowTarget>();
    private readonly Dictionary<IntPtr,WindowTarget> picked=new Dictionary<IntPtr,WindowTarget>();
    private readonly Dictionary<IntPtr,string> outcomes=new Dictionary<IntPtr,string>();
    private readonly List<AppRule> hidden=new List<AppRule>();
    private readonly Dictionary<uint,ProcessIdentity> sweepProcesses=new Dictionary<uint,ProcessIdentity>();
    private readonly Native.EventProc callback;
    private readonly List<IntPtr> hooks=new List<IntPtr>();
    private readonly Timer timer=new Timer{Interval=1000};
    private readonly bool allowSelf;
    private readonly uint ownPid=(uint)Process.GetCurrentProcess().Id;
    private bool busy,connected,disposed;
    private const string HostWarning="Application Frame Host is shared by Windows apps. Pick the actual app window again to create a specific rule.";
    private DateTime retryAt;
    internal bool Paused;
    string lastError="";
    internal event Action<string> ErrorChanged;
    internal string LastError {get{return lastError;}set{if(lastError==value)return;lastError=value;if(ErrorChanged!=null&&!String.IsNullOrEmpty(value))ErrorChanged(value);}}
    internal int Count {get{return platform is VisualTaskbarPlatform?((VisualTaskbarPlatform)platform).HiddenButtons:removed.Count;}}
    internal bool Polling {get{return timer.Enabled;}}
    internal TaskbarEngine(bool test,ITaskbarPlatform injected=null)
    {
        allowSelf=test;platform=injected??new VisualTaskbarPlatform();callback=OnEvent;
        if(injected==null)
        {
            hooks.Add(Native.SetWinEventHook(3,3,IntPtr.Zero,callback,0,0,0));
            hooks.Add(Native.SetWinEventHook(0x8000,0x8003,IntPtr.Zero,callback,0,0,0));
            if(hooks.Any(h=>h==IntPtr.Zero))LastError="Window notifications unavailable; using periodic checks.";
        }
        timer.Tick+=delegate{Sweep();};
    }
    private void Connect()
    {
        connected=false;retryAt=DateTime.UtcNow.AddSeconds(10);
        try{platform.Connect();connected=true;LastError="";}
        catch(Exception ex){LastError="Taskbar connection: "+ErrorHelp.Technical(ex);}
    }
    internal void ExplorerRestarted(){connected=false;retryAt=DateTime.MinValue;Sweep();}
    internal void RememberPickedWindow(WindowTarget target)
    {
        if(target==null||target.Window==IntPtr.Zero)return;
        picked[target.Window]=target;
        Sweep();
    }
    internal string Outcome(IntPtr window)
    {string value;return outcomes.TryGetValue(window,out value)?value:"No taskbar request recorded";}
    internal IntPtr[] KnownWindows {get{return picked.Keys.Concat(removed.Keys).Distinct().ToArray();}}
    internal void Rules(IEnumerable<AppRule> rules)
    {
        if(LastError==HostWarning)LastError="";
        hidden.Clear();hidden.AddRange(rules.Where(r=>!r.Show&&r.CanManage));
        Sweep();
        if(rules.Any(r=>!r.Show&&!r.CanManage))LastError=HostWarning;
    }
    private void OnEvent(IntPtr hook,uint evt,IntPtr hwnd,int obj,int child,uint thread,uint time)
    {
        if(disposed)return;
        if(evt==0x8001&&obj==0&&child==0){removed.Remove(hwnd);picked.Remove(hwnd);outcomes.Remove(hwnd);return;}
        if(hwnd!=IntPtr.Zero&&(evt==3||(obj==0&&child==0)))Apply(hwnd);
    }
    private WindowTarget TargetFor(IntPtr hwnd)
    {
        var target=platform.Resolve(hwnd,busy?sweepProcesses:null);
        return target!=null&&(!allowSelf&&target.OwnerPid==ownPid)?null:target;
    }
    private bool Hidden(WindowTarget target){return hidden.Any(rule=>rule.Matches(target));}
    private void Apply(IntPtr hwnd)
    {
        if(Paused||hidden.Count==0||!connected||!platform.Eligible(hwnd))return;
        var target=TargetFor(hwnd);if(target==null||!Hidden(target))return;
        try{platform.Hide(hwnd);removed[hwnd]=target;outcomes[hwnd]=platform is VisualTaskbarPlatform?"Taskbar-only visual rule requested; window membership unchanged":"DeleteTab accepted by Windows (visual result not verified)";}
        catch(Exception ex){outcomes[hwnd]="Hide request failed: "+ex.Message;LastError="Could not hide a button: "+ErrorHelp.Technical(ex);}
    }
    internal void Sweep()
    {
        if(busy||disposed)return;busy=true;
        try
        {
            sweepProcesses.Clear();
            if(connected)LastError="";
            if(!connected&&(hidden.Count>0||removed.Count>0)&&DateTime.UtcNow>=retryAt)Connect();
            foreach(var entry in picked.ToArray())
            {
                if(!platform.Exists(entry.Key)){picked.Remove(entry.Key);continue;}
                var current=TargetFor(entry.Key);
                if(current!=null&&!entry.Value.SameWindowApp(current))picked.Remove(entry.Key);
            }
            foreach(var h in outcomes.Keys.ToArray())if(!platform.Exists(h))outcomes.Remove(h);
            foreach(var entry in removed.ToArray())
            {
                if(!platform.Exists(entry.Key)){removed.Remove(entry.Key);continue;}
                var current=TargetFor(entry.Key);
                if(current==null)continue;
                if(!entry.Value.SameWindowApp(current)){removed.Remove(entry.Key);continue;}
                if(Paused||!Hidden(current))
                {
                    try{if(platform is VisualTaskbarPlatform||platform.Eligible(entry.Key)){if(!connected)continue;platform.Show(entry.Key);outcomes[entry.Key]=platform is VisualTaskbarPlatform?"Taskbar visual restoration requested":"AddTab accepted by Windows";}removed.Remove(entry.Key);}
                    catch(Exception ex){LastError="Could not restore a button: "+ErrorHelp.Technical(ex);}
                }
            }
            if(!Paused&&hidden.Count>0)foreach(var h in platform.Windows().Concat(picked.Keys).Distinct().ToArray())Apply(h);
            var visual=platform as VisualTaskbarPlatform;
            if(visual!=null&&(hidden.Count>0||removed.Count>0)&&!String.IsNullOrEmpty(visual.Status))LastError=visual.Status;
        }
        finally{busy=false;sweepProcesses.Clear();timer.Enabled=(!Paused&&hidden.Count>0)||removed.Count>0;}
    }
    public void Dispose()
    {
        if(disposed)return;
        timer.Stop();foreach(var hook in hooks)if(hook!=IntPtr.Zero)Native.UnhookWinEvent(hook);
        Paused=true;Sweep();disposed=true;timer.Dispose();platform.Dispose();GC.KeepAlive(callback);
    }
}
