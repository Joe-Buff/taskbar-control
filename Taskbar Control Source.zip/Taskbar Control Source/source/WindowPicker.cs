using System;
using System.Drawing;
using System.Windows.Forms;

// A non-click-through overlay owns the entire mouse gesture. Never inject or
// forward input to the target. Resolve its HWND only after the overlay is hidden.
internal sealed class WindowPicker : Form
{
    private readonly Timer timer = new Timer { Interval = 25 };
    private readonly Action<WindowTarget> completed;
    private DateTime deadline = DateTime.UtcNow.AddSeconds(15);
    private DateTime settleAt;
    private Point point;
    private bool selecting, settling, cancelled, finished;
    internal WindowPicker(Action<WindowTarget> callback)
    {
        completed = callback;
        FormBorderStyle = FormBorderStyle.None; ShowInTaskbar = false;
        StartPosition = FormStartPosition.Manual; Bounds = SystemInformation.VirtualScreen;
        TopMost = true; BackColor = Color.Black; Opacity = 0.04;
        // Alpha must be nonzero, with no TransparencyKey / WS_EX_TRANSPARENT.
        Cursor = Cursors.Cross; KeyPreview = true; Text = "Select an app — Escape cancels";
        timer.Tick += Tick; Shown += delegate { timer.Start(); Activate(); };
        Deactivate += delegate { CancelSelection(); };
    }
    protected override void OnMouseDown(MouseEventArgs e)
    {
        if (e.Button != MouseButtons.Left) { CancelSelection(); return; }
        if (cancelled) return;
        if (!settling) point = PointToScreen(e.Location);
        selecting = true; settling = false; Capture = true;
        base.OnMouseDown(e);
    }
    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        if (e.Button != MouseButtons.Left || !selecting) return;
        selecting = false;
        // Keep swallowing input through the double-click interval, so a second
        // click cannot accidentally hit a Close button after the overlay leaves.
        settling = true; settleAt = DateTime.UtcNow.AddMilliseconds(SystemInformation.DoubleClickTime + 75);
    }
    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
        if (keyData == Keys.Escape || keyData == (Keys.Alt | Keys.F4)) CancelSelection();
        return true; // No selection-mode keyboard commands reach the target.
    }
    internal void CancelSelection() { cancelled = true; }
    private void Tick(object sender, EventArgs e)
    {
        if (finished) return;
        if (DateTime.UtcNow >= deadline) cancelled = true;
        if (Control.MouseButtons != MouseButtons.None) return;
        if (cancelled) Finish(false);
        else if (settling && DateTime.UtcNow >= settleAt) Finish(true);
    }
    private void Finish(bool selected)
    {
        if (finished) return;
        finished = true; timer.Stop(); Capture = false; Hide();
        WindowTarget target=null;
        try { if(selected)target=WindowIdentity.Resolve(Native.WindowFromPoint(point)); }
        catch { /* A disappearing/protected window is a failed selection. */ }
        Close(); completed(target);
    }
    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (!finished && e.CloseReason == CloseReason.UserClosing) { e.Cancel = true; CancelSelection(); }
        base.OnFormClosing(e);
    }
    protected override void Dispose(bool disposing)
    {
        if (disposing) timer.Dispose();
        base.Dispose(disposing);
    }
}
