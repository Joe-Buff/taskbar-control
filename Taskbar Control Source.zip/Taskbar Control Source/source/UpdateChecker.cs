using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using TaskbarStyling;

[DataContract] internal sealed class GitHubAsset
{
    [DataMember] public string name {get;set;}
    [DataMember] public string browser_download_url {get;set;}
    [DataMember] public string digest {get;set;}
    [DataMember] public long size {get;set;}
}
[DataContract] internal sealed class GitHubRelease
{
    [DataMember] public string tag_name {get;set;}
    [DataMember] public string name {get;set;}
    [DataMember] public bool draft {get;set;}
    [DataMember] public bool prerelease {get;set;}
    [DataMember] public string html_url {get;set;}
    [DataMember] public GitHubAsset[] assets {get;set;}
}
internal sealed class AppRelease
{
    internal Version Version;
    internal string Page,Download,Hash;
    internal long Size;
    internal bool Installable {get{return !String.IsNullOrEmpty(Download)&&!String.IsNullOrEmpty(Hash)&&Size>0&&Size<=UpdateService.MaximumInstallerBytes;}}
}
internal static class UpdateService
{
    internal const string Repository="https://github.com/Joe-Buff/taskbar-control";
    internal const string Latest="https://api.github.com/repos/Joe-Buff/taskbar-control/releases/latest";
    internal const long MaximumInstallerBytes=100*1024*1024;
    internal static Version CurrentVersion {get{return Assembly.GetExecutingAssembly().GetName().Version;}}
    // No timer, startup hook, or automatic network call. Only the settings button calls this service.
    internal static Task<AppRelease> CheckAsync(CancellationToken token)
    {
        return Task.Run(()=>{using(var bytes=new MemoryStream()){Transfer(Latest,bytes,1024*1024,0,token,null);return Parse(Encoding.UTF8.GetString(bytes.ToArray()));}},token);
    }
    internal static Version ReadVersion(string value)
    {
        var match=Regex.Match(value??"",@"^(?:v|version\s+)?(\d+)\.(\d+)(?:\.(\d+))?(?:\.(\d+))?$",RegexOptions.IgnoreCase);
        if(!match.Success)return null;Version result;return Version.TryParse(String.Join(".",Enumerable.Range(1,4).Select(i=>match.Groups[i].Success?match.Groups[i].Value:"0")),out result)?result:null;
    }
    internal static bool IsRepositoryUrl(string value,string suffix)
    {
        Uri uri;if(!Uri.TryCreate(value,UriKind.Absolute,out uri)||uri.Scheme!="https"||uri.Host!="github.com"||!uri.IsDefaultPort||!String.IsNullOrEmpty(uri.UserInfo))return false;
        return uri.AbsolutePath.StartsWith("/Joe-Buff/taskbar-control/"+suffix,StringComparison.OrdinalIgnoreCase)&&String.IsNullOrEmpty(uri.Query)&&String.IsNullOrEmpty(uri.Fragment);
    }
    internal static AppRelease Parse(string json)
    {
        GitHubRelease release;try{using(var bytes=new MemoryStream(Encoding.UTF8.GetBytes(json)))release=(GitHubRelease)new DataContractJsonSerializer(typeof(GitHubRelease)).ReadObject(bytes);}catch(Exception ex){throw new InvalidDataException("GitHub returned an unreadable release. Try again later.",ex);}
        if(release==null||release.draft||release.prerelease||!IsRepositoryUrl(release.html_url,"releases/tag/"))throw new InvalidDataException("The response did not identify a public stable release from the official repository.");
        var version=ReadVersion(release.tag_name)??ReadVersion(release.name);
        if(version==null)throw new InvalidDataException("The release has no recognizable version number. Check its GitHub page before updating.");
        var result=new AppRelease{Version=version,Page=release.html_url};
        var installers=(release.assets??new GitHubAsset[0]).Where(a=>a!=null&&Regex.IsMatch(a.name??"",@"^Taskbar[ ._-]?Control[ ._-]Setup(?:[ ._-]v?\d+(?:\.\d+){1,3})?\.exe$",RegexOptions.IgnoreCase)&&IsRepositoryUrl(a.browser_download_url,"releases/download/")).ToList();
        if(installers.Count==1)
        {
            var asset=installers[0];result.Download=asset.browser_download_url;result.Size=asset.size;
            if(Regex.IsMatch(asset.digest??"",@"^sha256:[a-fA-F0-9]{64}$"))result.Hash=asset.digest.Substring(7);
        }
        return result;
    }
    static HttpWebResponse Response(string url,CancellationToken token)
    {
        // Follow only HTTPS redirects to GitHub's release-asset hosts; never downgrade to HTTP.
        for(int redirects=0;redirects<6;redirects++)
        {
            token.ThrowIfCancellationRequested();var uri=new Uri(url);
            if(uri.Scheme!="https"||!uri.IsDefaultPort||!String.IsNullOrEmpty(uri.UserInfo)||!(uri.Host=="api.github.com"||uri.Host=="github.com"||uri.Host=="release-assets.githubusercontent.com"||uri.Host=="objects.githubusercontent.com"))throw new InvalidDataException("The download redirected outside GitHub. The update was stopped.");
            var request=(HttpWebRequest)WebRequest.Create(uri);request.AllowAutoRedirect=false;request.Timeout=15000;request.ReadWriteTimeout=15000;request.UserAgent="TaskbarControl/"+CurrentVersion.ToString(3);request.Accept="application/vnd.github+json";request.Headers["X-GitHub-Api-Version"]="2022-11-28";request.Proxy=WebRequest.DefaultWebProxy;
            HttpWebResponse response;using(token.Register(request.Abort)){try{response=(HttpWebResponse)request.GetResponse();}catch(WebException){token.ThrowIfCancellationRequested();throw;}}
            int status=(int)response.StatusCode;
            if(status>=300&&status<=399){string location=response.Headers["Location"];response.Dispose();if(String.IsNullOrEmpty(location))throw new InvalidDataException("GitHub returned an incomplete redirect.");url=new Uri(uri,location).AbsoluteUri;continue;}
            return response;
        }
        throw new InvalidDataException("GitHub returned too many redirects. Try again later.");
    }
    static void Transfer(string url,Stream destination,long limit,long expected,CancellationToken token,IProgress<string> progress)
    {
        ServicePointManager.SecurityProtocol|=SecurityProtocolType.Tls12;
        using(var response=Response(url,token))
        using(token.Register(response.Close))
        {
            if(response.ContentLength>limit)throw new InvalidDataException("The download is larger than the allowed size. The update was stopped.");
            using(var input=response.GetResponseStream())
            {
                byte[] buffer=new byte[65536];long total=0;int previous=-1;
                while(true)
                {
                    token.ThrowIfCancellationRequested();int count;
                    try{count=input.Read(buffer,0,buffer.Length);}catch{token.ThrowIfCancellationRequested();throw;}
                    if(count==0)break;total+=count;if(total>limit)throw new InvalidDataException("The download exceeded its expected size. The update was stopped.");destination.Write(buffer,0,count);
                    int percent=expected>0?(int)Math.Min(100,total*100/expected):0;if(progress!=null&&percent!=previous){previous=percent;progress.Report("Downloading update… "+percent+"%");}
                }
                if(expected>0&&total!=expected)throw new InvalidDataException("The installer download was incomplete. Your installed app has not been changed.");
            }
        }
    }
    internal static Task<string> DownloadAsync(AppRelease release,IProgress<string> progress,CancellationToken token)
    {
        return Task.Run(()=>
        {
            if(!release.Installable)throw new InvalidDataException("This release does not include one verifiable Windows installer. No update was installed.");
            string directory=Path.Combine(Path.GetTempPath(),"TaskbarControl-Update-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(directory);string file=Path.Combine(directory,"Taskbar Control Setup.exe"),partial=file+".partial";
            try
            {
                using(var output=new FileStream(partial,FileMode.CreateNew,FileAccess.Write,FileShare.None))Transfer(release.Download,output,release.Size,release.Size,token,progress);
                token.ThrowIfCancellationRequested();progress.Report("Verifying installer…");VerifyInstaller(partial,release);token.ThrowIfCancellationRequested();File.Move(partial,file);return file;
            }
            catch{try{if(File.Exists(partial))File.Delete(partial);Directory.Delete(directory);}catch{}throw;}
        },token);
    }
    internal static void VerifyInstaller(string file,AppRelease release)
    {
        if(new FileInfo(file).Length!=release.Size)throw new InvalidDataException("The installer size did not match the published release. Nothing was installed.");
        string actual;using(var input=File.OpenRead(file))using(var sha=SHA256.Create())actual=BitConverter.ToString(sha.ComputeHash(input)).Replace("-","");
        if(!String.Equals(actual,release.Hash,StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("The installer did not match GitHub's SHA-256 checksum. Nothing was installed. Try the update again.");
        using(var input=File.OpenRead(file))if(input.ReadByte()!=0x4d||input.ReadByte()!=0x5a)throw new InvalidDataException("The download is not a Windows installer. Nothing was installed.");
    }
    internal static string InstallerArguments(string directory)
    {
        if(String.IsNullOrWhiteSpace(directory)||directory.IndexOfAny(new[]{'"','\r','\n'})>=0||!Path.IsPathRooted(directory))throw new ArgumentException("The installation folder is not valid.");
        // NSIS requires /D to be last and unquoted, even for a path containing spaces.
        return "/UPDATE=1 /D="+Path.GetFullPath(directory).TrimEnd(Path.DirectorySeparatorChar);
    }
    internal static string FriendlyError(Exception ex)
    {
        var web=ex as WebException;if(web!=null)
        {
            var response=web.Response as HttpWebResponse;if(response!=null){int code=(int)response.StatusCode;response.Dispose();if(code==403||code==429)return "GitHub temporarily limited update checks. Wait a while, then try again.";if(code==404)return "No public release is available at the official GitHub location yet.";}
            return "Could not reach GitHub. Check your connection and try again. Your installed app and settings are unchanged.";
        }
        if(ex is InvalidDataException)return ex.Message;
        if(ex is UnauthorizedAccessException||ex is IOException)return "Windows could not save the update. Check available disk space and access to your temporary folder, then try again.";
        return "The update could not be started. Your settings are kept. Try again, or download the installer from the official GitHub release page.";
    }
}
internal static class UpdatePrompt
{
    internal static bool Confirm(Form owner,AppRelease release)
    {
        using(var dialog=new Form{Text="Taskbar Control update",Icon=owner.Icon,Font=owner.Font,BackColor=Theme.Background,ForeColor=Theme.Text,ClientSize=new Size(560,260),StartPosition=FormStartPosition.CenterParent,FormBorderStyle=FormBorderStyle.FixedDialog,MinimizeBox=false,MaximizeBox=false,ShowInTaskbar=false})
        {
            var title=new Label{Text="Version "+release.Version.ToString(3)+" is available",Font=Theme.Heading(18),AutoSize=true,Location=new Point(24,23)};dialog.Controls.Add(title);
            dialog.Controls.Add(new Label{Text=release.Installable?"Download and install this update from GitHub?\n\nSetup replaces the app in its current folder. Your saved app rules, folders, theme, and startup preferences are kept.":"This release does not include a verifiable installer. You can review it on GitHub. Nothing will be installed automatically.",Location=new Point(26,76),Size=new Size(506,116)});
            var actions=new FlowLayoutPanel{Dock=DockStyle.Bottom,Height=58,Padding=new Padding(24,4,0,0)};
            var install=new FlatButton{Text="Download and install",Primary=true,Enabled=release.Installable,DialogResult=DialogResult.OK};var later=new FlatButton{Text="Not now",DialogResult=DialogResult.Cancel};var notes=new FlatButton{Text="Release notes"};notes.Click+=delegate{try{System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(release.Page){UseShellExecute=true});}catch{notes.Text="Could not open";}};actions.Controls.Add(install);actions.Controls.Add(later);actions.Controls.Add(notes);dialog.Controls.Add(actions);dialog.AcceptButton=install;dialog.CancelButton=later;dialog.Shown+=delegate{Theme.Frame(dialog.Handle);};return dialog.ShowDialog(owner)==DialogResult.OK;
        }
    }
}
