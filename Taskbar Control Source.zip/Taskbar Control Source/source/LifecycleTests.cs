using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using TaskbarStyling;

internal static class LifecycleTests
{
    static readonly List<string> log=new List<string>();
    [DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr window,int message,IntPtr w,IntPtr l);
    [DllImport("user32.dll")] static extern IntPtr GetActiveWindow();
    [DllImport("user32.dll")] static extern bool IsWindowEnabled(IntPtr window);
    static void Check(bool condition,string message){if(!condition)throw new Exception(message);log.Add("PASS: "+message);}
    static Process Client(string exe,string name,string config,bool tray)
    {
        return Process.Start(new ProcessStartInfo(exe,"--activation-fixture \""+name+"\" \""+config+"\" "+(tray?"tray":"open")){UseShellExecute=false,WindowStyle=ProcessWindowStyle.Hidden});
    }
    static void Finish(Process process)
    {
        using(process)
        {
            var wait=Stopwatch.StartNew();while(!process.HasExited&&wait.ElapsedMilliseconds<7000)SelfTest.Pump(20);
            if(!process.HasExited){process.Kill();throw new Exception("Duplicate launch did not exit in time.");}
            if(process.ExitCode!=0)throw new Exception("Duplicate launch failed: "+process.ExitCode);
            SelfTest.Pump(60);
        }
    }
    static void Minimize(MainForm form){SendMessage(form.Handle,0x112,new IntPtr(0xf020),IntPtr.Zero);SelfTest.Pump(30);}
    static double Contrast(Color a,Color b)
    {
        Func<Color,double> luminance=c=>{double v=c.R/255.0;return v<=0.04045?v/12.92:Math.Pow((v+0.055)/1.055,2.4);};
        double x=luminance(a),y=luminance(b);return (Math.Max(x,y)+0.05)/(Math.Min(x,y)+0.05);
    }
    internal static void Run(string directory)
    {
        Directory.CreateDirectory(directory);
        try
        {
            string name=@"Local\TaskbarControl.Lifecycle."+Guid.NewGuid().ToString("N"),file=Path.Combine(directory,"settings.json");bool created;
            string copied=Path.Combine(directory,"Renamed Taskbar Control.exe");File.Copy(Application.ExecutablePath,copied,true);
            using(var mutex=new Mutex(true,name,out created))
            using(var form=new MainForm(new Settings{HideOwnTaskbar=true},file,true,true))
            {
                // The second launch starts before the receiving window exists.
                var early=Client(copied,name,file,false);SelfTest.Pump(200);
                using(var activation=new InstanceActivation(name))
                {
                    form.Show();SelfTest.Pump(80);Finish(early);
                    Check(!form.Visible,"A duplicate arriving during startup waits for the initial tray state");
                    activation.Ready(form.OpenWindow,form.ExitAndRestore);SelfTest.Pump(50);
                    Check(form.Visible&&form.TestTrayConfigured,"Queued startup activation opens the first instance");
                    IntPtr original=form.Handle;
                    Minimize(form);Check(!form.Visible&&!Native.IsWindowVisible(original)&&!Native.IsIconic(original),"Minimize with a hidden taskbar icon leaves no minimized caption window");
                    Finish(Client(copied,name,file,false));
                    Check(form.Visible&&form.WindowState==FormWindowState.Normal&&form.Handle==original,"Relaunching a renamed EXE restores the same window without a second instance");
                    for(int i=0;i<5;i++){form.Close();Finish(Client(Application.ExecutablePath,name,file,false));}
                    Check(form.Visible&&!form.IsDisposed&&form.Handle==original,"Five close-to-tray and relaunch cycles keep the original editor alive");
                    form.Hide();Finish(Client(copied,name,file,true));Check(!form.Visible,"A duplicate Windows startup launch stays silent in the tray");
                    Check(!File.Exists(file),"Duplicate launches do not create settings or another editor");
                    form.OpenWindow();form.WindowState=FormWindowState.Minimized;SelfTest.Pump(50);
                    Check(!form.Visible&&!Native.IsWindowVisible(form.Handle),"Programmatic minimize also hides the whole window");
                    Finish(Client(copied,name,file,false));Check(form.Visible&&form.WindowState==FormWindowState.Normal,"Relaunch restores a programmatically minimized window (visible="+form.Visible+", state="+form.WindowState+", iconic="+Native.IsIconic(form.Handle)+")");
                    form.TestOwn.Checked=false;SelfTest.Pump(30);Minimize(form);
                    Check(!form.Visible&&form.TestTrayConfigured,"Minimize also uses the tray when the app's taskbar button is enabled");
                    Finish(Client(copied,name,file,false));Check(form.Visible&&form.ShowInTaskbar,"Activation survives window handle recreation after changing own taskbar visibility");
                    form.WindowState=FormWindowState.Maximized;SelfTest.Pump(30);Minimize(form);Finish(Client(copied,name,file,false));
                    Check(form.Visible&&form.WindowState==FormWindowState.Maximized,"A maximized editor reopens maximized after tray minimization");
                    form.WindowState=FormWindowState.Normal;form.Location=new Point(-30000,-30000);form.Hide();Finish(Client(copied,name,file,false));
                    Check(Screen.AllScreens.Any(s=>s.WorkingArea.IntersectsWith(new Rectangle(form.Location,new Size(form.Width,48)))),"A hidden window on a disconnected display returns to an available screen");
                    using(var dialog=new Form{Text="Controlled owned dialog",ShowInTaskbar=false})
                    using(var timer=new System.Windows.Forms.Timer{Interval=30})
                    {
                        Process client=null;var deadline=DateTime.UtcNow.AddSeconds(7);bool focused=false;string observed="";
                        dialog.Shown+=delegate{client=Client(copied,name,file,false);timer.Start();};
                        timer.Tick+=delegate{if(client.HasExited){focused=GetActiveWindow()==dialog.Handle&&!IsWindowEnabled(form.Handle);observed="dialog active="+(GetActiveWindow()==dialog.Handle)+", owner enabled="+IsWindowEnabled(form.Handle);timer.Stop();dialog.Close();}else if(DateTime.UtcNow>deadline){timer.Stop();client.Kill();dialog.Close();}};
                        dialog.ShowDialog(form);Finish(client);Check(focused,"A duplicate launch focuses the existing modal dialog without bypassing it ("+observed+")");
                    }
                    form.TestTheme(true);Check(Contrast(Theme.Text,Theme.Surface)>=7&&Contrast(Theme.Muted,Theme.Selected)>=4.5,"Light-mode labels and secondary text meet strong contrast targets");
                    Check(Contrast(ModernPaint.Edge,ModernPaint.Field)>=3,"Light-mode field borders have at least 3:1 contrast");
                    form.TestTheme(false);
                    Finish(Process.Start(new ProcessStartInfo(copied,"--activation-fixture \""+name+"\" \""+file+"\" exit"){UseShellExecute=false,WindowStyle=ProcessWindowStyle.Hidden}));
                    Check(form.IsDisposed,"Setup's graceful exit request closes the editor through its restoration path");
                }
                Check(Native.FindWindowEx(new IntPtr(-3),IntPtr.Zero,null,name+".Activation")==IntPtr.Zero,"Exit destroys the invisible activation receiver");
            }
            ErrorChecks();
            string preference=Path.Combine(directory,"installer-preference.json");
            var saved=new Settings{ThemeMode="light",HideOwnTaskbar=true};saved.Apps.Add(new AppRule(@"C:\Apps\Example.exe"){Show=false});saved.Save(preference);
            Check(Program.ConfigureStartupPreference(preference,"off")==0&&Settings.Read(preference).StartupEnabled==false,"Installer startup opt-out is saved before the editor opens");
            var preserved=Settings.Read(preference);Check(preserved.ThemeMode=="light"&&preserved.HideOwnTaskbar&&!preserved.Apps[0].Show,"Installer configuration preserves existing rules and preferences");
            Check(Program.ConfigureStartupPreference(preference,"on")==0&&Settings.Read(preference).StartupEnabled==true,"Installer can enable startup before the editor opens");
            string originalSettings=File.ReadAllText(preference);Check(Program.ConfigureStartupPreference(preference,"invalid")==2&&File.ReadAllText(preference)==originalSettings,"Invalid installer options do not alter saved settings");
            File.WriteAllText(preference,"invalid settings");Check(Program.ConfigureStartupPreference(preference,"on")==1&&File.ReadAllText(preference)=="invalid settings","Unreadable settings are preserved and reported as an installer error");
            log.Add("PASS: Completed on controlled windows with an inactive taskbar platform; no user keyboard or mouse input was generated.");
        }
        catch(Exception ex){log.Add("FAIL: "+ex);Environment.ExitCode=1;}
        File.WriteAllLines(Path.Combine(directory,"lifecycle-results.txt"),log);
    }
    static void ErrorChecks()
    {
        Check(ErrorHelp.Explain("HRESULT: 0x80070002").Summary.Contains("not be found"),"File-not-found HRESULT gets a readable explanation");
        Check(ErrorHelp.Explain("HRESULT: 0x80070005").Summary.Contains("denied"),"Access-denied HRESULT gets a readable explanation");
        Check(ErrorHelp.Explain("HRESULT: 0x800705B4").Summary.Contains("respond in time"),"Timeout HRESULT gets a readable explanation");
        Check(ErrorHelp.Explain("This Windows taskbar build is not supported (127)").Next.Contains("newer"),"Unsupported Windows builds get a relevant next step");
        Check(ErrorHelp.Explain("HRESULT: 0x81234567").Next.Contains("not known"),"Unknown codes do not receive an invented diagnosis");
        string technical=ErrorHelp.Technical(new System.ComponentModel.Win32Exception(5,"A custom helper error"));
        Check(technical.Contains("0x80070005")&&ErrorHelp.Explain(technical).Summary.Contains("denied"),"Native Windows error codes survive custom exception messages");
        using(var errors=new ErrorLog())
        {
            errors.Report("Preparing taskbar-only hiding…");errors.Report("Waiting for the taskbar-only helper. Apps remain in Alt+Tab.");
            Check(errors.Count==0,"Normal helper startup is not logged as an error");
            errors.Report("HRESULT: 0x80070005");errors.Report("HRESULT: 0x80070005");
            Check(errors.Count==1&&!errors.Readable.Contains("0x80070005")&&errors.Readable.Contains("Next:"),"Repeated errors are deduplicated and the log shows readable guidance");
            Check(errors.Details.Contains("0x80070005"),"Copy details retains the original error code");
            for(int i=0;i<65;i++)errors.Report("Controlled unknown error "+i);
            Check(errors.Count==50,"Error history is bounded to avoid unbounded memory use");
        }
        using(var engine=new TaskbarEngine(true,new FakeTaskbarPlatform()))
        {
            int changes=0;engine.ErrorChanged+=delegate{changes++;};engine.LastError="Controlled failure";engine.LastError="Controlled failure";engine.LastError="";
            Check(changes==1,"Engine errors are delivered without adding a background polling timer");
        }
    }
}
