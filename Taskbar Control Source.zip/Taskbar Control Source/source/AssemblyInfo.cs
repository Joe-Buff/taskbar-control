using System.Reflection;
[assembly: AssemblyTitle("Taskbar Control")]
[assembly: AssemblyProduct("Taskbar Control")]
[assembly: AssemblyDescription("Choose which running apps appear on your taskbar")]
[assembly: AssemblyVersion("1.10.0.0")]
[assembly: AssemblyFileVersion("1.10.0.0")]
