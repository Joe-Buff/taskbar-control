using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using TaskbarStyling;

[DataContract]
public class AppRule
{
    [DataMember] public string Path;
    [DataMember] public bool Show = true;
    [DataMember] public string AppId;
    [DataMember] public string Name;
    public AppRule(string path) { Path = System.IO.Path.GetFullPath(path); }
    internal AppRule(WindowTarget target){Path=target.Path;AppId=target.AppId;Name=target.Name;}
    internal string Key {get{return String.IsNullOrEmpty(AppId)?"exe:"+Path:"app:"+AppId;}}
    internal string Label {get{return !String.IsNullOrEmpty(Name)?Name:!String.IsNullOrEmpty(Path)?System.IO.Path.GetFileName(Path):AppId;}}
    internal bool CanManage {get{return !String.IsNullOrEmpty(AppId)||!WindowIdentity.SharedHost(Path);}}
    internal bool Matches(WindowTarget target)
    {return target!=null&&CanManage&&(!String.IsNullOrEmpty(AppId)?String.Equals(AppId,target.AppId,StringComparison.OrdinalIgnoreCase):String.Equals(Path,target.Path,StringComparison.OrdinalIgnoreCase));}
}
[DataContract]
public class Settings
{
    [DataMember] public List<AppRule> Apps = new List<AppRule>();
    [DataMember] public List<string> Folders = new List<string>();
    [DataMember] public bool HideOwnTaskbar;
    [DataMember] public bool? StartupEnabled;
    [DataMember] public string ThemeMode = "dark";
    public static Settings Read(string file)
    {
        if (!File.Exists(file)) return new Settings();
        using (var s = File.OpenRead(file))
        {
            var value = (Settings)new DataContractJsonSerializer(typeof(Settings)).ReadObject(s);
            if (value == null || value.Apps == null || value.Folders == null) throw new InvalidDataException("Invalid settings file.");
            value.Apps = value.Apps.Where(x => x != null && (!String.IsNullOrWhiteSpace(x.Path)||!String.IsNullOrWhiteSpace(x.AppId))).GroupBy(x => x.Key, StringComparer.OrdinalIgnoreCase).Select(x => x.First()).ToList();
            foreach(var app in value.Apps)if(!app.CanManage)app.Show=true;
            return value;
        }
    }
    public void Save(string file)
    {
        Directory.CreateDirectory(System.IO.Path.GetDirectoryName(file));
        string temp = file + ".tmp";
        using (var s = File.Create(temp)) new DataContractJsonSerializer(typeof(Settings)).WriteObject(s, this);
        if (File.Exists(file)) File.Replace(temp, file, file + ".bak"); else File.Move(temp, file);
    }
}

internal static class Native
{
    internal delegate bool EnumProc(IntPtr hwnd, IntPtr data);
    internal delegate void EventProc(IntPtr hook, uint evt, IntPtr hwnd, int obj, int child, uint thread, uint time);
    [DllImport("user32.dll")] internal static extern bool EnumWindows(EnumProc callback, IntPtr data);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] internal static extern IntPtr FindWindowEx(IntPtr parent,IntPtr after,string className,string title);
    [DllImport("user32.dll")] internal static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] internal static extern bool IsWindow(IntPtr h);
    [DllImport("user32.dll")] internal static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")] internal static extern IntPtr GetWindow(IntPtr h, uint cmd);
    [DllImport("user32.dll")] internal static extern IntPtr GetAncestor(IntPtr h, uint flags);
    [DllImport("user32.dll")] internal static extern int GetWindowLong(IntPtr h, int index);
    [DllImport("user32.dll")] internal static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll")] internal static extern IntPtr SetWinEventHook(uint min, uint max, IntPtr module, EventProc callback, uint pid, uint tid, uint flags);
    [DllImport("user32.dll")] internal static extern bool UnhookWinEvent(IntPtr hook);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] internal static extern uint RegisterWindowMessage(string name);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] internal static extern int GetClassName(IntPtr h, StringBuilder name, int count);
    [DllImport("kernel32.dll")] internal static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] internal static extern bool QueryFullProcessImageName(IntPtr p, uint flags, StringBuilder path, ref int size);
    [DllImport("kernel32.dll")] internal static extern bool CloseHandle(IntPtr h);
    [DllImport("dwmapi.dll")] internal static extern int DwmSetWindowAttribute(IntPtr h, int attribute, ref int value, int size);
    [DllImport("user32.dll")] internal static extern short GetAsyncKeyState(int key);
    [DllImport("user32.dll")] internal static extern bool GetCursorPos(out Point point);
    [DllImport("user32.dll")] internal static extern IntPtr WindowFromPoint(Point point);
    internal static string WindowExecutable(IntPtr window)
    {
        var target=WindowIdentity.Resolve(window);return target==null?null:target.Path;
    }
    internal static string ProcessPath(uint pid)
    {
        IntPtr p = OpenProcess(0x1000, false, pid);
        if (p == IntPtr.Zero) return null;
        try
        {
            int count = 512; var b = new StringBuilder(count);
            if (QueryFullProcessImageName(p, 0, b, ref count)) return b.ToString();
            if (Marshal.GetLastWin32Error() != 122) return null;
            count = 32768; b = new StringBuilder(count);
            return QueryFullProcessImageName(p, 0, b, ref count) ? b.ToString() : null;
        }
        finally { CloseHandle(p); }
    }
    internal static bool Eligible(IntPtr h)
    {
        return EligibilityReason(h)=="eligible";
    }
    internal static string EligibilityReason(IntPtr h)
    {
        if(!IsWindow(h))return "window closed";
        if(!IsWindowVisible(h))return "window not visible";
        if(GetAncestor(h,2)!=h)return "child window";
        return EligibilityReason(GetWindowLong(h,-20),GetWindow(h,4)!=IntPtr.Zero,WindowIdentity.WindowClass(h));
    }
    internal static string EligibilityReason(int style,bool owned,string name)
    {
        if(new[]{"Shell_TrayWnd","Shell_SecondaryTrayWnd","Progman","WorkerW"}.Contains(name))return "Windows shell window";
        // APPWINDOW explicitly opts a window into the taskbar, including owned
        // or NOACTIVATE windows. Do not change any of these styles ourselves.
        if((style&0x40000)!=0)return "eligible";
        if((style&0x80)!=0)return "tool window";
        if((style&0x08000000)!=0)return "non-activating window";
        return owned?"owned window without APPWINDOW":"eligible";
    }
    internal static List<IntPtr> TopLevelWindows()
    {
        var windows=new HashSet<IntPtr>();
        EnumWindows(delegate(IntPtr h,IntPtr data){windows.Add(h);return true;},IntPtr.Zero);
        // EnumWindows is documented to enumerate desktop apps only on Windows
        // 8+. Supplement the modern app classes without walking a mutable
        // GetWindow chain. Bound and deduplicate each lookup during recreation.
        foreach(string name in new[]{"ApplicationFrameWindow","Windows.UI.Core.CoreWindow"})
        {
            IntPtr after=IntPtr.Zero;var seen=new HashSet<IntPtr>();
            for(int i=0;i<4096;i++)
            {
                after=FindWindowEx(IntPtr.Zero,after,name,null);
                if(after==IntPtr.Zero||!seen.Add(after))break;
                windows.Add(after);
            }
        }
        return windows.ToList();
    }
}
[ComImport, Guid("56FDF342-FD6D-11d0-958A-006097C9A090"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
internal interface ITaskbarList
{
    void HrInit(); void AddTab(IntPtr hwnd); void DeleteTab(IntPtr hwnd); void ActivateTab(IntPtr hwnd); void SetActiveAlt(IntPtr hwnd);
}

internal static class Scanner
{
    internal static List<string> Scan(IEnumerable<string> roots, CancellationToken token, out int skipped)
    {
        var result = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var visited = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var pending = new Stack<string>(roots); skipped = 0;
        while (pending.Count > 0)
        {
            token.ThrowIfCancellationRequested(); string dir = pending.Pop();
            if (!visited.Add(dir)) continue;
            try
            {
                foreach (string file in Directory.EnumerateFiles(dir, "*.exe")) { token.ThrowIfCancellationRequested(); result.Add(System.IO.Path.GetFullPath(file)); }
                foreach (string child in Directory.EnumerateDirectories(dir))
                {
                    token.ThrowIfCancellationRequested();
                    try { if ((File.GetAttributes(child) & FileAttributes.ReparsePoint) == 0) pending.Push(child); }
                    catch (IOException) { skipped++; } catch (UnauthorizedAccessException) { skipped++; }
                }
            }
            catch (IOException) { skipped++; } catch (UnauthorizedAccessException) { skipped++; }
        }
        return result.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList();
    }
}

internal static class Program
{
    [STAThread]
    private static void Main(string[] args)
    {
        Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
        if(args.Length==1&&args[0]=="--setup-startup-query")
        {
            try{Environment.ExitCode=(Settings.Read(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TaskbarControl","settings.json")).StartupEnabled??true)?11:10;}catch{Environment.ExitCode=12;}return;
        }
        if(args.Length==1&&args[0]=="--exit-for-setup"){InstanceActivation.RequestExit(@"Local\TaskbarControl.Utility.1");return;}
        if(args.Length==3&&args[0]=="--setup-test-preference"){Environment.ExitCode=ConfigureStartupPreference(args[1],args[2]);return;}
        if(args.Length==2&&args[0]=="--setup-startup-preference")
        {
            Environment.ExitCode=ConfigureStartupPreference(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TaskbarControl","settings.json"),args[1]);return;
        }
        if (args.Length == 2 && args[0] == "--self-test") { SelfTest.Run(args[1]); return; }
        if (args.Length == 2 && args[0] == "--benchmark") { Benchmark.Run(args[1]); return; }
        if (args.Length == 2 && args[0] == "--dashboard-test") { DashboardTests.Run(args[1]); return; }
        if (args.Length == 2 && args[0] == "--update-test") { UpdateTests.Run(args[1]); return; }
        if (args.Length == 2 && args[0] == "--update-network-test") { UpdateTests.NetworkRun(args[1]); return; }
        if (args.Length == 2 && args[0] == "--core-test") { SelfTest.RunCore(args[1]); return; }
        if (args.Length == 2 && args[0] == "--ui-preview") { DashboardTests.Run(args[1]); return; }
        if (args.Length == 2 && args[0] == "--picker-test") { PickerTests.Run(args[1]); return; }
        if (args.Length == 2 && args[0] == "--lifecycle-test") { LifecycleTests.Run(args[1]); return; }
        if (args.Length == 4 && args[0] == "--activation-fixture") { if(args[3]=="exit")InstanceActivation.RequestExit(args[1]);else RunInstance(args[1],args[2],args[3]=="tray",true); return; }
        if (args.Length == 2 && args[0] == "--host-fixture") { HostedFixture.Run(args[1],IntPtr.Zero); return; }
        if (args.Length == 3 && args[0] == "--child-fixture") { HostedFixture.Run(args[2],new IntPtr(Int64.Parse(args[1]))); return; }
        string config = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TaskbarControl", "settings.json");
        RunInstance(@"Local\TaskbarControl.Utility.1",config,args.Contains("--tray"),false);
    }
    internal static void RunInstance(string name,string config,bool startInTray,bool test)
    {
        bool created;
        using (var mutex = new Mutex(true, name, out created))
        {
            if (!created)
            {
                if(!InstanceActivation.Request(name,startInTray))
                {
                    Environment.ExitCode=2;
                    if(!test)MessageBox.Show("Taskbar Control is still starting or closing. Try opening it again in a moment. If you are upgrading from an older version, exit that copy from its tray menu first.","Taskbar Control",MessageBoxButtons.OK,MessageBoxIcon.Information);
                }
                return;
            }
            // Fixtures must never create a real engine or access the user's settings.
            if(test){Environment.ExitCode=3;return;}
            try
            {
                using(var activation=new InstanceActivation(name))
                using(var form=new MainForm(Settings.Read(config),config,startInTray))
                {
                    form.Shown+=delegate{form.BeginInvoke((Action)(()=>activation.Ready(form.OpenWindow,form.ExitAndRestore)));};
                    Application.Run(form);
                }
            }
            catch (Exception ex) { MessageBox.Show("Taskbar Control could not start. Your saved settings have been preserved.\n\n" + ex.Message + "\n\nSettings: " + config, "Taskbar Control", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
    internal static int ConfigureStartupPreference(string file,string choice)
    {
        if(choice!="on"&&choice!="off")return 2;
        try{var settings=Settings.Read(file);settings.StartupEnabled=choice=="on";settings.Save(file);return 0;}
        catch{return 1;}
    }
}
