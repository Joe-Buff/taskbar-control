param([string]$Destination=(Join-Path $PSScriptRoot '..\dist'),[switch]$SkipBuild,[string]$CppCompiler,[string]$InstallerCompiler,[string]$BinaryPath,[switch]$UseExistingNative)
$ErrorActionPreference='Stop'
$project=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$destinationPath=[IO.Path]::GetFullPath($Destination)
if((Test-Path -LiteralPath $destinationPath) -and (Get-ChildItem -LiteralPath $destinationPath -Force | Select-Object -First 1)){throw 'Use an empty destination to prevent stale files entering a release.'}
if(-not $SkipBuild){& (Join-Path $PSScriptRoot 'build.ps1') -CppCompiler $CppCompiler -UseExistingNative:$UseExistingNative}
if(-not $BinaryPath){$BinaryPath=Join-Path $project 'TaskbarControl.exe'}
$customerName='Taskbar Control for Windows'
$publisherName='Taskbar Control Source'
$customer=Join-Path $destinationPath $customerName
$publisher=Join-Path $destinationPath $publisherName
New-Item -ItemType Directory -Path $customer -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $publisher 'source') -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $publisher 'assets') -Force | Out-Null
$documents=@('README.txt','START HERE.txt','CHANGELOG.md','PRIVACY.md','Estimated System Resource Use.txt')
Copy-Item -LiteralPath $BinaryPath -Destination (Join-Path $customer 'TaskbarControl.exe')
foreach($name in $documents){Copy-Item -LiteralPath (Join-Path $project $name) -Destination (Join-Path $customer $name)}
foreach($name in ($documents+@('DEVELOPER.md'))){Copy-Item -LiteralPath (Join-Path $project $name) -Destination (Join-Path $publisher $name)}
$sourceFiles=@('Appearance.cs','AssemblyInfo.cs','Benchmark.cs','BuildIcon.cs','ErrorLog.cs','InstanceActivation.cs','LifecycleTests.cs','MainWindow.cs','ModernControls.cs','PickerTests.cs','TaskbarControl.cs','TaskbarEngine.cs','TaskbarDiagnostics.cs','TaskbarVisual.cpp','VisualHelper.cs','VisualTaskbarPlatform.cs','VisualNativeTests.cpp','Tests.cs','WindowIdentity.cs','WindowPicker.cs','app.manifest','build.ps1','package.ps1','TaskbarControl.ico','TaskbarControl.png')
foreach($name in $sourceFiles){Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination (Join-Path $publisher ('source\'+$name))}
foreach($name in @('Dashboard.cs','DashboardTests.cs','UpdateChecker.cs','AppIconCache.cs','TaskbarVisual.dll')){Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination (Join-Path $publisher ('source\'+$name))}
New-Item -ItemType Directory -Path (Join-Path $publisher 'installer') -Force | Out-Null
foreach($name in @('TaskbarControl.nsi','build-installer.ps1','test-installer.ps1','README.md')){Copy-Item -LiteralPath (Join-Path $project ('installer\'+$name)) -Destination (Join-Path $publisher ('installer\'+$name))}
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'TaskbarControl.png') -Destination (Join-Path $publisher 'assets\TaskbarControl-1024.png')
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'TaskbarControl.ico') -Destination (Join-Path $publisher 'assets\TaskbarControl.ico')
foreach($name in @('Interface-Dark.png','Interface-Light.png','Logo.png')){Copy-Item -LiteralPath (Join-Path $project ('assets\'+$name)) -Destination (Join-Path $publisher ('assets\'+$name))}
$privatePath='(?i)[a-z]:[\\/]+Users[\\/]+[^\\/\s]+'
foreach($package in @($customer,$publisher))
{
    foreach($file in Get-ChildItem -LiteralPath $package -Recurse -File)
    {
        if($file.Extension -in @('.json','.log','.bak','.pdb','.pfx','.pem')){throw ('Private or generated file in package: '+$file.Name)}
        if($file.Extension -notin @('.png','.ico'))
        {
            $bytes=[IO.File]::ReadAllBytes($file.FullName)
            foreach($encoding in @([Text.Encoding]::UTF8,[Text.Encoding]::Unicode)){if($encoding.GetString($bytes) -match $privatePath){throw ('Personal home-directory path in: '+$file.Name)}}
        }
    }
    $hashes=foreach($file in Get-ChildItem -LiteralPath $package -Recurse -File | Sort-Object FullName){'{0}  {1}' -f (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash,$file.FullName.Substring($package.Length+1)}
    [IO.File]::WriteAllLines((Join-Path $package 'SHA256SUMS.txt'),$hashes)
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
foreach($name in @($publisherName)){[IO.Compression.ZipFile]::CreateFromDirectory((Join-Path $destinationPath $name),(Join-Path $destinationPath ($name+'.zip')),[IO.Compression.CompressionLevel]::Optimal,$true)}
if($InstallerCompiler){& (Join-Path $project 'installer\build-installer.ps1') -Compiler $InstallerCompiler -Payload $customer -Output (Join-Path $destinationPath 'Taskbar Control Setup.exe')}
$zipHashes=Get-ChildItem -LiteralPath $destinationPath -File | Where-Object {$_.Extension -in @('.zip','.exe')} | ForEach-Object {'{0}  {1}' -f (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash,$_.Name}
[IO.File]::WriteAllLines((Join-Path $destinationPath 'DOWNLOAD-HASHES.txt'),$zipHashes)
Write-Output 'Installer payload and publisher kit built; allowlists and privacy scans passed.'
