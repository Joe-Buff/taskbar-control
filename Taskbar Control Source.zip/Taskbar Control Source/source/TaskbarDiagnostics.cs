using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TaskbarStyling;

// Reports are read-only. The explicit reconnect button retries normal rule application.
internal static class TaskbarDiagnostics
{
    internal static string Build(Settings settings,TaskbarEngine engine)
    {
        var text=new StringBuilder();var cache=new Dictionary<uint,ProcessIdentity>();
        var ordinary=new HashSet<IntPtr>();Native.EnumWindows(delegate(IntPtr h,IntPtr data){ordinary.Add(h);return true;},IntPtr.Zero);
        var all=Native.TopLevelWindows().Concat(engine==null?new IntPtr[0]:engine.KnownWindows).Distinct().ToList();
        text.AppendLine("TASKBAR CONTROL — WINDOW DIAGNOSTICS");
        text.AppendLine("Version: "+typeof(Program).Assembly.GetName().Version);
        text.AppendLine("OS: "+Environment.OSVersion.VersionString);
        text.AppendLine("Desktop windows: "+ordinary.Count+"; with modern/picked windows: "+all.Count);
        text.AppendLine("Backend: standalone taskbar visuals. No DeleteTab hiding or target-window style changes.");
        text.AppendLine("Visual acknowledgements do not replace a live Alt+Tab check.");
        text.AppendLine("No notification badges are removed or changed by this tool.");
        if(engine!=null)text.AppendLine("Paused: "+engine.Paused+"; last error: "+engine.LastError);
        foreach(var rule in settings.Apps)
        {
            text.AppendLine();text.AppendLine("APP: "+rule.Label+" | Show="+rule.Show);
            text.AppendLine("Rule path: "+rule.Path);text.AppendLine("Rule app identity: "+rule.AppId);
            int found=0;
            foreach(var h in all)
            {
                uint pid;Native.GetWindowThreadProcessId(h,out pid);
                var process=WindowIdentity.Process(pid,cache);WindowTarget target=null;string error=null;
                try{target=WindowIdentity.Resolve(h,cache);}catch(Exception ex){error=ex.Message;}
                // Path/name proximity is reported only. It never broadens hide rules.
                if(!Related(rule,target,process))continue;
                found++;
                text.AppendLine("  HWND="+h.ToInt64().ToString("X")+" PID="+pid+" class="+WindowIdentity.WindowClass(h));
                text.AppendLine("  EnumWindows="+ordinary.Contains(h)+"; eligibility="+Native.EligibilityReason(h));
                text.AppendLine("  ExStyle=0x"+Native.GetWindowLong(h,-20).ToString("X8")+"; owner=0x"+Native.GetWindow(h,4).ToInt64().ToString("X"));
                text.AppendLine("  Process path: "+process.Path+"; process app identity: "+process.AppId);
                text.AppendLine("  Window app identity: "+WindowIdentity.WindowAppId(h));
                text.AppendLine("  Resolved app identity: "+(target==null?"unresolved":target.AppId));
                text.AppendLine("  Rule matches: "+rule.Matches(target)+(error==null?"":"; lookup error: "+error));
                if(engine!=null)text.AppendLine("  "+engine.Outcome(h));
            }
            if(found==0)text.AppendLine("  No related window was discovered on this desktop.");
        }
        return Redact(text.ToString());
    }
    static bool Related(AppRule rule,WindowTarget target,ProcessIdentity process)
    {
        if(rule.Matches(target))return true;
        if(!String.IsNullOrEmpty(rule.Path))
        {
            string file=Path.GetFileName(rule.Path);
            if(String.Equals(file,Path.GetFileName(process.Path??""),StringComparison.OrdinalIgnoreCase))return true;
            if(target!=null&&String.Equals(file,Path.GetFileName(target.Path??""),StringComparison.OrdinalIgnoreCase))return true;
        }
        if(!String.IsNullOrEmpty(rule.AppId))
        {
            string family=rule.AppId.Split('!')[0]+"!";
            if((process.AppId??"").StartsWith(family,StringComparison.OrdinalIgnoreCase))return true;
            if(target!=null&&(target.AppId??"").StartsWith(family,StringComparison.OrdinalIgnoreCase))return true;
        }
        return false;
    }
    internal static string Redact(string value)
    {
        string home=Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        if(!String.IsNullOrEmpty(home))value=System.Text.RegularExpressions.Regex.Replace(value,System.Text.RegularExpressions.Regex.Escape(home),"%USERPROFILE%",System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        return System.Text.RegularExpressions.Regex.Replace(value,@"(?i)[a-z]:\\Users\\[^\\\r\n]+","%USERPROFILE%");
    }
    internal static void Show(IWin32Window owner,Settings settings,TaskbarEngine engine)
    {
        using(var form=new Form{Text="Taskbar Control diagnostics",ClientSize=new Size(950,630),StartPosition=FormStartPosition.CenterParent,Font=new Font("Segoe UI",10),Padding=new Padding(18),MinimizeBox=false})
        {
            var report=new TextBox{Multiline=true,ReadOnly=true,Dock=DockStyle.Fill,ScrollBars=ScrollBars.Both,WordWrap=false,Font=new Font("Consolas",10),Text=Build(settings,engine)};
            var actions=new FlowLayoutPanel{Dock=DockStyle.Bottom,Height=48,Padding=new Padding(0,10,0,0)};
            var refresh=new FlatButton{Text="Refresh"};refresh.Click+=delegate{report.Text=Build(settings,engine);report.SelectionStart=0;report.SelectionLength=0;};
            var reconnect=new FlatButton{Text="Reconnect taskbar"};reconnect.Click+=delegate{if(engine!=null)engine.ExplorerRestarted();report.Text=Build(settings,engine);};
            var copy=new FlatButton{Text="Copy report"};copy.Click+=delegate{try{Clipboard.SetText(report.Text);}catch(Exception ex){ModernMessage.ShowError(form,"Could not copy the report.",ex.Message);}};
            var save=new FlatButton{Text="Save report…"};save.Click+=delegate{using(var file=new SaveFileDialog{Filter="Text report (*.txt)|*.txt",FileName="Taskbar Control diagnostics.txt"})if(file.ShowDialog(form)==DialogResult.OK)try{File.WriteAllText(file.FileName,report.Text);}catch(Exception ex){ModernMessage.ShowError(form,"Could not save the report.",ex.Message);}};
            actions.Controls.AddRange(new Control[]{refresh,reconnect,copy,save});form.Controls.Add(report);form.Controls.Add(actions);Theme.Paint(form);form.Shown+=delegate{Theme.Frame(form.Handle);report.SelectionStart=0;report.SelectionLength=0;refresh.Focus();};form.ShowDialog(owner);
        }
    }
}
