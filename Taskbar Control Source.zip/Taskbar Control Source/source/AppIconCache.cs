using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

// Loads only icons for rows actually painted. No folder scan or shell lookup on the UI thread.
internal sealed class AppIconCache : IDisposable
{
    readonly Control owner;
    readonly Dictionary<string,Bitmap> icons=new Dictionary<string,Bitmap>(StringComparer.OrdinalIgnoreCase);
    readonly HashSet<string> attempted=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
    readonly Queue<string> queue=new Queue<string>();
    bool busy,disposed;
    internal AppIconCache(Control control){owner=control;}
    internal int Count {get{return icons.Count;}}
    internal Bitmap Get(string path)
    {
        if(disposed||String.IsNullOrEmpty(path))return null;
        Bitmap icon;if(icons.TryGetValue(path,out icon))return icon;
        // Avoid network shares and keep the tray utility's cache bounded.
        if(attempted.Count<256&&Path.IsPathRooted(path)&&!path.StartsWith(@"\\")&&attempted.Add(path)){queue.Enqueue(path);Next();}
        return null;
    }
    async void Next()
    {
        if(busy||disposed||queue.Count==0)return;busy=true;string path=queue.Dequeue();
        Bitmap bitmap=await Task.Run(()=>
        {
            try
            {
                var drive=new DriveInfo(Path.GetPathRoot(path));if(drive.DriveType!=DriveType.Fixed||!File.Exists(path))return null;
                using(var icon=Icon.ExtractAssociatedIcon(path)){return icon==null?null:icon.ToBitmap();}
            }
            catch{return null;}
        });
        if(disposed){if(bitmap!=null)bitmap.Dispose();return;}
        if(bitmap!=null)icons[path]=bitmap;busy=false;if(!owner.IsDisposed)owner.Invalidate();Next();
    }
    public void Dispose(){disposed=true;queue.Clear();foreach(var bitmap in icons.Values)bitmap.Dispose();icons.Clear();}
}
