using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
class BuildIcon
{
    static GraphicsPath Round(float x,float y,float w,float h,float radius)
    {var p=new GraphicsPath();float d=radius*2;p.AddArc(x,y,d,d,180,90);p.AddArc(x+w-d,y,d,d,270,90);p.AddArc(x+w-d,y+h-d,d,d,0,90);p.AddArc(x,y+h-d,d,d,90,90);p.CloseFigure();return p;}
    static Bitmap Render(int size)
    {
        using(var b=new Bitmap(size*4,size*4))
        {
            using(var g=Graphics.FromImage(b))
            {
                g.SmoothingMode=SmoothingMode.AntiAlias;g.ScaleTransform(size*4/256f,size*4/256f);
                using(var p=Round(6,6,244,244,54))using(var brush=new SolidBrush(Color.FromArgb(17,17,17)))g.FillPath(brush,p);
                using(var p=Round(8,8,240,240,52))using(var pen=new Pen(Color.FromArgb(63,63,63),2))g.DrawPath(pen,p);
                using(var p=Round(31,87,194,82,18))using(var pen=new Pen(Color.FromArgb(235,235,235),size<32?8:5))g.DrawPath(pen,p);
                foreach(float x in new[]{51f,107f})using(var p=Round(x,110,36,36,7))using(var brush=new SolidBrush(Color.FromArgb(240,240,240)))g.FillPath(brush,p);
                using(var p=Round(163,110,36,36,7))using(var pen=new Pen(Color.FromArgb(110,110,110),3))g.DrawPath(pen,p);
                using(var pen=new Pen(Color.White,6)){pen.StartCap=LineCap.Round;pen.EndCap=LineCap.Round;g.DrawLine(pen,172,128,190,128);}
            }
            var final=new Bitmap(size,size);using(var g=Graphics.FromImage(final)){g.InterpolationMode=InterpolationMode.HighQualityBicubic;g.PixelOffsetMode=PixelOffsetMode.HighQuality;g.DrawImage(b,0,0,size,size);}return final;
        }
    }
    static void Main(string[] args)
    {
        int[] sizes={16,20,24,32,40,48,64,96,128,256};var images=new byte[sizes.Length][];
        for(int i=0;i<sizes.Length;i++)using(var bitmap=Render(sizes[i]))using(var stream=new MemoryStream()){bitmap.Save(stream,ImageFormat.Png);images[i]=stream.ToArray();}
        using(var w=new BinaryWriter(File.Create(args[0])))
        {
            w.Write((ushort)0);w.Write((ushort)1);w.Write((ushort)sizes.Length);int offset=6+16*sizes.Length;
            for(int i=0;i<sizes.Length;i++){w.Write((byte)(sizes[i]==256?0:sizes[i]));w.Write((byte)(sizes[i]==256?0:sizes[i]));w.Write((byte)0);w.Write((byte)0);w.Write((ushort)1);w.Write((ushort)32);w.Write(images[i].Length);w.Write(offset);offset+=images[i].Length;}foreach(var image in images)w.Write(image);
        }
        using(var bitmap=Render(1024))bitmap.Save(Path.ChangeExtension(args[0],".png"),ImageFormat.Png);
        using(var bitmap=Render(256))bitmap.Save(Path.ChangeExtension(args[0],".preview.png"),ImageFormat.Png);
    }
}
