using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using TaskbarStyling;

internal sealed partial class MainForm : Form
{
    readonly Settings settings;
    readonly string config;
    readonly TaskbarEngine engine;
    readonly bool testing;
    readonly BufferedAppGrid list=new BufferedAppGrid();
    readonly ModernTextField search=new ModernTextField{Placeholder="Search your apps…"};
    readonly ModernCombo themeChoice=new ModernCombo();
    readonly ModernToggle startup=new ModernToggle{Text="Start with Windows",AutoSize=true};
    readonly ModernToggle paused=new ModernToggle{Text="Pause hiding",AutoSize=true};
    readonly ModernToggle onlyHidden=new ModernToggle{Text="Only hidden apps",AutoSize=true};
    readonly ModernToggle hideOwn=new ModernToggle{Text="Hide my taskbar icon",AutoSize=true};
    readonly Label summary=new Label(),empty=new Label();
    readonly ErrorLog errorLog=new ErrorLog();
    readonly NotifyIcon tray=new NotifyIcon();
    readonly FlatButton scanButton=new FlatButton{Text="Rescan folders"};
    readonly System.Windows.Forms.Timer statusTimer=new System.Windows.Forms.Timer{Interval=1000};
    readonly uint taskbarCreated=Native.RegisterWindowMessage("TaskbarCreated");
    readonly ToolTip tips=new ToolTip();
    AppIconCache appIcons;
    readonly Font appNameFont=Theme.Medium(10.25f),pathFont=Theme.Body(9.5f);
    WindowPicker picker;
    CancellationTokenSource scanCancel;
    bool filling,exiting,opening;
    string displayedEngineError="";
    internal MainForm(Settings value,string file,bool startHidden,bool test=false,ITaskbarPlatform testPlatform=null)
    {
        settings=value;config=file;testing=test;Theme.Light=settings.ThemeMode=="light";
        engine=new TaskbarEngine(false,test?(testPlatform??new InactiveTaskbarPlatform()):null);
        Text="Taskbar Control";Icon=Icon.ExtractAssociatedIcon(Application.ExecutablePath)??SystemIcons.Application;
        Font=Theme.Body(10.25f);BackColor=Theme.Background;ForeColor=Theme.Text;DoubleBuffered=true;SetStyle(ControlStyles.ResizeRedraw,true);
        appIcons=new AppIconCache(list);BuildDashboard();
        var menu=new ContextMenuStrip{Renderer=new ToolStripProfessionalRenderer(new MonochromeMenuColors()),ShowImageMargin=false};menu.Items.Add("Open Taskbar Control",null,delegate{OpenWindow();});
        var ownMenu=new ToolStripMenuItem("Hide my taskbar icon"){Checked=hideOwn.Checked};ownMenu.Click+=delegate{hideOwn.Checked=!hideOwn.Checked;};hideOwn.CheckedChanged+=delegate{ownMenu.Checked=hideOwn.Checked;};menu.Items.Add(ownMenu);
        menu.Items.Add("Pause / resume hiding",null,delegate{paused.Checked=!paused.Checked;});menu.Items.Add("Show all apps",null,delegate{ShowAll(null,EventArgs.Empty);});menu.Items.Add(new ToolStripSeparator());menu.Items.Add("Exit and restore taskbar buttons",null,delegate{exiting=true;Close();});
        tray.Icon=Icon;tray.Text="Taskbar Control";tray.ContextMenuStrip=menu;tray.Visible=!testing;tray.DoubleClick+=delegate{OpenWindow();};ShowInTaskbar=!settings.HideOwnTaskbar;
        ApplyTheme();engine.Rules(settings.Apps);RefreshList();
        FormClosing+=delegate(object sender,FormClosingEventArgs e){if(!exiting&&e.CloseReason==CloseReason.UserClosing){e.Cancel=true;Hide();return;}if(scanCancel!=null)scanCancel.Cancel();if(picker!=null)picker.Dispose();if(updateCancel!=null)updateCancel.Cancel();statusTimer.Stop();statusTimer.Dispose();engine.Dispose();appIcons.Dispose();appNameFont.Dispose();pathFont.Dispose();tips.Dispose();tray.Visible=false;tray.Dispose();};
        engine.ErrorChanged+=delegate(string message){errorLog.Report(message);};
        statusTimer.Tick+=delegate{UpdateSummary();};VisibleChanged+=delegate{statusTimer.Enabled=Visible;};
        Shown+=delegate{if(!testing)StartupChanged(this,EventArgs.Empty);if(startHidden)Hide();};
    }
    static FlowLayoutPanel Flow(){return new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false,Margin=new Padding(0)};}
    FlatButton Button(string text,EventHandler action){var button=new FlatButton{Text=text};button.Click+=action;return button;}
    void ApplyTheme()
    {
        Theme.Light=themeChoice.SelectedIndex==1;BackColor=Theme.Background;Theme.Paint(this);TintHints(this);summary.ForeColor=empty.ForeColor=Theme.Muted;errorLog.ApplyTheme();
        list.BackgroundColor=Theme.Surface;list.BorderStyle=BorderStyle.None;list.EnableHeadersVisualStyles=false;list.ColumnHeadersDefaultCellStyle.BackColor=Theme.Surface;list.ColumnHeadersDefaultCellStyle.ForeColor=Theme.Muted;list.DefaultCellStyle.BackColor=Theme.AppRow;list.DefaultCellStyle.ForeColor=Theme.Text;list.DefaultCellStyle.SelectionBackColor=Theme.Selected;list.DefaultCellStyle.SelectionForeColor=Theme.Text;list.GridColor=Theme.Surface;list.ColumnHeadersBorderStyle=DataGridViewHeaderBorderStyle.None;list.CellBorderStyle=DataGridViewCellBorderStyle.None;
        list.Columns[2].DefaultCellStyle.ForeColor=Theme.Muted;list.Columns[2].DefaultCellStyle.Font=pathFont;list.DefaultCellStyle.Padding=new Padding(9,3,9,3);empty.BackColor=Theme.Surface;
        if(tray.ContextMenuStrip!=null){tray.ContextMenuStrip.BackColor=Theme.Surface;tray.ContextMenuStrip.ForeColor=Theme.Text;foreach(ToolStripItem item in tray.ContextMenuStrip.Items)item.ForeColor=Theme.Text;}
        if(IsHandleCreated)Theme.Frame(Handle);Invalidate(true);
    }
    void TintHints(Control parent){foreach(Control child in parent.Controls){if((child.Tag as string)=="muted")child.ForeColor=Theme.Muted;TintHints(child);}}
    protected override bool ShowWithoutActivation {get{return testing;}}
    protected override void OnHandleCreated(EventArgs e){base.OnHandleCreated(e);Theme.Frame(Handle);}
    protected override void WndProc(ref Message message)
    {
        // Hide before Windows can create a minimized caption on the desktop.
        if(message.Msg==0x112&&(message.WParam.ToInt64()&0xfff0)==0xf020){Hide();return;}
        if((uint)message.Msg==taskbarCreated&&engine!=null)engine.ExplorerRestarted();
        base.WndProc(ref message);
    }
    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);
        // Covers programmatic minimize / Show Desktop as well as the title button.
        if(!opening&&WindowState==FormWindowState.Minimized)Hide();
        else Invalidate(true);
    }
    void PaintCell(object sender,DataGridViewCellPaintingEventArgs e)
    {
        if(e.RowIndex<0||e.ColumnIndex<0)return;
        var saved=e.Graphics.Save();
        try
        {
            e.Graphics.SetClip(Rectangle.Intersect(e.CellBounds,e.ClipBounds),System.Drawing.Drawing2D.CombineMode.Intersect);
            using(var background=new SolidBrush(Theme.Surface))e.Graphics.FillRectangle(background,e.CellBounds);
            var row=list.GetRowDisplayRectangle(e.RowIndex,false);row.Y+=4;row.Height-=8;
            e.Graphics.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            if(Theme.Light)row.Inflate(-1,0);
            using(var shape=ModernPaint.Round(row,12))
            {
                using(var fill=new SolidBrush(list.Rows[e.RowIndex].Selected?Theme.Selected:e.RowIndex==hoveredRow?Theme.Hover:Theme.AppRow))e.Graphics.FillPath(fill,shape);
                if(Theme.Light)using(var edge=new Pen(Theme.CardEdge,list.Rows[e.RowIndex].Selected?2f:1.5f))e.Graphics.DrawPath(edge,shape);
            }
            if(e.ColumnIndex==0)
                ModernPaint.Toggle(e.Graphics,new Rectangle(e.CellBounds.X+(e.CellBounds.Width-34)/2,e.CellBounds.Y+(e.CellBounds.Height-20)/2,34,20),Convert.ToBoolean(e.Value),list.Enabled);
            else if(e.ColumnIndex==1)
            {
                var tile=new Rectangle(e.CellBounds.X+9,e.CellBounds.Y+(e.CellBounds.Height-30)/2,30,30);
                var rule=list.Rows[e.RowIndex].Tag as AppRule;var icon=appIcons.Get(rule==null?null:rule.Path);
                if(icon!=null)e.Graphics.DrawImage(icon,new Rectangle(tile.X+3,tile.Y+3,24,24));
                else ModernPaint.Monitor(e.Graphics,new Rectangle(tile.X+5,tile.Y+5,20,20),Theme.Muted);
                string name=Convert.ToString(e.Value);
                TextRenderer.DrawText(e.Graphics,name,appNameFont,new Rectangle(tile.Right+10,e.CellBounds.Y,e.CellBounds.Width-52,e.CellBounds.Height),Theme.Text,TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPrefix);
            }
            else e.Paint(e.ClipBounds,DataGridViewPaintParts.ContentForeground);
        }
        finally{e.Graphics.Restore(saved);}
        e.Handled=true;
    }
    internal void OpenWindow()
    {
        if(exiting||IsDisposed)return;
        // Cancel through the picker's safe gesture cleanup, not by disposing it.
        if(picker!=null){picker.CancelSelection();return;}
        opening=true;
        try
        {
            // WinForms can retain a native minimized placement while hidden.
            // Show first, then restore, without letting OnResize hide it again.
            Show();if(WindowState==FormWindowState.Minimized)WindowState=FormWindowState.Normal;
            var titleArea=new Rectangle(Location,new Size(Width,Math.Min(48,Height)));
            if(!testing&&!Screen.AllScreens.Any(s=>s.WorkingArea.IntersectsWith(titleArea)))
            {
                WindowState=FormWindowState.Normal;var area=Screen.PrimaryScreen.WorkingArea;
                Location=new Point(area.Left+Math.Max(0,(area.Width-Width)/2),area.Top+Math.Max(0,(area.Height-Height)/2));
            }
            if(!testing)InstanceActivation.Focus(this);UpdateSummary();
        }
        finally{opening=false;}
    }
    void UpdateSummary()
    {
        summary.Text=String.Format("{0} apps  ·  {1} hidden rules  ·  {2} taskbar buttons hidden",settings.Apps.Count,settings.Apps.Count(a=>!a.Show&&a.CanManage),engine.Count);
        UpdateDashboardStats();
        if(!String.IsNullOrEmpty(engine.LastError)&&displayedEngineError!=engine.LastError)errorLog.Report(engine.LastError);
        displayedEngineError=engine.LastError;
    }
    void RefreshList()
    {
        filling=true;list.Rows.Clear();string query=search.Text.Trim();
        foreach(var app in settings.Apps.Where(a=>(!onlyHidden.Checked||!a.Show)&&((a.Label??"")+" "+(a.Path??"")+" "+(a.AppId??"")).IndexOf(query,StringComparison.OrdinalIgnoreCase)>=0).OrderBy(a=>a.Label,StringComparer.OrdinalIgnoreCase))
        {
            int index=list.Rows.Add(app.Show,app.Label,app.CanManage?(!String.IsNullOrEmpty(app.Path)?app.Path:app.AppId):"Shared Windows host — pick the app window again");list.Rows[index].Tag=app;
            list.Rows[index].Cells[0].ReadOnly=!app.CanManage;
            list.Rows[index].Cells[2].ToolTipText=(app.Path??"")+(String.IsNullOrEmpty(app.AppId)?"":"\nApp identity: "+app.AppId);
        }
        filling=false;empty.Visible=list.Rows.Count==0;empty.Text=settings.Apps.Count==0?"Add an app, or pick its window to hide its taskbar button.":"No apps match this search.";if(empty.Visible)empty.BringToFront();UpdateSummary();
    }
    bool Save(){try{settings.Save(config);return true;}catch(Exception ex){Error("Could not save settings. Changes remain active for this session.\n\n"+ErrorHelp.Technical(ex));return false;}}
    void Error(string message){errorLog.Report(message);}
    void ItemChecked(object sender,DataGridViewCellEventArgs e)
    {
        if(filling||e.RowIndex<0||e.ColumnIndex!=0)return;var rule=list.Rows[e.RowIndex].Tag as AppRule;if(rule==null)return;
        rule.Show=Convert.ToBoolean(list.Rows[e.RowIndex].Cells[0].Value);Save();engine.Rules(settings.Apps);UpdateSummary();
        if(onlyHidden.Checked&&IsHandleCreated)BeginInvoke((Action)RefreshList);
    }
    int Merge(IEnumerable<string> files)
    {
        var known=new HashSet<string>(settings.Apps.Where(a=>!String.IsNullOrEmpty(a.Path)).Select(a=>a.Path),StringComparer.OrdinalIgnoreCase);int count=0;
        foreach(string path in files)if(known.Add(path)){settings.Apps.Add(new AppRule(path));count++;}Save();RefreshList();return count;
    }
    AppRule MergeTarget(WindowTarget target,bool hide)
    {
        var matches=settings.Apps.Where(a=>a.Matches(target)).ToList();var rule=matches.FirstOrDefault(a=>!String.IsNullOrEmpty(a.AppId))??matches.FirstOrDefault();
        if(rule==null){rule=new AppRule(target);settings.Apps.Add(rule);}else{rule.Path=target.Path;rule.AppId=target.AppId;rule.Name=target.Name;}
        if(matches.Count>0)rule.Show=matches.All(a=>a.Show);foreach(var duplicate in matches.Where(a=>a!=rule))settings.Apps.Remove(duplicate);
        if(hide)rule.Show=false;return rule;
    }
    void AddExecutable(object sender,EventArgs e){using(var dialog=new OpenFileDialog{Filter="Applications (*.exe)|*.exe",Multiselect=true,Title="Choose applications"})if(dialog.ShowDialog(this)==DialogResult.OK)Merge(dialog.FileNames);}
    void PickWindow(object sender,EventArgs e)
    {
        if(picker!=null)return;tray.Text="Select an app window. Escape cancels.";Hide();picker=new WindowPicker(PickedWindow);
        try{picker.Show();}catch(Exception ex){picker.Dispose();picker=null;OpenWindow();Error("Could not start window selection: "+ErrorHelp.Technical(ex));}
    }
    void PickedWindow(WindowTarget target)
    {
        picker=null;if(IsDisposed||exiting)return;
        if(target==null){EndPick(null);return;}
        if(target.OwnerPid==(uint)Process.GetCurrentProcess().Id || String.Equals(target.Path,Application.ExecutablePath,StringComparison.OrdinalIgnoreCase)){EndPick("Use Hide my taskbar icon to control Taskbar Control itself.");return;}
        var rule=MergeTarget(target,true);Save();engine.Rules(settings.Apps);engine.RememberPickedWindow(target);onlyHidden.Checked=false;search.Text=rule.Label;RefreshList();
        EndPick(engine.LastError);
    }
    void EndPick(string message){tray.Text="Taskbar Control";OpenWindow();if(!String.IsNullOrEmpty(message))Error(message);}
    async void AddFolder(object sender,EventArgs e)
    {
        using(var dialog=new FolderBrowserDialog{Description="Scan this folder and its subfolders for applications",ShowNewFolderButton=false})if(dialog.ShowDialog(this)==DialogResult.OK)
        {if(!settings.Folders.Contains(dialog.SelectedPath,StringComparer.OrdinalIgnoreCase))settings.Folders.Add(dialog.SelectedPath);Save();if(scanCancel==null)await Scan();}
    }
    async Task Scan()
    {
        if(settings.Folders.Count==0)return;scanCancel=new CancellationTokenSource();var token=scanCancel.Token;var roots=settings.Folders.ToArray();scanButton.Text="Cancel scan";
        try{int skipped=0;var files=await Task.Run(()=>Scanner.Scan(roots,token,out skipped));if(!IsDisposed&&!token.IsCancellationRequested)Merge(files);}
        catch(OperationCanceledException){}
        catch(Exception ex){if(!IsDisposed)Error("Scan failed: "+ErrorHelp.Technical(ex));}
        finally{scanCancel.Dispose();scanCancel=null;if(!IsDisposed)scanButton.Text="Rescan folders";}
    }
    void ManageFolders(object sender,EventArgs e)
    {
        using(var dialog=new Form{Text="Saved folders",ClientSize=new Size(720,370),StartPosition=FormStartPosition.CenterParent,Font=Font,MinimizeBox=false,MaximizeBox=false,BackColor=Theme.Background,ForeColor=Theme.Text,Icon=Icon,Padding=new Padding(20)})
        {
            var folders=new ModernList{Dock=DockStyle.Fill,HorizontalScrollbar=true,BorderStyle=BorderStyle.None,Placeholder="No saved scan folders"};folders.Items.AddRange(settings.Folders.ToArray());
            var remove=Button("Remove selected folder",delegate{if(folders.SelectedItem!=null){settings.Folders.Remove((string)folders.SelectedItem);folders.Items.Remove(folders.SelectedItem);Save();}});var bottom=Flow();bottom.Dock=DockStyle.Bottom;bottom.Height=48;bottom.Padding=new Padding(0,10,0,0);bottom.Controls.Add(remove);bottom.Controls.Add(new Label{Text="Existing app rules are kept.",AutoSize=true,Padding=new Padding(0,8,0,0)});
            dialog.Controls.Add(folders);dialog.Controls.Add(bottom);Theme.Paint(dialog);dialog.Shown+=delegate{Theme.Frame(dialog.Handle);};dialog.ShowDialog(this);
        }
    }
    void AddRunning(object sender,EventArgs e)
    {
        var cache=new Dictionary<uint,ProcessIdentity>();
        foreach(var h in Native.TopLevelWindows())if(Native.Eligible(h)){var target=WindowIdentity.Resolve(h,cache);if(target!=null&&target.OwnerPid!=(uint)Process.GetCurrentProcess().Id)MergeTarget(target,false);}
        Save();engine.Rules(settings.Apps);RefreshList();
    }
    void RemoveSelected(object sender,EventArgs e){foreach(DataGridViewRow row in list.SelectedRows)settings.Apps.Remove((AppRule)row.Tag);Save();engine.Rules(settings.Apps);RefreshList();}
    void ShowAll(object sender,EventArgs e){foreach(var app in settings.Apps)app.Show=true;Save();engine.Rules(settings.Apps);RefreshList();}
    void StartupChanged(object sender,EventArgs e)
    {
        try
        {
            if(!testing)using(var key=Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run")){string command="\""+Application.ExecutablePath+"\" --tray";if(startup.Checked){if(!String.Equals(key.GetValue("TaskbarControl") as string,command,StringComparison.OrdinalIgnoreCase))key.SetValue("TaskbarControl",command);}else key.DeleteValue("TaskbarControl",false);}
            if(settings.StartupEnabled!=startup.Checked){settings.StartupEnabled=startup.Checked;Save();}
        }
        catch(Exception ex){startup.CheckedChanged-=StartupChanged;startup.Checked=false;startup.CheckedChanged+=StartupChanged;Error("Windows startup could not be configured.\n\n"+ErrorHelp.Technical(ex));}
    }
    internal void ExitAndRestore(){exiting=true;Close();}
    internal void TestExit(){ExitAndRestore();}
    internal void TestTheme(bool light){themeChoice.SelectedIndex=light?1:0;}
    internal void TestPick(WindowTarget target){PickedWindow(target);}
    internal void TestAdd(string path){Merge(new[]{path});}
    internal void TestCancelPicker(){PickWindow(this,EventArgs.Empty);picker.CancelSelection();}
    internal bool TestPickerClosed {get{return picker==null;}}
    internal DataGridView TestGrid {get{return list;}}
    internal CheckBox TestStartup {get{return startup;}}
    internal CheckBox TestOwn {get{return hideOwn;}}
    internal CheckBox TestPaused {get{return paused;}}
    internal bool TestTrayConfigured {get{return tray.Icon!=null&&tray.ContextMenuStrip!=null;}}
    internal int TestIconCount {get{return appIcons.Count;}}
    internal bool TestTrayVisible {get{return tray.Visible;}}
    internal ErrorLog TestErrors {get{return errorLog;}}
}
