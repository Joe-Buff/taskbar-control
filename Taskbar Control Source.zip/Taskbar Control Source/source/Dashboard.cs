using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using TaskbarStyling;

internal sealed partial class MainForm
{
    readonly TableLayoutPanel shell=new TableLayoutPanel();
    readonly Panel pages=new Panel();
    readonly Panel appsPage=new Panel(),foldersPage=new Panel(),settingsPage=new Panel(),activityPage=new Panel();
    readonly DashboardNav[] nav={new DashboardNav("Apps","apps"),new DashboardNav("Folders","folders"),new DashboardNav("Activity","activity"),new DashboardNav("Settings","settings")};
    readonly DashboardNav collapse=new DashboardNav("Collapse","menu");
    readonly Label pageTitle=new Label(),pageHint=new Label();
    readonly FlowLayoutPanel bottomOptions=Flow();
    readonly Label latestError=new Label();
    readonly StatTile tracked=new StatTile("Apps in your list"),hidden=new StatTile("Set to hidden"),visible=new StatTile("Set to visible");
    int hoveredRow=-1;
    readonly FlatButton checkUpdate=new FlatButton{Text="Check for updates",Primary=true};
    readonly FlatButton cancelUpdate=new FlatButton{Text="Cancel",Visible=false};
    readonly Label updateStatus=new Label();
    readonly Label folderInfo=new Label();
    bool sidebarExpanded=true;
    CancellationTokenSource updateCancel;
    internal string TestPage {get{return pageTitle.Text;}}
    internal void TestNavigate(int index){Navigate(index);}
    internal void TestSidebar(){ToggleSidebar();}
    internal bool TestUpdateBusy {get{return updateCancel!=null;}}

    void BuildDashboard()
    {
        ClientSize=new Size(1240,850);MinimumSize=new Size(1060,720);StartPosition=FormStartPosition.CenterScreen;
        AutoScaleMode=AutoScaleMode.Font;
        shell.Dock=DockStyle.Fill;shell.Padding=new Padding(16);shell.Margin=new Padding(0);shell.ColumnCount=2;shell.RowCount=1;
        shell.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,184));shell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));shell.RowStyles.Add(new RowStyle(SizeType.Percent,100));Controls.Add(shell);
        var sidebar=new SoftCard{Dock=DockStyle.Fill,Margin=new Padding(0,0,16,0),Padding=new Padding(12,18,12,18)};
        shell.Controls.Add(sidebar,0,0);
        var navigation=new TableLayoutPanel{Dock=DockStyle.Fill,RowCount=8,ColumnCount=1,Margin=new Padding(0)};
        // A default AutoSize column retains Button's preferred width even when
        // collapsed. An explicit percentage column stays inside the sidebar.
        navigation.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
        navigation.RowStyles.Add(new RowStyle(SizeType.Absolute,64));for(int i=0;i<3;i++)navigation.RowStyles.Add(new RowStyle(SizeType.Absolute,54));navigation.RowStyles.Add(new RowStyle(SizeType.Percent,100));navigation.RowStyles.Add(new RowStyle(SizeType.Absolute,54));navigation.RowStyles.Add(new RowStyle(SizeType.Absolute,54));navigation.RowStyles.Add(new RowStyle(SizeType.Absolute,6));sidebar.Controls.Add(navigation);
        var mark=new PictureBox{Dock=DockStyle.Left,Width=42,SizeMode=PictureBoxSizeMode.Zoom,Margin=new Padding(4,0,0,16)};
        using(var stream=System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("TaskbarControl.Brand.png"))using(var source=Image.FromStream(stream))mark.Image=new Bitmap(source,80,80);
        mark.Disposed+=delegate{if(mark.Image!=null)mark.Image.Dispose();};navigation.Controls.Add(mark,0,0);
        for(int i=0;i<nav.Length;i++){int index=i;nav[i].Dock=DockStyle.Fill;nav[i].Margin=new Padding(0,4,0,4);nav[i].Click+=delegate{Navigate(index);};tips.SetToolTip(nav[i],nav[i].Text);navigation.Controls.Add(nav[i],0,i==3?5:i+1);}
        collapse.Dock=DockStyle.Fill;collapse.Margin=new Padding(0,4,0,4);collapse.Click+=delegate{ToggleSidebar();};tips.SetToolTip(collapse,"Expand or collapse the sidebar");navigation.Controls.Add(collapse,0,6);
        var main=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,Margin=new Padding(6,0,0,0)};
        main.RowStyles.Add(new RowStyle(SizeType.Absolute,102));main.RowStyles.Add(new RowStyle(SizeType.Percent,100));main.RowStyles.Add(new RowStyle(SizeType.Absolute,112));shell.Controls.Add(main,1,0);
        var heading=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=2,Margin=new Padding(0)};heading.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));heading.RowStyles.Add(new RowStyle(SizeType.Absolute,57));heading.RowStyles.Add(new RowStyle(SizeType.Percent,100));
        pageTitle.Font=Theme.Heading(23);pageTitle.Dock=DockStyle.Fill;pageTitle.Margin=new Padding(0,9,0,0);heading.Controls.Add(pageTitle,0,0);
        pageHint.Dock=DockStyle.Fill;pageHint.Tag="muted";pageHint.Margin=new Padding(2,3,0,0);heading.Controls.Add(pageHint,0,1);main.Controls.Add(heading,0,0);
        pages.Dock=DockStyle.Fill;pages.Margin=new Padding(0);main.Controls.Add(pages,0,1);
        foreach(var page in new[]{appsPage,foldersPage,activityPage,settingsPage}){page.Dock=DockStyle.Fill;pages.Controls.Add(page);}
        var footer=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,RowCount=1,Margin=new Padding(0),Padding=new Padding(0,10,0,0)};
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,480));footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));main.Controls.Add(footer,0,2);
        var footerLeft=new Panel{Dock=DockStyle.Fill,Padding=new Padding(2,0,12,0),Margin=new Padding(0)};footer.Controls.Add(footerLeft,0,0);
        summary.AutoSize=false;summary.Dock=DockStyle.Bottom;summary.Height=48;summary.Tag="muted";summary.Padding=new Padding(0,9,0,0);footerLeft.Controls.Add(summary);
        bottomOptions.Dock=DockStyle.Top;bottomOptions.Height=42;footerLeft.Controls.Add(bottomOptions);
        var errorPreview=new SoftCard{Dock=DockStyle.Fill,Padding=new Padding(16,10,16,10),Margin=new Padding(0)};footer.Controls.Add(errorPreview,1,0);
        latestError.Dock=DockStyle.Fill;latestError.Text="No errors to report.";latestError.Tag="muted";latestError.AccessibleName="Latest error and suggested fix";latestError.Cursor=Cursors.Hand;latestError.Click+=delegate{Navigate(2);};errorPreview.Controls.Add(latestError);
        errorPreview.Controls.Add(new Label{Text="ERROR LOG",Dock=DockStyle.Top,Height=24,Font=Theme.Medium(9.25f),Tag="muted"});
        errorLog.Changed+=UpdateErrorPreview;
        BuildApps();BuildFolders();BuildActivity();BuildSettings();Navigate(0);
    }
    void BuildApps()
    {
        var body=new TableLayoutPanel{Dock=DockStyle.Fill,RowCount=2,ColumnCount=1,Margin=new Padding(0)};body.RowStyles.Add(new RowStyle(SizeType.Absolute,106));body.RowStyles.Add(new RowStyle(SizeType.Percent,100));appsPage.Controls.Add(body);
        var stats=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=3,RowCount=1,Margin=new Padding(0,0,0,16)};
        foreach(var tile in new[]{tracked,hidden,visible}){stats.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,33.333f));tile.Dock=DockStyle.Fill;tile.Margin=new Padding(0,0,12,0);stats.Controls.Add(tile);}visible.Margin=new Padding(0);body.Controls.Add(stats,0,0);
        var card=new SoftCard{Dock=DockStyle.Fill,Padding=new Padding(16),Margin=new Padding(0)};body.Controls.Add(card,0,1);
        var content=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=4,Margin=new Padding(0)};content.RowStyles.Add(new RowStyle(SizeType.Absolute,50));content.RowStyles.Add(new RowStyle(SizeType.Absolute,52));content.RowStyles.Add(new RowStyle(SizeType.Percent,100));content.RowStyles.Add(new RowStyle(SizeType.Absolute,30));card.Controls.Add(content);
        var actions=Flow();var pick=Button("Pick a window",PickWindow);pick.Primary=true;actions.Controls.Add(pick);actions.Controls.Add(Button("Add executable…",AddExecutable));actions.Controls.Add(Button("Add running apps",AddRunning));content.Controls.Add(actions,0,0);
        tips.SetToolTip(pick,"Select a window to hide its taskbar button. The app stays open and available in Alt+Tab. Escape cancels.");
        var filters=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,Margin=new Padding(0)};filters.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));filters.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,196));
        search.Dock=DockStyle.Top;search.AccessibleName="Search apps or executable paths";search.TextChanged+=delegate{RefreshList();};tips.SetToolTip(search,"Search by app name, executable path, or app identity");filters.Controls.Add(search,0,0);onlyHidden.Margin=new Padding(10,0,0,0);onlyHidden.CheckedChanged+=delegate{RefreshList();};filters.Controls.Add(onlyHidden,1,0);content.Controls.Add(filters,0,1);
        ConfigureAppGrid();
        var table=new WholeRowListPanel(list){Dock=DockStyle.Fill,Margin=new Padding(0)};table.Controls.Add(list);table.Controls.Add(new ThemedScrollBar(list));empty.Dock=DockStyle.Fill;empty.TextAlign=ContentAlignment.MiddleCenter;empty.Padding=new Padding(18);table.Controls.Add(empty);content.Controls.Add(table,0,2);
        content.Controls.Add(new Label{Text="Show on: visible on taskbar. Show off: hidden, still available in Alt+Tab.",Dock=DockStyle.Fill,Padding=new Padding(2,8,0,0),Tag="muted"},0,3);
        bottomOptions.Controls.Add(Button("Remove selected",RemoveSelected));bottomOptions.Controls.Add(Button("Show all apps",ShowAll));paused.Margin=new Padding(10,0,0,0);paused.CheckedChanged+=delegate{engine.Paused=paused.Checked;engine.Sweep();UpdateSummary();};bottomOptions.Controls.Add(paused);
    }
    void ConfigureAppGrid()
    {
        list.Dock=DockStyle.Fill;list.ScrollBars=ScrollBars.None;list.Margin=new Padding(0);list.AllowUserToAddRows=false;list.AllowUserToDeleteRows=false;list.AllowUserToResizeRows=false;list.RowHeadersVisible=false;list.SelectionMode=DataGridViewSelectionMode.FullRowSelect;list.MultiSelect=true;list.AutoGenerateColumns=false;list.AutoSizeRowsMode=DataGridViewAutoSizeRowsMode.None;list.RowTemplate.Height=58;list.ColumnHeadersHeight=34;
        list.Columns.Add(new DataGridViewCheckBoxColumn{HeaderText="Show",Name="show",Width=64,CellTemplate=new DisplaySwitchCell(),SortMode=DataGridViewColumnSortMode.NotSortable});
        list.Columns.Add(new DataGridViewTextBoxColumn{HeaderText="App",Name="app",Width=250,ReadOnly=true,SortMode=DataGridViewColumnSortMode.NotSortable});
        list.Columns.Add(new DataGridViewTextBoxColumn{HeaderText="Executable / app identity",Name="path",ReadOnly=true,AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill,SortMode=DataGridViewColumnSortMode.NotSortable});
        list.AccessibleName="Taskbar visibility. Turn Show on to restore, off to hide.";list.CurrentCellDirtyStateChanged+=delegate{if(list.IsCurrentCellDirty)list.CommitEdit(DataGridViewDataErrorContexts.Commit);};list.CellValueChanged+=ItemChecked;list.CellPainting+=PaintCell;
        list.CellMouseEnter+=delegate(object sender,DataGridViewCellEventArgs e){int old=hoveredRow;hoveredRow=e.RowIndex;if(old>=0&&old<list.Rows.Count)list.InvalidateRow(old);if(hoveredRow>=0)list.InvalidateRow(hoveredRow);};
        list.MouseLeave+=delegate{int old=hoveredRow;hoveredRow=-1;if(old>=0&&old<list.Rows.Count)list.InvalidateRow(old);};
    }
    TableLayoutPanel PageStack(Panel page,params int[] heights)
    {
        page.AutoScroll=true;var stack=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=1,RowCount=heights.Length,Margin=new Padding(0)};
        foreach(int height in heights)stack.RowStyles.Add(new RowStyle(SizeType.Absolute,height));page.Controls.Add(stack);return stack;
    }
    SoftCard Section(TableLayoutPanel stack,int row,string title,string description)
    {
        var card=new SoftCard{Dock=DockStyle.Fill,Margin=new Padding(0,0,0,16),Padding=new Padding(22)};stack.Controls.Add(card,0,row);
        card.Controls.Add(new Label{Text=title,Font=Theme.Medium(12.5f),AutoSize=true,Location=new Point(22,20)});
        card.Controls.Add(new Label{Text=description,AutoSize=false,Location=new Point(22,56),Height=50,Width=700,Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right,Tag="muted"});return card;
    }
    void BuildFolders()
    {
        var stack=PageStack(foldersPage,214,142);
        var scan=Section(stack,0,"Build your app library","Add a folder to find its executable files. Adding apps does not hide them until you turn Show off.");
        var actions=Flow();actions.Dock=DockStyle.Bottom;actions.Height=42;actions.Controls.Add(Button("Add folder…",AddFolder));actions.Controls.Add(Button("Saved folders…",ManageFolders));scanButton.Click+=async delegate{if(scanCancel!=null)scanCancel.Cancel();else await Scan();};actions.Controls.Add(scanButton);scan.Controls.Add(actions);
        var note=Section(stack,1,"Scan when you need to","Saved folders are scanned only when you ask. There is no continuous background folder scan.");
        folderInfo.Dock=DockStyle.Bottom;folderInfo.Height=23;note.Controls.Add(folderInfo);
    }
    void BuildActivity()
    {
        var layout=new TableLayoutPanel{Dock=DockStyle.Fill,RowCount=2,ColumnCount=1,Margin=new Padding(0)};layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,52));activityPage.Controls.Add(layout);
        var card=new SoftCard{Dock=DockStyle.Fill,Padding=new Padding(22),Margin=new Padding(0)};card.Controls.Add(errorLog);layout.Controls.Add(card,0,0);
        var actions=Flow();actions.Padding=new Padding(0,12,0,0);actions.Controls.Add(Button("Save diagnostics",delegate{TaskbarDiagnostics.Show(this,settings,engine);}));layout.Controls.Add(actions,0,1);
    }
    void BuildSettings()
    {
        var stack=PageStack(settingsPage,142,178,248);
        var appearance=Section(stack,0,"Appearance","Choose the look that feels right for your desktop.");
        themeChoice.Width=150;themeChoice.Anchor=AnchorStyles.Top|AnchorStyles.Right;themeChoice.Location=new Point(appearance.Width-178,25);themeChoice.Items.AddRange(new object[]{"Dark theme","Light theme"});themeChoice.SelectedIndex=Theme.Light?1:0;themeChoice.SelectedIndexChanged+=delegate{settings.ThemeMode=themeChoice.SelectedIndex==1?"light":"dark";Save();ApplyTheme();};appearance.Controls.Add(themeChoice);
        var behavior=Section(stack,1,"Ready in the tray","Closing or minimizing the window keeps your rules active. Open it again from the tray or your shortcut.");
        var toggles=Flow();toggles.Dock=DockStyle.Bottom;toggles.Height=40;
        startup.Checked=settings.StartupEnabled??true;startup.CheckedChanged+=StartupChanged;toggles.Controls.Add(startup);hideOwn.Checked=settings.HideOwnTaskbar;hideOwn.CheckedChanged+=delegate{settings.HideOwnTaskbar=hideOwn.Checked;ShowInTaskbar=!hideOwn.Checked;Save();};toggles.Controls.Add(hideOwn);behavior.Controls.Add(toggles);
        tips.SetToolTip(startup,"Start quietly in the system tray when you sign in to Windows.");
        var updates=Section(stack,2,"Updates","Installed version "+UpdateService.CurrentVersion.ToString(3)+"  ·  Checks only when you press the button.");
        updateStatus.Text="Updates come from Joe-Buff/taskbar-control on GitHub. Your settings are kept when updating.";updateStatus.Tag="muted";updateStatus.SetBounds(22,104,700,52);updateStatus.Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right;updates.Controls.Add(updateStatus);
        var buttons=Flow();buttons.Dock=DockStyle.Bottom;buttons.Height=42;buttons.Controls.Add(checkUpdate);buttons.Controls.Add(cancelUpdate);checkUpdate.Click+=async delegate{await CheckForUpdates();};cancelUpdate.Click+=delegate{if(updateCancel!=null)updateCancel.Cancel();};updates.Controls.Add(buttons);
    }
    void ToggleSidebar(){sidebarExpanded=!sidebarExpanded;shell.SuspendLayout();shell.ColumnStyles[0].Width=sidebarExpanded?184:86;foreach(var button in nav)button.Compact=!sidebarExpanded;collapse.Text=sidebarExpanded?"Collapse":"Expand";collapse.AccessibleName=collapse.Text+" sidebar";collapse.Compact=!sidebarExpanded;shell.ResumeLayout(true);Invalidate(true);}
    void Navigate(int index)
    {
        var all=new[]{appsPage,foldersPage,activityPage,settingsPage};for(int i=0;i<all.Length;i++){all[i].Visible=i==index;nav[i].Selected=i==index;nav[i].Invalidate();}
        all[index].BringToFront();bottomOptions.Visible=index==0;pageTitle.Text=new[]{"Taskbar Control","Folders","Activity","Settings"}[index];pageHint.Text=new[]{"Your apps stay open. Your taskbar stays clear.","Find apps in the folders you choose.","Plain-language errors and details to help resolve them.","Make Taskbar Control feel at home on your PC."}[index];UpdateDashboardStats();
    }
    void UpdateDashboardStats(){tracked.Value=settings.Apps.Count.ToString();hidden.Value=settings.Apps.Count(a=>!a.Show&&a.CanManage).ToString();visible.Value=settings.Apps.Count(a=>a.Show).ToString();folderInfo.Text=settings.Folders.Count+" saved folders";}
    void UpdateErrorPreview(){latestError.Text=errorLog.LatestBrief;latestError.Tag=errorLog.Count==0?"muted":null;latestError.ForeColor=errorLog.Count==0?Theme.Muted:Theme.Text;nav[2].Notice=errorLog.Count>0;nav[2].Invalidate();tips.SetToolTip(latestError,errorLog.Latest+"\nClick to open Activity and copy details.");}
    async Task CheckForUpdates()
    {
        if(updateCancel!=null)return;var cancel=new CancellationTokenSource();updateCancel=cancel;checkUpdate.Enabled=false;cancelUpdate.Visible=true;updateStatus.Text="Checking the latest public release…";
        try
        {
            var release=await UpdateService.CheckAsync(cancel.Token);
            if(IsDisposed||exiting)return;
            if(release.Version<=UpdateService.CurrentVersion){updateStatus.Text=release.Version==UpdateService.CurrentVersion?"You're up to date. Checked just now.":"No newer release is published. GitHub currently lists version "+release.Version.ToString(3)+"; this copy is newer.";return;}
            updateStatus.Text="Version "+release.Version.ToString(3)+" is available.";
            if(!UpdatePrompt.Confirm(this,release))return;
            var progress=new Progress<string>(message=>{if(!IsDisposed&&!exiting)updateStatus.Text=message;});
            string installer=await UpdateService.DownloadAsync(release,progress,cancel.Token);
            if(IsDisposed||exiting||cancel.IsCancellationRequested)return;
            var setup=Process.Start(new ProcessStartInfo(installer,UpdateService.InstallerArguments(Application.StartupPath)){UseShellExecute=true});
            cancelUpdate.Visible=false;
            updateStatus.Text="Setup is open. It will replace this version and keep your settings. Finish setup to reopen the app.";
            // Keep the button disabled while setup is open; avoid two simultaneous installers.
            if(setup!=null)
            {
                using(setup)
                {
                    var finished=new TaskCompletionSource<bool>();
                    setup.Exited+=delegate{finished.TrySetResult(true);};setup.EnableRaisingEvents=true;
                    if(setup.HasExited)finished.TrySetResult(true);await finished.Task;
                }
                if(!IsDisposed&&!exiting)updateStatus.Text="Setup has closed. If you canceled it, this version and your settings are still in place.";
            }
        }
        catch(OperationCanceledException){if(!IsDisposed)updateStatus.Text="Update canceled. Your installed app and settings are unchanged.";}
        catch(Exception ex){if(!IsDisposed){updateStatus.Text=UpdateService.FriendlyError(ex);errorLog.Report("Update failed: "+updateStatus.Text+"\n"+ErrorHelp.Technical(ex));}}
        finally{if(!IsDisposed){checkUpdate.Enabled=true;cancelUpdate.Visible=false;}updateCancel=null;cancel.Dispose();}
    }
}

namespace TaskbarStyling
{
    internal sealed class StatTile:Control
    {
        readonly string label;string value="0";
        internal StatTile(string title){label=title;SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);}
        internal string Value{set{if(this.value!=value){this.value=value;Invalidate();}}}
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(Theme.Background);e.Graphics.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            using(var path=ModernPaint.Round(Theme.Light?new Rectangle(1,1,Width-3,Height-3):new Rectangle(0,0,Width-1,Height-1),20)){using(var brush=new SolidBrush(Theme.Surface))e.Graphics.FillPath(brush,path);if(Theme.Light)using(var pen=new Pen(Theme.CardEdge,1.5f))e.Graphics.DrawPath(pen,path);}
            using(var font=Theme.Heading(23))TextRenderer.DrawText(e.Graphics,value,font,new Rectangle(20,10,Width-48,42),Theme.Text,TextFormatFlags.Left|TextFormatFlags.VerticalCenter);
            TextRenderer.DrawText(e.Graphics,label,Font,new Rectangle(22,56,Width-42,23),Theme.Muted,TextFormatFlags.Left|TextFormatFlags.EndEllipsis);
            using(var pen=new Pen(Theme.Light?Color.FromArgb(170,170,170):Color.FromArgb(48,48,48),2))e.Graphics.DrawLine(pen,Width-28,24,Width-28,Height-24);
        }
    }
    internal sealed class DashboardNav:Button
    {
        readonly string glyph;bool hover;internal bool Selected,Notice;bool compact;
        internal bool Compact{set{compact=value;Invalidate();}}
        internal DashboardNav(string text,string icon){Text=text;glyph=icon;Font=Theme.Medium(10);AccessibleName=text;FlatStyle=FlatStyle.Flat;FlatAppearance.BorderSize=0;SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);}
        protected override void OnMouseEnter(EventArgs e){hover=true;Invalidate();base.OnMouseEnter(e);}protected override void OnMouseLeave(EventArgs e){hover=false;Invalidate();base.OnMouseLeave(e);}
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(Theme.Surface);e.Graphics.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;var box=new Rectangle(0,0,Width-1,Height-1);
            if(Theme.Light)box.Inflate(-1,-1);
            using(var path=ModernPaint.Round(box,12)){if(Selected||hover)using(var brush=new SolidBrush(Selected?(Theme.Light?Theme.Selected:Theme.Hover):Theme.AppRow))e.Graphics.FillPath(brush,path);if(Theme.Light&&(Selected||hover||Focused))using(var pen=new Pen(Theme.CardEdge,Selected||Focused?2f:1.5f))e.Graphics.DrawPath(pen,path);else if(Focused)using(var pen=new Pen(Theme.Muted))e.Graphics.DrawPath(pen,path);}
            Color color=Selected?Theme.Text:Theme.Muted;int x=compact?(Width-20)/2:13,y=(Height-20)/2;
            using(var pen=new Pen(color,1.5f))
            {
                if(glyph=="apps"){for(int i=0;i<4;i++)using(var path=ModernPaint.Round(new Rectangle(x+(i%2)*11,y+(i/2)*11,7,7),2))e.Graphics.DrawPath(pen,path);}
                else if(glyph=="folders"){e.Graphics.DrawLines(pen,new[]{new Point(x,y+4),new Point(x+7,y+4),new Point(x+10,y+7),new Point(x+20,y+7),new Point(x+20,y+18),new Point(x,y+18),new Point(x,y+4)});}
                else if(glyph=="activity"){e.Graphics.DrawLines(pen,new[]{new Point(x,y+12),new Point(x+5,y+12),new Point(x+8,y+3),new Point(x+12,y+18),new Point(x+15,y+9),new Point(x+20,y+9)});}
                else if(glyph=="settings"){e.Graphics.DrawEllipse(pen,x+3,y+3,14,14);e.Graphics.DrawEllipse(pen,x+7,y+7,6,6);for(int i=0;i<8;i++){double a=i*Math.PI/4;e.Graphics.DrawLine(pen,x+10+(float)Math.Cos(a)*8,y+10+(float)Math.Sin(a)*8,x+10+(float)Math.Cos(a)*11,y+10+(float)Math.Sin(a)*11);}}
                else {e.Graphics.DrawLine(pen,x,y+4,x+19,y+4);e.Graphics.DrawLine(pen,x,y+10,x+19,y+10);e.Graphics.DrawLine(pen,x,y+16,x+19,y+16);}
            }
            if(!compact)TextRenderer.DrawText(e.Graphics,Text,Font,new Rectangle(45,0,Width-50,Height),color,TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPrefix);
            if(Notice)using(var brush=new SolidBrush(Theme.Text))e.Graphics.FillEllipse(brush,Width-9,5,5,5);
        }
    }
}
