using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

// Compile with /main:PickerTests alongside the application sources. Routes mouse
// messages to the HWND returned by Windows hit-testing; no physical input injection.
internal static class PickerTests
{
    [DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr hwnd, int msg, IntPtr wp, IntPtr lp);
    static List<string> log = new List<string>();
    internal static void Run(string file)
    {
        Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
        try
        {
            int oldClicks = 0;
            using (var old = Target(delegate { oldClicks++; }))
            {
                var button = (Button)old.Controls[0];
                RouteClick(button.PointToScreen(new Point(30, 15)));
                Check(oldClicks == 1 && old.IsDisposed, "Old pass-through gesture activates a target Close button");
            }
            TestSelection(false, false); TestSelection(true, false); TestSelection(false, true);
            int callbacks = 0;
            using (var picker = new WindowPicker(delegate(WindowTarget target) { Check(target == null, "Cancel returns no executable"); callbacks++; }))
            { picker.Show(); Pump(50); picker.CancelSelection(); Pump(100); Check(callbacks == 1 && picker.IsDisposed, "Cancel removes overlay exactly once"); }
            log.Add("PASS: All picker regression checks passed. These use real HWND hit-testing and routed messages, not physical clicks or SteelSeries.");
        }
        catch (Exception ex) { log.Add("FAIL: " + ex); Environment.ExitCode = 1; }
        File.WriteAllLines(file, log);
    }
    static Form Target(Action clicked)
    {
        var f = new Form { Text = "Picker regression target", StartPosition = FormStartPosition.Manual, Bounds = new Rectangle(120,120,420,240) };
        var b = new Button { Text = "Close target", Bounds = new Rectangle(30,30,160,40) };
        b.Click += delegate { clicked(); f.Close(); }; f.Controls.Add(b);
        f.Show(); f.Hide(); f.Show(); f.Activate(); Pump(50); return f;
    }
    static void TestSelection(bool titleClose, bool twice)
    {
        int clicks = 0, callbacks = 0; string result = null;
        using (var target = Target(delegate { clicks++; }))
        using (var picker = new WindowPicker(delegate(WindowTarget selected) { result = selected==null?null:selected.Path; callbacks++; }))
        {
            Point point = titleClose ? new Point(target.Right - 22, target.Top + 15) : target.Controls[0].PointToScreen(new Point(30,15));
            picker.Show(); Pump(80);
            Check(Native.WindowFromPoint(point) == picker.Handle, "Overlay owns hit-test above " + (titleClose ? "title-bar Close" : "target button"));
            Check((Native.GetWindowLong(picker.Handle,-20) & 0x20) == 0 && picker.Opacity > 0, "Overlay is not click-through");
            RouteClick(point);
            if (twice) { Pump(75); RouteClick(point); }
            Check(!target.IsDisposed && clicks == 0, "Selection gesture did not activate target controls");
            Pump(SystemInformation.DoubleClickTime + 250);
            Check(callbacks == 1 && String.Equals(result, Application.ExecutablePath, StringComparison.OrdinalIgnoreCase), "Executable resolved once after release" + (twice ? " and double-click guard" : ""));
            Check(!target.IsDisposed && target.Visible && clicks == 0, "Target remains open and visible");
            Check(picker.IsDisposed, "Selection overlay cleaned up");
        }
    }
    static void RouteClick(Point point)
    {
        IntPtr hwnd = Native.WindowFromPoint(point); var control = Control.FromHandle(hwnd);
        if (control == null) throw new Exception("Hit-test escaped controlled test windows.");
        Point client = control.PointToClient(point);
        IntPtr coordinates = new IntPtr((client.Y << 16) | (client.X & 65535));
        SendMessage(hwnd, 0x201, new IntPtr(1), coordinates); SendMessage(hwnd, 0x202, IntPtr.Zero, coordinates); Pump(10);
    }
    static void Pump(int ms) { var sw = Stopwatch.StartNew(); while(sw.ElapsedMilliseconds < ms) { Application.DoEvents(); Thread.Sleep(5); } }
    static void Check(bool ok, string text) { if (!ok) throw new Exception(text); log.Add("PASS: " + text); }
}
