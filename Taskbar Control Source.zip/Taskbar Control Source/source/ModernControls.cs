using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace TaskbarStyling
{
    internal sealed class BufferedAppGrid:DataGridView
    {
        int wheelRemainder;
        internal BufferedAppGrid(){DoubleBuffered=true;SetStyle(ControlStyles.ResizeRedraw,true);}
        protected override void OnColumnWidthChanged(DataGridViewColumnEventArgs e){base.OnColumnWidthChanged(e);Invalidate();}
        internal int ViewportRows {get{return Math.Max(1,(ClientSize.Height-(ColumnHeadersVisible?ColumnHeadersHeight:0))/Math.Max(1,RowTemplate.Height));}}
        internal int LastScrollRow {get{return Math.Max(0,Rows.Count-ViewportRows);}}
        internal void ScrollToRow(int index)
        {
            if(Rows.Count==0)return;
            index=Math.Max(0,Math.Min(LastScrollRow,index));
            if(FirstDisplayedScrollingRowIndex!=index)FirstDisplayedScrollingRowIndex=index;
        }
        internal void WheelScroll(int delta)
        {
            wheelRemainder+=delta;int steps=wheelRemainder/SystemInformation.MouseWheelScrollDelta;wheelRemainder%=SystemInformation.MouseWheelScrollDelta;
            int lines=SystemInformation.MouseWheelScrollLines;if(lines==0||steps==0)return;
            ScrollToRow(Math.Max(0,FirstDisplayedScrollingRowIndex)-steps*(lines<0?ViewportRows:lines));
        }
        protected override void OnMouseWheel(MouseEventArgs e)
        {
            if(ScrollBars!=ScrollBars.None){base.OnMouseWheel(e);return;}
            WheelScroll(e.Delta);
        }
    }
    // Reserve leftover vertical space below the viewport rather than drawing a
    // partial, still-clickable row. The grid and scrollbar share the same bounds.
    internal sealed class WholeRowListPanel:Panel
    {
        readonly BufferedAppGrid grid;
        internal WholeRowListPanel(BufferedAppGrid target)
        {
            grid=target;SetStyle(ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);
            grid.ColumnHeadersHeightChanged+=delegate{PerformLayout();};
            grid.RowHeightChanged+=delegate{PerformLayout();};
        }
        protected override void OnLayout(LayoutEventArgs e)
        {
            if(grid!=null)
            {
                int header=grid.ColumnHeadersVisible?grid.ColumnHeadersHeight:0;
                int row=Math.Max(1,grid.RowTemplate.Height);
                int available=Math.Max(0,ClientSize.Height-header);
                int remainder=available%row;
                if(Padding.Bottom!=remainder)Padding=new Padding(0,0,0,remainder);
            }
            base.OnLayout(e);
        }
    }
    // Painted with the app palette; avoids the native scrollbar's bright strip in dark mode.
    // The grid still owns row selection, keyboard navigation, and the actual scroll position.
    internal sealed class ThemedScrollBar:Control
    {
        readonly Func<int> count,viewport,position;
        readonly Action<int> scroll,wheel;
        int Last {get{return Math.Max(0,count()-viewport());}}
        bool dragging,hover;
        int dragOffset;
        internal ThemedScrollBar(BufferedAppGrid grid):this(()=>grid.Rows.Count,()=>grid.ViewportRows,()=>grid.FirstDisplayedScrollingRowIndex,grid.ScrollToRow,grid.WheelScroll)
        {
            grid.Scroll+=delegate{RefreshRange();};grid.SizeChanged+=delegate{RefreshRange();};grid.RowsAdded+=delegate{RefreshRange();};grid.RowsRemoved+=delegate{RefreshRange();};grid.RowHeightChanged+=delegate{RefreshRange();};
            AccessibleName="Scroll app list";AccessibleRole=AccessibleRole.ScrollBar;
        }
        internal ThemedScrollBar(ScrollableLogTextBox text):this(()=>text.LineCount,()=>text.ViewportLines,()=>text.FirstLine,text.ScrollToLine,text.WheelScroll)
        {
            text.ViewChanged+=RefreshRange;AccessibleName="Scroll error log";
        }
        ThemedScrollBar(Func<int> total,Func<int> shown,Func<int> first,Action<int> move,Action<int> wheelMove)
        {
            count=total;viewport=shown;position=first;scroll=move;wheel=wheelMove;
            Width=18;Dock=DockStyle.Right;Margin=new Padding(0);TabStop=true;AccessibleRole=AccessibleRole.ScrollBar;
            SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw|ControlStyles.Selectable,true);
            RefreshRange();
        }
        internal Rectangle Thumb
        {
            get
            {
                int track=Math.Max(1,Height-8),size=Math.Min(track,Math.Max(28,(int)((long)track*Math.Min(count(),viewport())/Math.Max(1,count()))));
                int current=Math.Max(0,Math.Min(Last,position()));
                int top=4+(Last==0?0:(int)((long)(track-size)*current/Last));
                return new Rectangle(6,top,hover||dragging?8:6,size);
            }
        }
        // Keep the gutter allocated: toggling Visible during the grid's layout can
        // leave a newly needed scrollbar at zero height after the form is resized.
        void RefreshRange(){if(IsDisposed)return;TabStop=Last>0;Invalidate();}
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(Theme.Surface);if(Last==0)return;e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
            Color track=Theme.Light?Color.FromArgb(235,235,240):Color.FromArgb(31,31,31);
            Color thumb=Theme.Light?(hover||dragging?Color.FromArgb(55,55,55):Color.FromArgb(100,100,100)):(hover||dragging?Color.FromArgb(147,147,147):Color.FromArgb(101,101,101));
            using(var shape=ModernPaint.Round(new Rectangle(6,4,8,Math.Max(1,Height-8)),4))using(var brush=new SolidBrush(track))e.Graphics.FillPath(brush,shape);
            using(var shape=ModernPaint.Round(Thumb,4)){using(var brush=new SolidBrush(thumb))e.Graphics.FillPath(brush,shape);if(Focused)using(var pen=new Pen(Theme.Text))e.Graphics.DrawPath(pen,shape);}
        }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);if(e.Button!=MouseButtons.Left)return;Focus();
            var thumb=Thumb;
            if(e.Y>=thumb.Top&&e.Y<thumb.Bottom){dragging=true;dragOffset=e.Y-thumb.Top;Capture=true;Invalidate();}
            else scroll(Math.Max(0,position())+(e.Y<thumb.Top?-viewport():viewport()));
        }
        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);if(!dragging)return;
            int travel=Math.Max(1,Height-8-Thumb.Height),top=Math.Max(0,Math.Min(travel,e.Y-dragOffset-4));
            scroll((int)Math.Round((double)top*Last/travel));
        }
        protected override void OnMouseUp(MouseEventArgs e){base.OnMouseUp(e);dragging=false;Capture=false;Invalidate();}
        protected override void OnMouseCaptureChanged(EventArgs e){base.OnMouseCaptureChanged(e);if(!Capture){dragging=false;Invalidate();}}
        protected override void OnMouseEnter(EventArgs e){base.OnMouseEnter(e);hover=true;Invalidate();}
        protected override void OnMouseLeave(EventArgs e){base.OnMouseLeave(e);hover=false;Invalidate();}
        protected override void OnMouseWheel(MouseEventArgs e){wheel(e.Delta);base.OnMouseWheel(e);}
        protected override bool IsInputKey(Keys keyData){return keyData==Keys.Up||keyData==Keys.Down||keyData==Keys.PageUp||keyData==Keys.PageDown||keyData==Keys.Home||keyData==Keys.End||base.IsInputKey(keyData);}
        protected override void OnKeyDown(KeyEventArgs e)
        {
            int row=Math.Max(0,position());
            switch(e.KeyCode){case Keys.Up:row--;break;case Keys.Down:row++;break;case Keys.PageUp:row-=viewport();break;case Keys.PageDown:row+=viewport();break;case Keys.Home:row=0;break;case Keys.End:row=Last;break;default:base.OnKeyDown(e);return;}
            scroll(row);e.Handled=true;e.SuppressKeyPress=true;Invalidate();
        }
        protected override void OnGotFocus(EventArgs e){base.OnGotFocus(e);Invalidate();}
        protected override void OnLostFocus(EventArgs e){base.OnLostFocus(e);Invalidate();}
    }
    // Standard read-only edit control keeps text selection/copy and wrapping.
    // Its own HWND receives these documented edit messages; no other app is touched.
    internal sealed class ScrollableLogTextBox:TextBox
    {
        const int EM_GETLINECOUNT=0xBA,EM_GETFIRSTVISIBLELINE=0xCE,EM_LINESCROLL=0xB6;
        [DllImport("user32.dll")]static extern IntPtr SendMessage(IntPtr window,int message,IntPtr wParam,IntPtr lParam);
        internal event Action ViewChanged;
        int wheelRemainder;
        internal int LineCount {get{return IsHandleCreated?(int)SendMessage(Handle,EM_GETLINECOUNT,IntPtr.Zero,IntPtr.Zero):1;}}
        internal int FirstLine {get{return IsHandleCreated?(int)SendMessage(Handle,EM_GETFIRSTVISIBLELINE,IntPtr.Zero,IntPtr.Zero):0;}}
        internal int ViewportLines {get{return Math.Max(1,ClientSize.Height/Math.Max(1,Font.Height));}}
        internal void ScrollToLine(int line)
        {
            line=Math.Max(0,Math.Min(Math.Max(0,LineCount-ViewportLines),line));
            if(IsHandleCreated)SendMessage(Handle,EM_LINESCROLL,IntPtr.Zero,new IntPtr(line-FirstLine));NotifyView();
        }
        internal void WheelScroll(int delta)
        {
            wheelRemainder+=delta;int steps=wheelRemainder/SystemInformation.MouseWheelScrollDelta;wheelRemainder%=SystemInformation.MouseWheelScrollDelta;
            int lines=SystemInformation.MouseWheelScrollLines;if(lines!=0&&steps!=0)ScrollToLine(FirstLine-steps*(lines<0?ViewportLines:lines));
        }
        void NotifyView(){if(ViewChanged!=null)ViewChanged();}
        protected override void WndProc(ref Message m)
        {
            if(m.Msg==0x20A){WheelScroll(unchecked((short)((long)m.WParam>>16)));m.Result=IntPtr.Zero;return;}
            base.WndProc(ref m);
            if(m.Msg==0x100||m.Msg==0x202||m.Msg==0x115||m.Msg==0xB6||m.Msg==0xB7)NotifyView();
        }
        protected override void OnTextChanged(EventArgs e){base.OnTextChanged(e);NotifyView();}
        protected override void OnSizeChanged(EventArgs e){base.OnSizeChanged(e);NotifyView();}
        protected override void OnFontChanged(EventArgs e){base.OnFontChanged(e);NotifyView();}
        protected override void OnHandleCreated(EventArgs e){base.OnHandleCreated(e);NotifyView();}
    }
    internal static class ModernPaint
    {
        internal static Color Accent {get{return Theme.Light?Color.FromArgb(30,30,30):Color.FromArgb(235,235,235);}}
        internal static Color OnAccent {get{return Theme.Light?Color.White:Color.FromArgb(20,20,20);}}
        internal static Color Field {get{return Theme.Light?Color.White:Color.FromArgb(28,28,28);}}
        internal static Color Edge {get{return Theme.Light?Theme.CardEdge:Color.FromArgb(52,52,52);}}
        internal static GraphicsPath Round(Rectangle r,int radius)
        {var p=new GraphicsPath();if(r.Width<=0||r.Height<=0)return p;int d=Math.Min(radius*2,Math.Min(r.Width,r.Height));p.AddArc(r.Left,r.Top,d,d,180,90);p.AddArc(r.Right-d,r.Top,d,d,270,90);p.AddArc(r.Right-d,r.Bottom-d,d,d,0,90);p.AddArc(r.Left,r.Bottom-d,d,d,90,90);p.CloseFigure();return p;}
        internal static void FieldBox(Graphics g,Rectangle r,bool focus)
        {g.SmoothingMode=SmoothingMode.AntiAlias;using(var p=Round(r,8)){using(var fill=new SolidBrush(Field))g.FillPath(fill,p);using(var pen=new Pen(focus?Accent:Edge,Theme.Light?(focus?2f:1.5f):1f))g.DrawPath(pen,p);}}
        internal static void Toggle(Graphics g,Rectangle r,bool value,bool enabled)
        {
            g.SmoothingMode=SmoothingMode.AntiAlias;
            using(var p=Round(r,r.Height/2))
            {using(var brush=new SolidBrush(value&&enabled?Accent:Field))g.FillPath(brush,p);using(var pen=new Pen(value&&enabled?Accent:Theme.Light?Edge:Theme.Muted,Theme.Light?1.5f:1f))g.DrawPath(pen,p);}
            int thumb=r.Height-6;using(var b=new SolidBrush(value&&enabled?OnAccent:enabled?Theme.Text:Theme.Muted))g.FillEllipse(b,value?r.Right-thumb-3:r.Left+3,r.Top+3,thumb,thumb);
        }
        internal static void Radio(Graphics g,Rectangle r,bool value,bool enabled)
        {g.SmoothingMode=SmoothingMode.AntiAlias;using(var pen=new Pen(value&&enabled?Accent:Theme.Muted,1.4f))g.DrawEllipse(pen,r);if(value)using(var b=new SolidBrush(enabled?Accent:Theme.Muted))g.FillEllipse(b,r.X+5,r.Y+5,r.Width-10,r.Height-10);}
        internal static void Monitor(Graphics g,Rectangle r,Color color)
        {g.SmoothingMode=SmoothingMode.AntiAlias;using(var p=new Pen(color,1.4f)){using(var shape=Round(new Rectangle(r.X,r.Y,r.Width,r.Height-7),3))g.DrawPath(p,shape);g.DrawLine(p,r.X+r.Width/2,r.Bottom-7,r.X+r.Width/2,r.Bottom-3);g.DrawLine(p,r.X+5,r.Bottom-2,r.Right-5,r.Bottom-2);}}
        internal static void Arrow(Graphics g,int x,int y,Color color)
        {g.SmoothingMode=SmoothingMode.AntiAlias;using(var p=new Pen(color,1.5f)){p.StartCap=LineCap.Round;p.EndCap=LineCap.Round;g.DrawLines(p,new[]{new Point(x-4,y-2),new Point(x,y+2),new Point(x+4,y-2)});}}
        internal static void Check(Graphics g,Rectangle r,bool value,bool enabled)
        {
            g.SmoothingMode=SmoothingMode.AntiAlias;
            using(var path=Round(r,4)){using(var brush=new SolidBrush(value&&enabled?Accent:Field))g.FillPath(brush,path);using(var pen=new Pen(value&&enabled?Accent:Edge))g.DrawPath(pen,path);}
            if(value)using(var pen=new Pen(enabled?OnAccent:Theme.Muted,2)){pen.StartCap=LineCap.Round;pen.EndCap=LineCap.Round;g.DrawLines(pen,new[]{new Point(r.Left+4,r.Top+r.Height/2),new Point(r.Left+7,r.Bottom-5),new Point(r.Right-4,r.Top+5)});}
        }
        internal static void ComboChrome(ComboBox combo,Graphics g)
        {
            using(var background=new SolidBrush(combo.Parent==null?Theme.Background:combo.Parent.BackColor))g.FillRectangle(background,combo.ClientRectangle);FieldBox(g,new Rectangle(1,1,combo.Width-3,combo.Height-3),combo.Focused||combo.DroppedDown);
            string text=combo.SelectedIndex<0&&combo is ModernCombo?((ModernCombo)combo).Placeholder:combo.Text;
            TextRenderer.DrawText(g,text,combo.Font,new Rectangle(10,1,combo.Width-36,combo.Height-2),combo.Enabled?Theme.Text:Theme.Muted,TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPrefix);
            Arrow(g,combo.Width-15,combo.Height/2,combo.Enabled?Theme.Text:Theme.Muted);
        }
    }
    internal class ModernCombo:ComboBox
    {
        internal string Placeholder="";
        internal ModernCombo(){FlatStyle=FlatStyle.Flat;DrawMode=DrawMode.OwnerDrawFixed;ItemHeight=27;DropDownStyle=ComboBoxStyle.DropDownList;DropDownHeight=270;IntegralHeight=false;BackColor=Theme.Surface;ForeColor=Theme.Text;}
        protected override void OnSizeChanged(EventArgs e){base.OnSizeChanged(e);Invalidate();}
        protected override void WndProc(ref Message m){base.WndProc(ref m);if(m.Msg==0xF&&IsHandleCreated)using(var g=Graphics.FromHwnd(Handle))ModernPaint.ComboChrome(this,g);else if((m.Msg==0x317||m.Msg==0x318)&&m.WParam!=IntPtr.Zero)using(var g=Graphics.FromHdc(m.WParam))ModernPaint.ComboChrome(this,g);}
        protected override void OnDrawItem(DrawItemEventArgs e)
        {using(var b=new SolidBrush((e.State&DrawItemState.Selected)!=0?Theme.Selected:ModernPaint.Field))e.Graphics.FillRectangle(b,e.Bounds);if(e.Index>=0)TextRenderer.DrawText(e.Graphics,GetItemText(Items[e.Index]),Font,new Rectangle(e.Bounds.X+9,e.Bounds.Y,e.Bounds.Width-12,e.Bounds.Height),Theme.Text,TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPrefix);}
    }
    internal sealed class ComboChromeWindow:NativeWindow,IDisposable
    {
        readonly ComboBox combo;
        internal ComboChromeWindow(ComboBox control){combo=control;combo.DrawMode=DrawMode.OwnerDrawFixed;combo.ItemHeight=25;combo.DrawItem+=DrawItem;AssignHandle(control.Handle);}
        void DrawItem(object sender,DrawItemEventArgs e){using(var b=new SolidBrush((e.State&DrawItemState.Selected)!=0?Theme.Selected:ModernPaint.Field))e.Graphics.FillRectangle(b,e.Bounds);if(e.Index>=0)TextRenderer.DrawText(e.Graphics,combo.GetItemText(combo.Items[e.Index]),combo.Font,new Rectangle(e.Bounds.X+8,e.Bounds.Y,e.Bounds.Width-12,e.Bounds.Height),Theme.Text,TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPrefix);}
        protected override void WndProc(ref Message m){base.WndProc(ref m);if(m.Msg==0xF&&Handle!=IntPtr.Zero)using(var g=Graphics.FromHwnd(Handle))ModernPaint.ComboChrome(combo,g);}
        public void Dispose(){combo.DrawItem-=DrawItem;ReleaseHandle();}
    }
    internal sealed class ModernNumber:NumericUpDown
    {
        ButtonChrome chrome;
        internal ModernNumber(){BorderStyle=BorderStyle.None;BackColor=ModernPaint.Field;ForeColor=Theme.Text;}
        protected override void UpdateEditText(){if(Value<0){ChangingText=true;Text="Keep";}else base.UpdateEditText();}
        protected override void ValidateEditText(){if(String.Equals(Text,"Keep",StringComparison.OrdinalIgnoreCase)){Value=-1;UpdateEditText();}else base.ValidateEditText();}
        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);if(chrome!=null)chrome.Dispose();
            foreach(Control child in Controls)if(!(child is TextBox)){chrome=new ButtonChrome(child);break;}
        }
        protected override void Dispose(bool disposing){if(disposing&&chrome!=null){chrome.Dispose();chrome=null;}base.Dispose(disposing);}
        sealed class ButtonChrome:NativeWindow,IDisposable
        {
            readonly Control control;
            internal ButtonChrome(Control target){control=target;AssignHandle(target.Handle);}
            protected override void WndProc(ref Message m)
            {
                base.WndProc(ref m);
                if(m.Msg==0xF&&Handle!=IntPtr.Zero)using(var g=Graphics.FromHwnd(Handle))Paint(g);
                else if((m.Msg==0x317||m.Msg==0x318)&&m.WParam!=IntPtr.Zero)using(var g=Graphics.FromHdc(m.WParam))Paint(g);
            }
            void Paint(Graphics g)
            {
                using(var background=new SolidBrush(ModernPaint.Field))g.FillRectangle(background,control.ClientRectangle);g.SmoothingMode=SmoothingMode.AntiAlias;int x=control.Width/2,y=control.Height/4;
                using(var p=new Pen(Theme.Muted,1.5f)){g.DrawLines(p,new[]{new Point(x-3,y+1),new Point(x,y-2),new Point(x+3,y+1)});y=control.Height*3/4;g.DrawLines(p,new[]{new Point(x-3,y-1),new Point(x,y+2),new Point(x+3,y-1)});}
            }
            public void Dispose(){ReleaseHandle();}
        }
    }
    internal sealed class ModernToggle:CheckBox
    {
        internal ModernToggle(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);AutoSize=true;MinimumSize=new Size(0,34);Margin=new Padding(0,0,18,0);}
        public override Size GetPreferredSize(Size proposed){return new Size(TextRenderer.MeasureText(Text,Font).Width+56,34);}
        protected override void OnPaint(PaintEventArgs e)
        {
            using(var background=new SolidBrush(BackColor))e.Graphics.FillRectangle(background,ClientRectangle);e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
            var r=new Rectangle(2,(Height-22)/2,40,22);ModernPaint.Toggle(e.Graphics,r,Checked,Enabled);
            TextRenderer.DrawText(e.Graphics,Text,Font,new Rectangle(53,0,Width-53,Height),Enabled?Theme.Text:Theme.Muted,TextFormatFlags.VerticalCenter|TextFormatFlags.NoPrefix);
            if(Focused)using(var pen=new Pen(ModernPaint.Accent)){pen.DashStyle=DashStyle.Dot;using(var p=ModernPaint.Round(new Rectangle(0,r.Top-2,44,26),13))e.Graphics.DrawPath(pen,p);}
        }
    }
    internal sealed class SoftCard:Panel
    {
        internal SoftCard(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);}
        protected override void OnPaint(PaintEventArgs e)
        {base.OnPaint(e);e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;using(var p=ModernPaint.Round(new Rectangle(1,1,Width-3,Height-3),22)){using(var b=new SolidBrush(Theme.Surface))e.Graphics.FillPath(b,p);if(Theme.Light)using(var pen=new Pen(Theme.CardEdge,1.5f))e.Graphics.DrawPath(pen,p);}}
    }
    internal sealed class ModernTextField:UserControl
    {
        readonly TextBox input=new TextBox{BorderStyle=BorderStyle.None};
        [System.Runtime.InteropServices.DllImport("user32.dll",CharSet=System.Runtime.InteropServices.CharSet.Unicode)]static extern IntPtr SendMessage(IntPtr handle,int message,IntPtr w,string text);
        internal string Placeholder="";
        internal ModernTextField()
        {
            SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);
            Height=36;MinimumSize=new Size(40,36);Margin=new Padding(0,0,8,0);TabStop=false;
            Controls.Add(input);input.HandleCreated+=delegate{SendMessage(input.Handle,0x1501,new IntPtr(1),Placeholder);};input.TextChanged+=delegate{base.OnTextChanged(EventArgs.Empty);};input.Enter+=delegate{Invalidate();};input.Leave+=delegate{Invalidate();};ApplyTheme();Arrange();
        }
        public override string Text {get{return input==null?base.Text:input.Text;}set{if(input==null)base.Text=value;else input.Text=value;}}
        internal void ApplyTheme(){if(input!=null){input.BackColor=ModernPaint.Field;input.ForeColor=Enabled?Theme.Text:Theme.Muted;input.AccessibleName=AccessibleName;}Invalidate();}
        void Arrange(){if(input!=null){input.Font=Font;input.SetBounds(11,Math.Max(0,(Height-input.PreferredHeight)/2),Math.Max(1,Width-22),input.PreferredHeight);}}
        protected override void OnSizeChanged(EventArgs e){base.OnSizeChanged(e);Arrange();}
        protected override void OnFontChanged(EventArgs e){base.OnFontChanged(e);Arrange();}
        protected override void OnEnabledChanged(EventArgs e){base.OnEnabledChanged(e);ApplyTheme();}
        protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);using(var background=new SolidBrush(Parent==null?Theme.Background:Parent.BackColor))e.Graphics.FillRectangle(background,ClientRectangle);ModernPaint.FieldBox(e.Graphics,new Rectangle(1,1,Width-3,Height-3),input.Focused);}
    }
    internal sealed class ModeBadge:Control
    {
        internal ModeBadge(){Size=new Size(142,28);SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);}
        protected override void OnTextChanged(EventArgs e){base.OnTextChanged(e);AccessibleName=Text;Invalidate();}
        protected override void OnPaint(PaintEventArgs e)
        {using(var background=new SolidBrush(Parent==null?Theme.Background:Parent.BackColor))e.Graphics.FillRectangle(background,ClientRectangle);e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;using(var path=ModernPaint.Round(new Rectangle(0,0,Width-1,Height-1),14)){using(var b=new SolidBrush(Theme.Surface))e.Graphics.FillPath(b,path);using(var p=new Pen(ModernPaint.Edge))e.Graphics.DrawPath(p,path);}using(var b=new SolidBrush(Theme.Text))e.Graphics.FillEllipse(b,12,Height/2-3,6,6);TextRenderer.DrawText(e.Graphics,Text,Font,new Rectangle(27,0,Width-30,Height),Theme.Text,TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);}
    }
    internal sealed class DisplaySwitchCell:DataGridViewCheckBoxCell
    {
        internal bool Radio;
        public override object Clone(){var cell=(DisplaySwitchCell)base.Clone();cell.Radio=Radio;return cell;}
        protected override Rectangle GetContentBounds(Graphics graphics,DataGridViewCellStyle style,int row)
        {if(DataGridView==null||row<0||ColumnIndex<0)return Rectangle.Empty;int width=Radio?20:34,height=20;return new Rectangle((OwningColumn.Width-width)/2,(DataGridView.Rows[row].Height-height)/2,width,height);}
    }
    internal sealed class ModernList:ListBox
    {
        internal string Placeholder="No apps selected";
        internal ModernList(){DrawMode=DrawMode.OwnerDrawFixed;ItemHeight=34;BorderStyle=BorderStyle.None;IntegralHeight=false;}
        protected override void OnDrawItem(DrawItemEventArgs e)
        {using(var b=new SolidBrush((e.State&DrawItemState.Selected)!=0?Theme.Selected:Theme.Surface))e.Graphics.FillRectangle(b,e.Bounds);if(e.Index>=0)TextRenderer.DrawText(e.Graphics,GetItemText(Items[e.Index]),Font,new Rectangle(e.Bounds.X+12,e.Bounds.Y,e.Bounds.Width-24,e.Bounds.Height),Theme.Text,TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPrefix);}
        void Empty(Graphics g){if(Items.Count==0)TextRenderer.DrawText(g,Placeholder,Font,ClientRectangle,Theme.Muted,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);}
        protected override void WndProc(ref Message m){base.WndProc(ref m);if(Items.Count==0){if(m.Msg==0xF&&IsHandleCreated)using(var g=Graphics.FromHwnd(Handle))Empty(g);else if((m.Msg==0x317||m.Msg==0x318)&&m.WParam!=IntPtr.Zero)using(var g=Graphics.FromHdc(m.WParam))Empty(g);}}
    }
    internal sealed class MonochromeMenuColors:ProfessionalColorTable
    {
        public override Color ToolStripDropDownBackground {get{return Theme.Surface;}}
        public override Color MenuItemSelected {get{return Theme.Selected;}}
        public override Color MenuItemBorder {get{return ModernPaint.Edge;}}
        public override Color MenuBorder {get{return ModernPaint.Edge;}}
        public override Color SeparatorDark {get{return ModernPaint.Edge;}}
        public override Color SeparatorLight {get{return Theme.Surface;}}
    }
    internal sealed class ModernMessage:Form
    {
        internal static void ShowError(Form owner,string message,string details)
        {
            using(var f=new ModernMessage())
            {
                f.Text="Taskbar Control";f.Font=owner.Font;f.BackColor=Theme.Background;f.ForeColor=Theme.Text;f.ClientSize=new Size(610,300);f.StartPosition=FormStartPosition.CenterParent;f.MinimizeBox=false;f.MaximizeBox=false;f.FormBorderStyle=FormBorderStyle.FixedDialog;
                var body=new TextBox{Text=message,ReadOnly=true,Multiline=true,ScrollBars=ScrollBars.Vertical,BorderStyle=BorderStyle.None,BackColor=Theme.Background,ForeColor=Theme.Text,Dock=DockStyle.Fill};
                var panel=new Panel{Dock=DockStyle.Fill,Padding=new Padding(24)};panel.Controls.Add(body);f.Controls.Add(panel);
                var bar=new FlowLayoutPanel{Dock=DockStyle.Bottom,Height=52,Padding=new Padding(20,4,0,0),FlowDirection=FlowDirection.RightToLeft};
                var ok=new FlatButton{Text="OK",DialogResult=DialogResult.OK};var copy=new FlatButton{Text="Copy error details"};copy.Click+=delegate{try{Clipboard.SetText(details);copy.Text="Copied";}catch{copy.Text="Copy unavailable";}};bar.Controls.Add(ok);bar.Controls.Add(copy);f.Controls.Add(bar);f.AcceptButton=ok;f.CancelButton=ok;f.Shown+=delegate{Theme.Frame(f.Handle);};f.ShowDialog(owner);
            }
        }
    }
}
