param([string]$CppCompiler,[switch]$UseExistingNative,[string]$OutputDirectory)
$ErrorActionPreference = 'Stop'
if(-not $CppCompiler){$found=Get-Command clang++.exe -ErrorAction SilentlyContinue;if($found){$CppCompiler=$found.Source}}
$native=Join-Path $PSScriptRoot 'TaskbarVisual.dll'
if(-not $UseExistingNative){
if(-not $CppCompiler -or -not (Test-Path -LiteralPath $CppCompiler)){throw 'Pass -CppCompiler with a Clang/MinGW C++23 compiler including C++/WinRT headers, or -UseExistingNative to reuse the included unchanged helper.'}
& $CppCompiler '-target' 'x86_64-w64-mingw32' '-std=c++23' '-DUNICODE' '-D_UNICODE' '-D_WIN32_WINNT=0x0A00' '-shared' '-static' '-O2' (Join-Path $PSScriptRoot 'TaskbarVisual.cpp') '-lole32' '-loleaut32' '-lruntimeobject' '-luuid' '-ldbghelp' '-o' $native
if($LASTEXITCODE -ne 0){throw 'Native taskbar helper compilation failed.'}
} elseif(-not (Test-Path -LiteralPath $native)){throw 'The prebuilt native helper is missing.'}
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$destination = Join-Path $PSScriptRoot '..\TaskbarControl.exe'
if($OutputDirectory){New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null;$destination=Join-Path ([IO.Path]::GetFullPath($OutputDirectory)) 'TaskbarControl.exe'}
& $compiler /nologo /target:exe /out:"$PSScriptRoot\BuildIcon.exe" /reference:System.Drawing.dll "$PSScriptRoot\BuildIcon.cs"
if ($LASTEXITCODE -ne 0) { throw 'Icon generator compilation failed.' }
& "$PSScriptRoot\BuildIcon.exe" "$PSScriptRoot\TaskbarControl.ico"
if ($LASTEXITCODE -ne 0) { throw 'Icon generation failed.' }
$files=Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.cs' | Select-Object -ExpandProperty FullName
& $compiler /nologo /target:winexe /platform:x64 /main:Program /optimize+ /warn:4 /win32icon:"$PSScriptRoot\TaskbarControl.ico" /win32manifest:"$PSScriptRoot\app.manifest" /out:"$destination" "/resource:$PSScriptRoot\TaskbarControl.png,TaskbarControl.Brand.png" "/resource:$native,TaskbarControl.Visual.dll" /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Runtime.Serialization.dll $files
if ($LASTEXITCODE -ne 0) { throw 'Compilation failed.' }
Write-Output "Built $destination"
