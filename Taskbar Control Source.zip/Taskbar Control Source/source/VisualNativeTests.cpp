#define TC_VISUAL_TEST
#include "TaskbarVisual.cpp"
#include <iostream>
int wmain(int argc,wchar_t** argv) {
    int checks=0;
    auto check=[&](bool success,const char* name){if(!success){std::cerr<<"FAIL: "<<name<<std::endl;exit(1);}++checks;std::cout<<"PASS: "<<name<<std::endl;};
    ruleMap=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,MapBytes,MapName);
    shared=static_cast<BYTE*>(MapViewOfFile(ruleMap,FILE_MAP_ALL_ACCESS,0,0,MapBytes));
    check(shared!=nullptr,"isolated native bridge opens");ZeroMemory(shared,MapBytes);
    auto publish=[&](std::wstring data){
        *reinterpret_cast<DWORD*>(shared)=0x54435631;*reinterpret_cast<DWORD*>(shared+4)=1;
        *reinterpret_cast<ULONGLONG*>(shared+8)=GetTickCount64();
        *reinterpret_cast<DWORD*>(shared+16)=static_cast<DWORD>(data.size()*2);
        memcpy(shared+40,data.data(),data.size()*2);
    };
    publish(L"Desktop.App\nMicrosoft.Example!App");
    check(ReadRules()&&wanted.size()==2,"two exact identities accepted");
    check(IdentityMatches(L"Appid: Desktop.App"),"matching taskbar group selected");
    check(!IdentityMatches(L"Appid: Desktop.AppOther"),"prefix-similar app stays visible");
    check(!IdentityMatches(L"Desktop.App"),"unrelated automation identity stays visible");
    check(!IdentityMatches(L"Appid: Recycled.Different.App"),"recycled button identity no longer matches old rule");
    *reinterpret_cast<ULONGLONG*>(shared+8)=GetTickCount64()-4000;
    check(!ReadRules()&&wanted.empty(),"expired publisher clears all visual rules");
    publish(L"Desktop.App");*reinterpret_cast<DWORD*>(shared+16)=60002;
    check(!ReadRules()&&wanted.empty(),"oversized buffer fails open");
    publish(L"Desktop.App");*reinterpret_cast<DWORD*>(shared+16)=1;
    check(!ReadRules()&&wanted.empty(),"partial UTF-16 buffer fails open");
    publish(L"Desktop.App");*reinterpret_cast<DWORD*>(shared+4)=99;
    check(!ReadRules()&&wanted.empty(),"unknown protocol fails open");
    publish(L"");check(ReadRules()&&wanted.empty(),"empty rules request restoration");
    Report(1,2);check(*reinterpret_cast<DWORD*>(shared+28)==2&&*reinterpret_cast<ULONGLONG*>(shared+32)>0,"acknowledgement records native count and heartbeat");
    if(argc==2) {
        DWORD config[8]{};config[1]=0x1000000;
        check(ResolveTaskbarSymbols(argv[1],config,8)==0,"Microsoft symbols resolve all six taskbar interfaces and verify their GUID");
        std::wcout<<L"SYMBOLS|"<<argv[1]<<L"|";
        for(int i=2;i<8;i++)std::cout<<std::hex<<config[i]<<(i==7?'\n':'|');
    }
    UnmapViewOfFile(shared);CloseHandle(ruleMap);CloseHandle(ruleMutex);
    std::cout<<std::dec<<checks<<" native checks passed; no live taskbar was modified."<<std::endl;
}
