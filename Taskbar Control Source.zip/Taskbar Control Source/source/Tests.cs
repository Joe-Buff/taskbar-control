using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using TaskbarStyling;

internal sealed class FakeTaskbarPlatform : ITaskbarPlatform
{
    internal readonly Dictionary<IntPtr,WindowTarget> Targets=new Dictionary<IntPtr,WindowTarget>();
    internal readonly List<IntPtr> Hidden=new List<IntPtr>(),Shown=new List<IntPtr>();
    internal bool FailShow, OmitEnumeration;
    public void Connect(){} public void Dispose(){}
    public void Hide(IntPtr h){Hidden.Add(h);}
    public void Show(IntPtr h){if(FailShow)throw new InvalidOperationException("Injected restore failure");Shown.Add(h);}
    public bool Exists(IntPtr h){return Targets.ContainsKey(h);} public bool Eligible(IntPtr h){return Exists(h);}
    public IEnumerable<IntPtr> Windows(){return OmitEnumeration?new IntPtr[0]:Targets.Keys.ToArray();}
    public WindowTarget Resolve(IntPtr h,Dictionary<uint,ProcessIdentity> cache){WindowTarget target;return Targets.TryGetValue(h,out target)?target:null;}
}
internal static class HostedFixture
{
    [DllImport("user32.dll",SetLastError=true)] static extern IntPtr SetParent(IntPtr child,IntPtr parent);
    [DllImport("user32.dll",SetLastError=true)] static extern int SetWindowLong(IntPtr window,int index,int value);
    internal static void Run(string report,IntPtr parent)
    {
        using(var form=new Form{Text=parent==IntPtr.Zero?"Controlled app host":"Controlled hosted app",Size=new Size(440,280),ShowInTaskbar=false})
        using(var timer=new System.Windows.Forms.Timer{Interval=100})
        {
            var deadline=DateTime.UtcNow.AddSeconds(20);
            form.Shown+=delegate
            {
                if(parent!=IntPtr.Zero){SetWindowLong(form.Handle,-16,(Native.GetWindowLong(form.Handle,-16)|0x40000000)&~unchecked((int)0x80000000));SetParent(form.Handle,parent);form.Location=new Point(10,10);}
                File.WriteAllText(report,form.Handle.ToInt64().ToString());timer.Start();
            };
            timer.Tick+=delegate{if(DateTime.UtcNow>=deadline||File.Exists(report+".stop"))form.Close();};Application.Run(form);
        }
    }
}
internal static class SelfTest
{
    static readonly List<string> log=new List<string>();
    internal static void RunCore(string directory)
    {
        Directory.CreateDirectory(directory);
        try{IdentityChecks();EngineChecks();VisualBridgeChecks();}
        catch(Exception ex){log.Add("FAIL: "+ex);Environment.ExitCode=1;}
        File.WriteAllLines(Path.Combine(directory,"core-results.txt"),log);
    }
    static void Check(bool condition,string name){if(!condition)throw new Exception(name);log.Add("PASS: "+name);}
    internal static void Pump(int milliseconds){var watch=Stopwatch.StartNew();while(watch.ElapsedMilliseconds<milliseconds){Application.DoEvents();Thread.Sleep(5);}}
    static WindowTarget Target(int handle,string path,string appId=null)
    {return new WindowTarget{Window=new IntPtr(handle),OwnerPid=90001,Path=path,AppId=appId,Name=Path.GetFileName(path)};}
    internal static void Run(string directory)
    {
        Directory.CreateDirectory(directory);
        try
        {
            string fixtures=Path.Combine(directory,"files");Directory.CreateDirectory(Path.Combine(fixtures,"nested"));File.WriteAllText(Path.Combine(fixtures,"one.exe"),"fixture");File.WriteAllText(Path.Combine(fixtures,"nested","two.exe"),"fixture");
            int skipped;var files=Scanner.Scan(new[]{fixtures,fixtures,Path.Combine(fixtures,"absent")},CancellationToken.None,out skipped);Check(files.Count==2&&skipped==1,"Folder scanning deduplicates executables and skips inaccessible locations");
            var cancel=new CancellationTokenSource();cancel.Cancel();bool cancelled=false;try{Scanner.Scan(new[]{fixtures},cancel.Token,out skipped);}catch(OperationCanceledException){cancelled=true;}Check(cancelled,"Folder scanning remains cancellable");
            string settingsPath=Path.Combine(directory,"legacy.json");File.WriteAllText(settingsPath,"{\"Apps\":[{\"Path\":\"C:\\\\Apps\\\\Music.exe\",\"Show\":false}],\"Folders\":[],\"HideOwnTaskbar\":true,\"StartupEnabled\":false}");
            var legacy=Settings.Read(settingsPath);Check(legacy.Apps.Count==1&&!legacy.Apps[0].Show&&legacy.HideOwnTaskbar&&legacy.StartupEnabled==false,"Existing rules and startup opt-out load without the new theme or app-identity fields");
            legacy.ThemeMode="light";legacy.Save(settingsPath);Check(Settings.Read(settingsPath).ThemeMode=="light"&&File.Exists(settingsPath+".bak"),"Theme preference saves with an atomic backup");
            legacy.Apps.Add(new AppRule(@"C:\Windows\System32\ApplicationFrameHost.exe"){Show=false});legacy.Save(settingsPath);Check(Settings.Read(settingsPath).Apps.Last().Show,"Legacy shared-host rules are retained but reset to Show instead of hiding unrelated apps");
            IdentityChecks();DiscoveryChecks();EngineChecks();VisualBridgeChecks();UiChecks(directory);UiDrawingChecks(directory);HostedCheck(directory);
            using(var window=new Form()){window.Show();Pump(30);Check(String.Equals(Native.WindowExecutable(window.Handle),Application.ExecutablePath,StringComparison.OrdinalIgnoreCase),"Ordinary windows still resolve their executable");window.Close();}
            log.Add("PASS: Completed. Taskbar operations use a fake platform; the hosted fixture uses real HWNDs and processes. Live Xbox taskbar behavior is not established by these checks.");
        }
        catch(Exception ex){log.Add("FAIL: "+ex);Environment.ExitCode=1;}
        File.WriteAllLines(Path.Combine(directory,"test-results.txt"),log);
    }
    static void VisualBridgeChecks()
    {
        using(var embedded=typeof(Program).Assembly.GetManifestResourceStream("TaskbarControl.Visual.dll"))
            Check(embedded!=null&&embedded.Length>10000,"Standalone executable contains its native helper");
        Check(VisualHelper.KnownOffsets("unsupported-build")==null,"Unknown Windows builds cannot select guessed taskbar addresses");
        Check(VisualHelper.KnownOffsets("483327DB5FAC66CA1D844F9D8F5054CB1").Length==6,"Verified Windows compatibility metadata is available offline");
        string suffix=".test."+Guid.NewGuid().ToString("N");
        using(var bridge=new VisualRuleBridge(suffix))
        using(var mapping=System.IO.MemoryMappedFiles.MemoryMappedFile.OpenExisting(VisualRuleBridge.MapName+suffix))
        using(var view=mapping.CreateViewAccessor())
        {
            bridge.Publish(new[]{"Example.App!Main","Example.App!Main","Desktop.App"});
            int length=view.ReadInt32(16);var bytes=new byte[length];view.ReadArray(40,bytes,0,length);
            Check(view.ReadInt32(0)==0x54435631&&view.ReadInt32(4)==1&&view.ReadUInt64(8)>0,"Visual companion protocol publishes a versioned live heartbeat");
            Check(System.Text.Encoding.Unicode.GetString(bytes)=="Desktop.App\nExample.App!Main","Visual rules deduplicate and transmit only exact app identities");
            Check(bridge.HiddenButtons==0&&bridge.Status.Contains("Waiting"),"Missing visual companion is reported instead of claiming buttons are hidden");
            view.Write(24,1);view.Write(28,2);view.Write(32,VisualRuleBridge.GetTickCount64());bridge.Publish(new[]{"Desktop.App"});
            Check(bridge.HiddenButtons==2&&bridge.Status=="","Fresh companion acknowledgements report the visual button count");
            view.Write(32,(ulong)1);bridge.Publish(new[]{"Desktop.App"});
            Check(bridge.HiddenButtons==0&&bridge.Status.Contains("Waiting"),"An expired acknowledgement cannot claim successful hiding");
            view.Write(24,4);view.Write(32,VisualRuleBridge.GetTickCount64());bridge.Publish(new[]{"Desktop.App"});
            Check(bridge.HiddenButtons==0&&bridge.Status.Contains("visible"),"Unsupported native attachment reports visible buttons instead of false success");
            bool rejected=false;try{VisualRuleBridge.Encode(new[]{"App\nOtherApp"});}catch(ArgumentException){rejected=true;}
            Check(rejected,"Visual bridge rejects newline injection in an app identity");
            rejected=false;try{VisualRuleBridge.Encode(Enumerable.Range(0,40).Select(i=>i+new string('a',1000)));}catch(InvalidOperationException){rejected=true;}
            Check(rejected,"Visual bridge rejects oversized payloads without truncating identities");
            bridge.Publish(new string[0]);Check(view.ReadInt32(16)==0,"Empty visual rules explicitly request restoration");
        }
        using(var monitor=System.IO.MemoryMappedFiles.MemoryMappedFile.CreateOrOpen(VisualRuleBridge.MapName+suffix,VisualRuleBridge.Capacity))
        using(var view=monitor.CreateViewAccessor())
        {
            using(var publisher=new VisualRuleBridge(suffix)){publisher.Publish(new[]{"Example.App"});}
            Check(view.ReadInt32(16)==0,"Normal bridge shutdown leaves an empty restoration request");
        }
    }
    static void IdentityChecks()
    {
        var xbox=new ProcessIdentity{Pid=101,Path=@"C:\Apps\Xbox\Xbox.exe",AppId="Example.Xbox!App"};var other=new ProcessIdentity{Pid=102,Path=@"C:\Apps\Other\Other.exe",AppId="Example.Other!App"};
        Check(WindowIdentity.ChooseChild(new[]{xbox},null)==xbox,"A unique hosted child resolves to the app inside the frame");
        Check(WindowIdentity.ChooseChild(new[]{xbox,other},null)==null,"Ambiguous hosted processes are not arbitrarily chosen");
        Check(WindowIdentity.ChooseChild(new[]{xbox,other},xbox.AppId)==xbox,"Window app identity disambiguates multiple hosted children");
        Check(WindowIdentity.ChooseChild(new[]{xbox,xbox},null)==xbox,"Multiple child windows from one app are deduplicated");
        var host=new ProcessIdentity{Path=@"C:\Windows\System32\ApplicationFrameHost.exe"};Check(WindowIdentity.ChooseChild(new[]{host},null)==null,"Shared Application Frame Host is never selected as an app");
        var rule=new AppRule(Target(101,xbox.Path,xbox.AppId)){Show=false};var moved=Target(102,@"C:\Apps\Xbox-v2\Xbox.exe",xbox.AppId);
        Check(rule.Matches(moved),"Packaged rules survive an executable moving to another version folder");
        Check(!rule.Matches(Target(103,xbox.Path,other.AppId)),"A packaged rule cannot match a different app using the same executable path");
        Check(!new AppRule(host.Path){Show=false}.Matches(Target(104,host.Path)),"Legacy broad host rules do not affect unrelated hosted apps");
        Check(new AppRule(xbox.Path){Show=false}.Matches(Target(105,xbox.Path,xbox.AppId)),"Existing executable rules still match packaged app executables");
    }
    static void EngineChecks()
    {
        var xbox=Target(10,@"C:\Apps\Xbox.exe","Example.Xbox!App");var other=Target(20,@"C:\Apps\Other.exe","Example.Other!App");var platform=new FakeTaskbarPlatform();platform.Targets[xbox.Window]=xbox;platform.Targets[other.Window]=other;
        var rule=new AppRule(xbox){Show=false};
        using(var engine=new TaskbarEngine(true,platform))
        {
            engine.Rules(new[]{rule});Check(engine.Count==1&&platform.Hidden.All(h=>h==xbox.Window),"Hide requests target only the selected app's outer taskbar window");
            rule.Show=true;engine.Rules(new[]{rule});Check(engine.Count==0&&platform.Shown.Contains(xbox.Window)&&!engine.Polling,"Turning Show on restores the button and stops idle polling");
            rule.Show=false;engine.Rules(new[]{rule});engine.Paused=true;engine.Sweep();Check(engine.Count==0&&!engine.Polling,"Pause restores managed buttons and stops polling");
            engine.Paused=false;engine.Sweep();Check(engine.Count==1&&engine.Polling,"Resume reapplies the hide rule");
            platform.Targets[xbox.Window]=Target(10,@"C:\Apps\Xbox-v2.exe",xbox.AppId);engine.Sweep();Check(engine.Count==1,"The engine continues to identify a packaged app after a path change");
            platform.FailShow=true;engine.Rules(new AppRule[0]);Check(engine.Count==1&&engine.Polling&&engine.LastError.Contains("restore"),"Failed restoration remains tracked for retry");platform.FailShow=false;engine.Sweep();Check(engine.Count==0,"Pending restoration succeeds on retry");
            engine.Rules(new[]{rule});platform.Targets[xbox.Window]=Target(10,other.Path,other.AppId);int shows=platform.Shown.Count;engine.Rules(new AppRule[0]);Check(engine.Count==0&&platform.Shown.Count==shows,"A reused window for a different hosted app is not incorrectly restored");
            platform.Targets[xbox.Window]=xbox;engine.Rules(new[]{rule});platform.Targets.Remove(xbox.Window);engine.Sweep();Check(engine.Count==0,"Closed windows are removed from tracking");platform.Targets[xbox.Window]=xbox;engine.Rules(new[]{rule});
        }
        Check(platform.Shown.Last()==xbox.Window,"Normal engine exit restores the remaining app button");
        using(var engine=new TaskbarEngine(true,new FakeTaskbarPlatform())){engine.Rules(new[]{new AppRule(@"C:\Windows\System32\ApplicationFrameHost.exe"){Show=false}});Check(!engine.Polling&&engine.LastError.Contains("Pick"),"Legacy host rules explain how to repick without polling or hiding a shared host");}
        var omitted=new FakeTaskbarPlatform{OmitEnumeration=true};omitted.Targets[xbox.Window]=xbox;
        using(var engine=new TaskbarEngine(true,omitted))
        {
            engine.Rules(new[]{rule});Check(engine.Count==0,"An omitted window is not claimed as managed");
            engine.RememberPickedWindow(xbox);Check(engine.Count==1&&omitted.Hidden.Contains(xbox.Window),"The exact picked window is managed even when desktop enumeration omits it");
            Check(engine.Outcome(xbox.Window).Contains("not verified"),"Diagnostics distinguish API acceptance from visual verification");
            engine.Paused=true;engine.Sweep();Check(engine.Count==0&&omitted.Shown.Contains(xbox.Window),"Pause restores an enumeration-omitted picked window");
            engine.Paused=false;omitted.Targets[xbox.Window]=other;int calls=omitted.Hidden.Count;engine.Sweep();Check(omitted.Hidden.Count==calls&&engine.KnownWindows.Length==0,"A recycled picked handle cannot hide an unrelated app");
        }
    }
    static void DiscoveryChecks()
    {
        Check(Native.EligibilityReason(0x08040000,true,"ApplicationFrameWindow")=="eligible","Explicit APPWINDOW is not rejected by NOACTIVATE or ownership");
        Check(Native.EligibilityReason(0x80,false,"Tool")!="eligible","Ordinary tool windows remain excluded");
        Check(Native.EligibilityReason(0x08000000,false,"Overlay")!="eligible","Ordinary non-activating overlays remain excluded");
        Check(Native.EligibilityReason(0,true,"Dialog")!="eligible","Owned dialogs without APPWINDOW remain excluded");
        Check(Native.EligibilityReason(0x40000,false,"Shell_TrayWnd")!="eligible","Shell surfaces cannot opt into hiding through APPWINDOW");
        using(var form=new Form{Text="Discovery fixture"})
        {
            form.Show();form.Hide();form.Show();Pump(30);int before=Native.GetWindowLong(form.Handle,-20);var windows=Native.TopLevelWindows();
            Check(windows.Contains(form.Handle)&&windows.Distinct().Count()==windows.Count,"Supplemented discovery retains classic windows without duplicates");
            var settings=new Settings();settings.Apps.Add(new AppRule(Application.ExecutablePath));string report=TaskbarDiagnostics.Build(settings,null);
            Check(report.Contains("APP:")&&report.Contains("eligibility=eligible")&&report.Contains("ExStyle="),"Read-only diagnostics report rule matching, styles, and eligibility");
            Check(before==Native.GetWindowLong(form.Handle,-20)&&form.Visible,"Diagnostic collection leaves the window style and visibility unchanged");
            form.Close();
        }
        string home=Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        if(String.IsNullOrEmpty(home))home=Path.Combine(@"C:\","Users","DiagnosticUser");
        Check(!TaskbarDiagnostics.Redact(home+@"\App.exe").Contains(home),"Diagnostic export redacts the current account's home path");
    }
    static void UiChecks(string directory)
    {
        var target=Target(150,@"C:\Apps\Example\Example.exe","Example.Package!App");target.Name="Example app";var settings=new Settings();var platform=new FakeTaskbarPlatform();platform.Targets[target.Window]=target;string file=Path.Combine(directory,"ui-settings.json");
        using(var form=new MainForm(settings,file,false,true,platform))
        {
            form.Show();Pump(60);Check(form.TestStartup.Checked,"Startup is enabled by default on a fresh setup");form.TestStartup.Checked=false;Check(Settings.Read(file).StartupEnabled==false,"Startup opt-out persists immediately");
            form.TestTheme(true);Check(Theme.Light&&Settings.Read(file).ThemeMode=="light","Light theme applies and persists");form.TestTheme(false);Check(!Theme.Light&&Settings.Read(file).ThemeMode=="dark","Dark theme can be restored");
            form.TestPick(target);Check(settings.Apps.Count==1&&!settings.Apps[0].Show&&platform.Hidden.Contains(target.Window),"Picking a window saves a hide rule and applies it immediately");
            Check(form.TestErrors.Count==0,"Successful picking does not add a success message to the error log");
            Check(Settings.Read(file).Apps.Single().AppId==target.AppId,"The picked app identity persists with its rule");
            var grid=form.TestGrid;var cell=grid.Rows[0].Cells[0];grid.CurrentCell=cell;grid.BeginEdit(false);typeof(DataGridViewCheckBoxCell).GetMethod("OnContentClick",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(cell,new object[]{new DataGridViewCellEventArgs(0,0)});grid.CommitEdit(DataGridViewDataErrorContexts.Commit);grid.EndEdit();
            Check(settings.Apps[0].Show&&platform.Shown.Contains(target.Window)&&cell.ContentBounds.Width>=34,"The full switch click target restores a picked app");
            grid.BeginEdit(false);typeof(DataGridViewCheckBoxCell).GetMethod("OnKeyUp",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(cell,new object[]{new KeyEventArgs(Keys.Space),0});grid.CommitEdit(DataGridViewDataErrorContexts.Commit);grid.EndEdit();Check(!settings.Apps[0].Show,"Visibility switches retain keyboard Space support");
            form.TestPick(target);Check(settings.Apps.Count==1&&!settings.Apps[0].Show,"Picking a known app hides it without creating duplicate rules");
            settings.Apps.Add(new AppRule(target.Path){Show=false});form.TestPick(target);Check(settings.Apps.Count==1,"Picking consolidates duplicate path and app-identity rules so one Show switch can restore the app");
            form.TestOwn.Checked=true;Check(!form.ShowInTaskbar&&form.TestTrayConfigured,"Hiding own taskbar button retains its tray menu configuration");form.TestOwn.Checked=false;
            form.TestNavigate(3);form.Size=form.MinimumSize;Pump(30);var toggleBounds=form.RectangleToClient(form.TestStartup.RectangleToScreen(form.TestStartup.ClientRectangle));Check(form.ClientRectangle.Contains(toggleBounds),"Startup remains visible at minimum window size");
            form.TestCancelPicker();Pump(150);Check(form.TestPickerClosed&&form.Visible,"Cancelling the picker returns to the manager");
            form.TestPaused.Checked=true;int calls=platform.Hidden.Count;form.TestPick(target);Check(platform.Hidden.Count==calls&&!settings.Apps[0].Show,"Picker saves its hide choice while respecting a deliberate pause");form.TestPaused.Checked=false;
            form.Close();Check(!form.Visible&&!form.IsDisposed,"Closing the editor keeps it running in the tray");form.TestExit();Check(form.IsDisposed,"Explicit exit disposes the editor cleanly");
        }
        Check(platform.Shown.Last()==target.Window,"Editor exit restores its tracked app button");
    }
    static void HostedCheck(string directory)
    {
        string fixture=Path.Combine(directory,"ApplicationFrameHost.exe"),hostReport=Path.Combine(directory,"host-hwnd.txt"),childReport=Path.Combine(directory,"child-hwnd.txt");File.Copy(Application.ExecutablePath,fixture,true);Process host=null,child=null;
        try
        {
            host=Process.Start(new ProcessStartInfo(fixture,"--host-fixture \""+hostReport+"\""){UseShellExecute=false,WindowStyle=ProcessWindowStyle.Hidden});WaitFile(hostReport);
            IntPtr root=new IntPtr(Int64.Parse(File.ReadAllText(hostReport)));
            Check(WindowIdentity.Resolve(root)==null,"An empty real ApplicationFrameHost fixture does not become a broad host rule");
            child=Process.Start(new ProcessStartInfo(Application.ExecutablePath,"--child-fixture "+root.ToInt64()+" \""+childReport+"\""){UseShellExecute=false,WindowStyle=ProcessWindowStyle.Hidden});WaitFile(childReport);
            var childHandle=new IntPtr(Int64.Parse(File.ReadAllText(childReport)));Check(Native.GetAncestor(childHandle,2)==root,"Controlled child is hosted inside a different process's real window");
            var target=WindowIdentity.Resolve(root);Check(target!=null&&target.Window==root&&String.Equals(target.Path,Application.ExecutablePath,StringComparison.OrdinalIgnoreCase),"Real child-window enumeration resolves the hosted executable while retaining its outer taskbar HWND");
        }
        finally
        {
            File.WriteAllText(childReport+".stop","");File.WriteAllText(hostReport+".stop","");
            foreach(var process in new[]{child,host})if(process!=null){if(!process.WaitForExit(2500))process.Kill();process.Dispose();}
        }
    }
    static IEnumerable<Control> Descendants(Control parent)
    {
        foreach(Control child in parent.Controls){yield return child;foreach(var nested in Descendants(child))yield return nested;}
    }
    static void UiDrawingChecks(string directory)
    {
        DashboardTests.Run(Path.Combine(directory,"dashboard"));
        Check(Environment.ExitCode==0,"Dashboard offscreen layout and behavior checks pass");
    }    static void WaitFile(string file){var watch=Stopwatch.StartNew();while(!File.Exists(file)&&watch.ElapsedMilliseconds<7000)Pump(30);if(!File.Exists(file))throw new Exception("Controlled fixture did not start.");}
    internal static void Preview(string directory)
    {
        Directory.CreateDirectory(directory);var settings=new Settings{Apps=new List<AppRule>{new AppRule(@"C:\Apps\Music\Music.exe"){Show=false},new AppRule(@"C:\Apps\Chat\Chat.exe"){Show=false},new AppRule(Target(1,@"C:\Program Files\WindowsApps\Example.Xbox\Xbox.exe","Example.Xbox!App")){Name="Xbox",Show=false},new AppRule(@"C:\Apps\Notes\Notes.exe")}};
        using(var form=new MainForm(settings,Path.Combine(directory,"preview-settings.json"),false,true))
        {
            form.Show();Pump(50);foreach(bool light in new[]{false,true}){form.TestTheme(light);Pump(30);Render(form,Path.Combine(directory,light?"Interface-Light.png":"Interface-Dark.png"));form.Size=form.MinimumSize;Pump(30);Render(form,Path.Combine(directory,light?"Compact-Light.png":"Compact-Dark.png"));form.ClientSize=new Size(1200,800);}
            form.TestErrors.Report("Controlled preview: HRESULT: 0x80070005");
            foreach(bool light in new[]{false,true}){form.TestTheme(light);Pump(30);Render(form,Path.Combine(directory,light?"ErrorLog-Light.png":"ErrorLog-Dark.png"));}
            form.TestExit();
        }
    }
    static void Render(MainForm form,string file){using(var bitmap=new Bitmap(form.ClientSize.Width,form.ClientSize.Height)){form.Controls[0].DrawToBitmap(bitmap,new Rectangle(Point.Empty,form.ClientSize));bitmap.Save(file);}}
}
