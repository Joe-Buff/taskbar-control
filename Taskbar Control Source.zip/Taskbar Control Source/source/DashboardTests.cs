using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Windows.Forms;
using TaskbarStyling;

internal static class DashboardTests
{
    static IEnumerable<Control> All(Control c){foreach(Control child in c.Controls){yield return child;foreach(var item in All(child))yield return item;}}
    internal static void Run(string directory)
    {
        Directory.CreateDirectory(directory);var results=new List<string>();
        try
        {
            var settings=new Settings{StartupEnabled=false};settings.Apps.Add(new AppRule(Path.Combine(Environment.SystemDirectory,"cmd.exe")){Show=false,Name="Command Prompt"});settings.Apps.Add(new AppRule(@"C:\Apps\MusicPlayer.exe"){Show=false,Name="Music Player"});settings.Apps.Add(new AppRule(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),"explorer.exe")){Name="File Explorer"});settings.Apps.Add(new AppRule(@"C:\Apps\RecordingStudio.exe"){Show=false,Name="Recording Studio"});settings.Apps.Add(new AppRule(Path.Combine(Environment.SystemDirectory,"notepad.exe")){Name="Notepad"});
            using(var form=new MainForm(settings,Path.Combine(directory,"test-settings.json"),false,true))
            {
                form.StartPosition=FormStartPosition.Manual;form.Location=new Point(-16000,-16000);form.ShowInTaskbar=false;form.Show();SelfTest.Pump(100);
                using(var warmup=new Bitmap(form.Width,form.Height))form.Controls[0].DrawToBitmap(warmup,form.Controls[0].ClientRectangle);
                SelfTest.Pump(1500);
                foreach(bool light in new[]{false,true})
                {
                    form.TestTheme(light);form.TestNavigate(0);form.ClientSize=new Size(1240,850);SelfTest.Pump(60);Render(form,directory,light?"Interface-Light.png":"Interface-Dark.png");Validate(form);results.Add("PASS: "+(light?"Light":"Dark")+" dashboard renders offscreen with no overlapping primary controls");
                    form.TestNavigate(3);SelfTest.Pump(60);Render(form,directory,light?"Settings-Light.png":"Settings-Dark.png");Validate(form);
                    form.TestNavigate(0);form.ClientSize=new Size(1060,720);SelfTest.Pump(60);Render(form,directory,light?"Compact-Light.png":"Compact-Dark.png");Validate(form);
                    var grid=(BufferedAppGrid)form.TestGrid;var scrollbar=All(form).OfType<ThemedScrollBar>().Single(c=>c.AccessibleName=="Scroll app list");
                    if(!scrollbar.Visible||scrollbar.Width<12||scrollbar.Height<30)throw new Exception("Overflow scrollbar missing or collapsed");
                    TestScrolling(form,grid,scrollbar,directory,light);results.Add("PASS: "+(light?"Light":"Dark")+" scrollbar matches theme, handles wheel/keys/drag, and reaches the final app after resize");
                    results.Add("PASS: Only full app rows are visible at top/middle/end through every pixel of a row-height resize cycle");
                    form.TestSidebar();SelfTest.Pump(40);Render(form,directory,light?"Sidebar-Light.png":"Sidebar-Dark.png");Validate(form);form.TestSidebar();
                    form.ClientSize=new Size(1700,1000);SelfTest.Pump(60);Validate(form);Render(form,directory,light?"Wide-Light.png":"Wide-Dark.png");
                    foreach(var size in new[]{new Size(1060,720),new Size(1240,850),new Size(1700,720),new Size(1060,1000),new Size(2560,1440),new Size(3840,2160)})
                    {
                        form.ClientSize=size;SelfTest.Pump(15);Validate(form);form.TestSidebar();SelfTest.Pump(15);Validate(form);
                        if(size==new Size(1240,850))Render(form,directory,light?"Collapsed-Light.png":"Collapsed-Dark.png");
                        form.TestSidebar();Validate(form);
                    }
                    form.Size=form.MinimumSize;SelfTest.Pump(15);Validate(form);form.TestSidebar();Validate(form);form.TestSidebar();
                    results.Add("PASS: "+(light?"Light":"Dark")+" sidebar buttons and icons stay inside their container from the true minimum size through 4K, expanded and collapsed");
                }
                form.TestTheme(false);form.ClientSize=new Size(1240,850);form.TestNavigate(1);SelfTest.Pump(40);Render(form,directory,"Folders.png");Validate(form);
                if(form.TestIconCount==0)throw new Exception("No real executable icon was loaded");results.Add("PASS: Actual executable icons load asynchronously; unavailable icons use the window-outline fallback");
                form.TestNavigate(2);form.TestErrors.Report("HRESULT: 0x80070005 Access is denied");SelfTest.Pump(40);Render(form,directory,"Activity.png");Validate(form);
                if(!form.TestErrors.Readable.Contains("Windows denied access"))throw new Exception("Human-readable error translation missing");
                TestErrors(form,directory,results);
                if(form.TestUpdateBusy)throw new Exception("An update started without a click");results.Add("PASS: Opening, navigation, themes, and resizing never start an update");
                form.TestNavigate(0);form.TestGrid.Rows[0].Cells[0].Value=false;SelfTest.Pump(40);if(Settings.Read(Path.Combine(directory,"test-settings.json")).Apps.All(a=>a.Show))throw new Exception("Rule did not save");results.Add("PASS: Visibility switch saves rules with inactive test backend");
                form.Hide();form.OpenWindow();SelfTest.Pump(40);if(!form.Visible||form.WindowState==FormWindowState.Minimized)throw new Exception("Hidden window failed to reopen");results.Add("PASS: Hidden UI reopens without starting a new app (offscreen test)");
                form.TestExit();
            }
            results.Add("PASS: No live taskbar backend, global input, startup registry changes, or real configuration files used.");
        }
        catch(Exception ex){results.Add("FAIL: "+ex);Environment.ExitCode=1;}
        File.WriteAllLines(Path.Combine(directory,"dashboard-results.txt"),results);
    }
    static void Invoke(Control control,string method,EventArgs args){control.GetType().GetMethod(method,BindingFlags.Instance|BindingFlags.NonPublic).Invoke(control,new object[]{args});}
    static void TestScrolling(MainForm form,BufferedAppGrid grid,ThemedScrollBar bar,string directory,bool light)
    {
        if(grid.ScrollBars!=ScrollBars.None||bar.Left<grid.Right)throw new Exception("Native scrollbar present or custom gutter overlaps rows");
        int original=grid.Rows.Count;
        for(int i=0;i<22;i++)grid.Rows.Add(true,"Example app "+(i+1),@"C:\Apps\Example.exe");
        grid.ScrollToRow(0);Invoke(bar,"OnKeyDown",new KeyEventArgs(Keys.End));
        if(grid.FirstDisplayedScrollingRowIndex!=grid.LastScrollRow||!grid.Rows[grid.Rows.Count-1].Displayed)throw new Exception("End does not reveal last row");
        Invoke(bar,"OnKeyDown",new KeyEventArgs(Keys.Home));if(grid.FirstDisplayedScrollingRowIndex!=0)throw new Exception("Home failed");
        Invoke(bar,"OnKeyDown",new KeyEventArgs(Keys.PageDown));if(grid.FirstDisplayedScrollingRowIndex!=grid.ViewportRows)throw new Exception("Page down failed");
        grid.ScrollToRow(0);grid.WheelScroll(-SystemInformation.MouseWheelScrollDelta);
        if(SystemInformation.MouseWheelScrollLines!=0&&grid.FirstDisplayedScrollingRowIndex==0)throw new Exception("Wheel failed");
        // Exercise thumb movement directly inside the offscreen fixture. No Focus,
        // capture, mouse movement, or global input is sent to the user's desktop.
        typeof(ThemedScrollBar).GetField("dragging",BindingFlags.Instance|BindingFlags.NonPublic).SetValue(bar,true);
        Invoke(bar,"OnMouseMove",new MouseEventArgs(MouseButtons.Left,0,9,bar.Height,0));
        typeof(ThemedScrollBar).GetField("dragging",BindingFlags.Instance|BindingFlags.NonPublic).SetValue(bar,false);
        if(grid.FirstDisplayedScrollingRowIndex!=grid.LastScrollRow)throw new Exception("Thumb drag did not reach bottom");
        grid.ScrollToRow(0);
        var originalSize=form.ClientSize;
        for(int delta=0;delta<grid.RowTemplate.Height;delta++)
        {
            form.ClientSize=new Size(originalSize.Width,originalSize.Height+delta);
            foreach(int start in new[]{0,3,grid.LastScrollRow}){grid.ScrollToRow(start);ValidateWholeRows(grid);}
        }
        form.ClientSize=originalSize;grid.ScrollToRow(0);
        using(var pixels=new Bitmap(bar.Width,bar.Height))
        {
            bar.DrawToBitmap(pixels,bar.ClientRectangle);var edge=pixels.GetPixel(0,bar.Height/2);
            if(edge.ToArgb()!=Theme.Surface.ToArgb())throw new Exception("Scrollbar gutter did not follow the theme");
            var thumb=pixels.GetPixel(8,bar.Thumb.Top+bar.Thumb.Height/2);
            if(thumb.ToArgb()==edge.ToArgb()||(!light&&thumb.R>200))throw new Exception("Scrollbar thumb is invisible or too bright");
        }
        Render(form,directory,light?"Scrolling-Light.png":"Scrolling-Dark.png");
        for(int i=grid.Rows.Count-1;i>=original;i--)grid.Rows.RemoveAt(i);grid.ScrollToRow(0);
        // Search rebuilds the grid and is a common way scroll ranges become stale.
        var search=All(form).OfType<ModernTextField>().Single();search.Text="no-such-app-fixture";
        if(grid.Rows.Count!=0||bar.TabStop)throw new Exception("Empty search left an active scroll range");
        search.Text="";if(grid.Rows.Count!=original)throw new Exception("Clearing search did not restore rows");
        grid.CurrentCell=grid.Rows[grid.Rows.Count-1].Cells[1];if(!grid.Rows[grid.Rows.Count-1].Displayed)throw new Exception("Selection did not scroll into view");grid.ScrollToRow(0);
    }
    static void TestErrors(MainForm form,string directory,List<string> results)
    {
        var samples=new Dictionary<string,string>{
            {"HRESULT: 0x80070002","AE0001"},{"HRESULT: 0x80070005","AE0002"},{"This Windows taskbar build is not supported","AE0003"},
            {"The app did not expose a taskbar identity","AE0004"},{"HRESULT: 0x800705B4","AE0005"},{"HRESULT: 0x80070020","AE0006"},
            {"Could not save settings","AE0007"},{"Startup could not be configured","AE0008"},{"Incomplete symbol file","AE0009"},
            {"Scan failed","AE0010"},{"Application Frame Host is shared","AE0011"},{"Could not hide a button","AE0012"},
            {"Could not start window selection","AE0013"},{"Update failed: Cannot find the file","AE0014"},{"HRESULT: 0x81234567","AE9999"}};
        foreach(var sample in samples)if(ErrorHelp.Explain(sample.Key).Code!=sample.Value)throw new Exception("Wrong diagnosis for "+sample.Key);
        var log=form.TestErrors;var clear=All(log).OfType<FlatButton>().Single(b=>b.Text=="Clear log");clear.PerformClick();
        log.Report("Preparing taskbar-only hiding");if(log.Count!=0)throw new Exception("Progress reported as an error");
        var preview=All(form).OfType<Label>().Single(c=>c.AccessibleName=="Latest error and suggested fix");
        log.Report("HRESULT: 0x80070002");log.Report("HRESULT: 0x80070002");
        if(log.Count!=1||!log.Readable.Contains("repeated 2 times")||!preview.Text.StartsWith("AE0001"))throw new Exception("Repeated error or preview not synchronized");
        if(!log.Details.Contains("AE0001")||!log.Details.Contains("0x80070002")||!log.Details.Contains(UpdateService.CurrentVersion.ToString()))throw new Exception("Diagnostic report lacks code, original error, or version");
        form.TestNavigate(0);Render(form,directory,"Error-Preview.png");form.ClientSize=new Size(1060,720);SelfTest.Pump(40);Render(form,directory,"Error-Compact.png");
        var needed=TextRenderer.MeasureText(preview.Text,preview.Font,new Size(preview.Width,int.MaxValue),TextFormatFlags.WordBreak);
        if(needed.Height>preview.Height)throw new Exception("Latest error is clipped at compact size");
        Invoke(preview,"OnClick",EventArgs.Empty);if(form.TestPage!="Activity")throw new Exception("Footer did not open Activity");
        form.ClientSize=new Size(1240,850);for(int i=0;i<65;i++)log.Report("Unknown fixture error "+i);
        if(log.Count!=50)throw new Exception("Error log is not bounded");
        var body=All(log).OfType<ScrollableLogTextBox>().Single();var bar=All(log).OfType<ThemedScrollBar>().Single();
        Invoke(bar,"OnKeyDown",new KeyEventArgs(Keys.End));if(body.FirstLine<=0||body.ScrollBars!=ScrollBars.None)throw new Exception("Themed log scrolling failed");
        body.ScrollToLine(0);body.WheelScroll(-SystemInformation.MouseWheelScrollDelta);
        if(SystemInformation.MouseWheelScrollLines!=0&&body.FirstLine==0)throw new Exception("Log wheel failed");
        body.Select(0,8);if(body.SelectionLength!=8)throw new Exception("Log text is no longer selectable");
        Render(form,directory,"Activity-Long.png");clear.PerformClick();
        if(preview.Text!="No errors to report."||log.Count!=0||bar.TabStop)throw new Exception("Clearing Activity did not reset footer or scrollbar");
        log.Report("HRESULT: 0x80070002");Render(form,directory,"Activity.png");clear.PerformClick();
        if(All(form).Any(c=>c.Visible&&c.Text=="Hiding active"))throw new Exception("Obsolete status badge remains");
        results.Add("PASS: All 15 diagnostic categories, retained Windows details, repeated-error counts, 50-entry bound, footer navigation and clearing");
        results.Add("PASS: Full Activity log uses themed scrolling and retains selectable text");
    }
    static void Validate(MainForm form)
    {
        if(form.TestGrid.Visible)ValidateWholeRows((BufferedAppGrid)form.TestGrid);
        foreach(var nav in All(form).OfType<DashboardNav>().Where(c=>c.Visible))
        {
            if(nav.Width<40||nav.Height<36||!nav.Parent.ClientRectangle.Contains(nav.Bounds))throw new Exception("Sidebar button clipped: "+nav.Text+" "+nav.Bounds+" in "+nav.Parent.ClientRectangle);
            if(!nav.Parent.Parent.DisplayRectangle.Contains(nav.Parent.Bounds))throw new Exception("Navigation layout exceeds the sidebar");
        }
        foreach(var control in All(form).Where(c=>c.Visible&&(c is FlatButton||c is ModernToggle||c is ModernTextField||c is ModernCombo)))
        {
            if(control.Width<16||control.Height<16)throw new Exception("Collapsed control: "+control.Text);
            if(control.Parent is FlowLayoutPanel&&!control.Parent.ClientRectangle.Contains(control.Bounds))throw new Exception("Clipped action: "+control.Text);
        }
    }
    static void ValidateWholeRows(BufferedAppGrid grid)
    {
        if((grid.ClientSize.Height-grid.ColumnHeadersHeight)%grid.RowTemplate.Height!=0)throw new Exception("List viewport does not fit whole rows");
        foreach(DataGridViewRow row in grid.Rows)
        {
            if(!row.Displayed)continue;
            var full=grid.GetRowDisplayRectangle(row.Index,false);var clipped=grid.GetRowDisplayRectangle(row.Index,true);
            if(full.Height!=row.Height||clipped.Height!=row.Height||full.Top<grid.ColumnHeadersHeight||full.Bottom>grid.ClientSize.Height)throw new Exception("Partially visible app row: "+row.Index+" "+full+" clipped "+clipped);
        }
    }
    static void Render(MainForm form,string directory,string name){using(var image=new Bitmap(form.ClientSize.Width,form.ClientSize.Height)){form.Controls[0].DrawToBitmap(image,new Rectangle(Point.Empty,image.Size));image.Save(Path.Combine(directory,name));}}
}
internal static class UpdateTests
{
    sealed class QuietProgress:IProgress<string>{public void Report(string message){}}
    internal static void NetworkRun(string directory)
    {
        Directory.CreateDirectory(directory);var log=new List<string>();
        try
        {
            var release=UpdateService.CheckAsync(System.Threading.CancellationToken.None).GetAwaiter().GetResult();
            log.Add("PASS: Actual .NET Framework HTTPS request parsed latest public GitHub release "+release.Version);
            if(!release.Installable)throw new Exception("Official release has no verifiable installer");
            string file=UpdateService.DownloadAsync(release,new QuietProgress(),System.Threading.CancellationToken.None).GetAwaiter().GetResult();
            log.Add("PASS: Downloaded through GitHub redirects and verified size, SHA-256, and EXE signature. Installer was NOT executed.");
            File.Delete(file);Directory.Delete(Path.GetDirectoryName(file));log.Add("PASS: Test download cleaned up; live installation unchanged.");
        }
        catch(Exception ex){log.Add("FAIL: "+ex);Environment.ExitCode=1;}
        File.WriteAllLines(Path.Combine(directory,"network-results.txt"),log);
    }
    static readonly List<string> results=new List<string>();
    static void Check(bool condition,string name){if(!condition)throw new Exception(name);results.Add("PASS: "+name);}
    static string Sample(string tag,string name,string hash){return "{\"tag_name\":\""+tag+"\",\"name\":\""+name+"\",\"html_url\":\"https://github.com/Joe-Buff/taskbar-control/releases/tag/v1.2.0\",\"draft\":false,\"prerelease\":false,\"assets\":[{\"name\":\"Taskbar.Control.Setup.exe\",\"browser_download_url\":\"https://github.com/Joe-Buff/taskbar-control/releases/download/v1.2.0/Taskbar.Control.Setup.exe\",\"size\":4,\"digest\":\"sha256:"+hash+"\"}]}";}
    internal static void Run(string directory)
    {
        Directory.CreateDirectory(directory);
        try
        {
            string hash=new string('a',64);var sample=Sample("v1.2.0","Version 1.2.0",hash);var release=UpdateService.Parse(sample);
            Check(release.Version==new Version(1,2,0,0)&&release.Installable,"Stable semver and exact installer asset are accepted");
            Check(UpdateService.Parse(Sample("taskbarcontrol","Version 1.0",hash)).Version==new Version(1,0,0,0),"Existing non-version GitHub tag falls back to Version 1.0 release title");
            Check(UpdateService.ReadVersion("v1.10.0")>UpdateService.ReadVersion("v1.9.9"),"Versions compare numerically");
            Check(UpdateService.ReadVersion("v1.10")==new Version(1,10,0,0)&&UpdateService.ReadVersion("Version 1.10")==new Version(1,10,0,0)&&UpdateService.ReadVersion("v1.10")>new Version(1,0,0,0),"Public tag/title 1.10 match internal 1.10.0.0 and upgrade the previous public release");
            Check(UpdateService.ReadVersion("1.2.0-beta")==null&&UpdateService.ReadVersion("notes 999.0")==null,"Ambiguous and prerelease names are not treated as stable versions");
            Check(!UpdateService.Parse(Sample("v1.2.0","","")).Installable,"Missing checksum prevents automatic installation");
            Check(!UpdateService.Parse(sample.Replace("Taskbar.Control.Setup.exe","Unknown.exe")).Installable,"Unrelated executable asset is rejected");
            Check(!UpdateService.IsRepositoryUrl("https://github.com/Joe-Buff/taskbar-control-other/releases/download/a.exe","releases/download/"),"Repository lookalike is rejected");
            Check(!UpdateService.IsRepositoryUrl("http://github.com/Joe-Buff/taskbar-control/releases/tag/v1.2","releases/tag/"),"HTTP release URLs are rejected");
            bool rejected=false;try{UpdateService.Parse(sample.Replace("\"prerelease\":false","\"prerelease\":true"));}catch(InvalidDataException){rejected=true;}Check(rejected,"Prerelease metadata is rejected");
            rejected=false;try{UpdateService.Parse("not JSON");}catch(InvalidDataException){rejected=true;}Check(rejected,"Malformed metadata fails safely");
            string file=Path.Combine(directory,"checksum-fixture.bin");File.WriteAllBytes(file,new byte[]{0x4d,0x5a,0,0});using(var sha=SHA256.Create())release.Hash=BitConverter.ToString(sha.ComputeHash(File.ReadAllBytes(file))).Replace("-","");UpdateService.VerifyInstaller(file,release);results.Add("PASS: Matching size, checksum, and Windows executable signature verify");
            File.WriteAllBytes(file,new byte[]{0x4d,0x5a,0,1});rejected=false;try{UpdateService.VerifyInstaller(file,release);}catch(InvalidDataException){rejected=true;}Check(rejected,"Modified download never reaches the installer");
            Check(UpdateService.InstallerArguments(@"C:\Apps\Taskbar Control")==@"/UPDATE=1 /D=C:\Apps\Taskbar Control","Update targets the existing installation including paths with spaces");
            Check(UpdateService.FriendlyError(new System.Net.WebException("offline")).Contains("Could not reach GitHub"),"Offline failures are not reported as up to date");
            results.Add("PASS: Update tests use local fixtures only; no network request, installer execution, or real settings change.");
        }
        catch(Exception ex){results.Add("FAIL: "+ex);Environment.ExitCode=1;}
        File.WriteAllLines(Path.Combine(directory,"update-results.txt"),results);
    }
}
