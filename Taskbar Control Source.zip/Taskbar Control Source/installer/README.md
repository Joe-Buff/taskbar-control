# Taskbar Control installer

Build with the official [NSIS 3.13](https://nsis.sourceforge.io/Download) Unicode compiler. NSIS is a build tool only; customers need just Taskbar Control Setup.exe.

```powershell
./source/package.ps1 -SkipBuild -Destination <empty-release-folder> -InstallerCompiler <path-to-makensis.exe>
```

Alternatively, run build-installer.ps1 with -Compiler, -Payload (the clean customer package folder), and -Output. Rebuild the app first if app source files changed. Customers receive one controls guide and a short estimated resource-use note; test reports and file hashes are not installed.

The setup installs for the current Windows account. It provides a writable destination-folder choice and checkboxes for Windows startup, a desktop shortcut, and Start menu shortcuts. Existing startup opt-outs are read before the options page. The chosen startup option is saved to settings before the main app opens; the app's own startup toggle stays available. On upgrades, shortcuts are retargeted to the chosen folder. Old folders from manually moved portable copies are not deleted.

The selected install folder always contains Uninstaller.exe, an Uninstall Taskbar Control.lnk shortcut, and README.txt with the basic controls guide. These do not depend on the optional desktop or Start menu shortcut choices. A registered same-folder upgrade removes the older Uninstall.exe filename after the new uninstaller is created.

The uninstaller is registered under the current user's Installed apps list. It requests normal app exit and waits, rather than terminating a running process. If a running copy does not support the exit request, exit it through the tray first. Uninstall removes only named installed files and shortcuts, and removes the startup entry only if it still points to that installation. Saved rules and unrelated files are preserved. A moved or superseded uninstaller refuses to operate.

For unattended setup: /S /STARTUP=0|1 /DESKTOP=0|1 /STARTMENU=0|1 /D=<absolute-install-folder>. The /D option must come last and its path must not be quoted, per NSIS syntax. Silent setup does not open the app at the end.

For an in-app upgrade: /UPDATE=1 /D=<the current app folder>. This skips directory/component changes, preserves startup and shortcuts, and never writes settings.json. The installer does not uninstall the app first.

## Tests and limits

test-installer.ps1 uses a separately compiled fixture with -TestId and -TestConfig. It redirects shortcuts and settings into the workspace and uses an INI-backed registration double. It tests file installation, settings preservation, checkbox choices, shortcut targets, upgrades, moved-uninstaller refusal, and cleanup. The production build uses actual HKCU entries; those writes and Windows sign-in startup require separate integration testing.

The release setup is unsigned. For public distribution, the publisher can sign both the app and installer with their own code-signing certificate. No publisher identity, certificate, credentials, or personal settings are embedded.

The compiler ZIP was downloaded from the NSIS project's official SourceForge location: https://downloads.sourceforge.net/project/nsis/NSIS%203/3.13/nsis-3.13.zip. SHA-256: BA63DFFC4410EE89193E1CB5A41989991BD77C61068DA17E3156D136B7B0B3D8. Tool binaries and test fixtures are excluded from the publisher package.
