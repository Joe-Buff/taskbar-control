param([Parameter(Mandatory=$true)][string]$Compiler,[Parameter(Mandatory=$true)][string]$Payload,[Parameter(Mandatory=$true)][string]$Output,[string]$TestId,[string]$TestConfig)
$ErrorActionPreference='Stop'
$compilerPath=(Resolve-Path -LiteralPath $Compiler).Path
$payloadPath=(Resolve-Path -LiteralPath $Payload).Path
$outputPath=[IO.Path]::GetFullPath($Output)
New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($outputPath)) -Force | Out-Null
$arguments=@('/V3',('/DPAYLOAD='+$payloadPath),('/DOUTPUT='+$outputPath))
if($TestId){if(-not $TestConfig){throw 'TestConfig is required for an isolated test build.'};$arguments+=('/DTEST_MODE='+$TestId);$arguments+=('/DTEST_CONFIG='+[IO.Path]::GetFullPath($TestConfig))}
$arguments+=(Join-Path $PSScriptRoot 'TaskbarControl.nsi')
& $compilerPath @arguments
if($LASTEXITCODE -ne 0){throw 'Installer compilation failed.'}
Get-FileHash -LiteralPath $outputPath -Algorithm SHA256
