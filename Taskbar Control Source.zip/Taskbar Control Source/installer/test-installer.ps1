param([Parameter(Mandatory=$true)][string]$Setup,[Parameter(Mandatory=$true)][string]$Root,[Parameter(Mandatory=$true)][string]$TestId,[Parameter(Mandatory=$true)][string]$TestConfig,[Parameter(Mandatory=$true)][string]$App)
$ErrorActionPreference='Stop'
$setupPath=(Resolve-Path -LiteralPath $Setup).Path
$testRoot=[IO.Path]::GetFullPath($Root)
$install=Join-Path $testRoot 'Custom folder with spaces'
$config=[IO.Path]::GetFullPath($TestConfig)
$expectedFileVersion=(Get-Item -LiteralPath $App).VersionInfo.FileVersion
$expectedVersion=([version]$expectedFileVersion).ToString(3)
$reg='Software\TaskbarControlInstallerTests\'+$TestId
$results=[Collections.Generic.List[string]]::new()
function Check([bool]$Value,[string]$Message){if(-not $Value){throw $Message};$results.Add('PASS: '+$Message)}
function RunSetup([string]$Options){$p=Start-Process -FilePath $setupPath -ArgumentList ('/S '+$Options+' /D='+$install) -WindowStyle Hidden -Wait -PassThru;if($p.ExitCode -ne 0){throw ('Setup returned '+$p.ExitCode)}}
function ReadValue([string]$Subkey,[string]$Name){$section='['+$reg+'\'+$Subkey+']';$active=$false;foreach($line in Get-Content -LiteralPath ($config+'.registration.ini')){if($line.StartsWith('[')){$active=$line -eq $section};if($active -and $line.StartsWith($Name+'=')){return $line.Substring($Name.Length+1)}};return $null}
function Uninstall(){if(Test-Path -LiteralPath (Join-Path $install 'Uninstaller.exe')){Start-Process -FilePath (Join-Path $install 'Uninstaller.exe') -ArgumentList '/S' -WindowStyle Hidden -Wait | Out-Null;$clock=[Diagnostics.Stopwatch]::StartNew();while((Test-Path -LiteralPath (Join-Path $install 'Uninstaller.exe')) -and $clock.ElapsedMilliseconds -lt 10000){Start-Sleep -Milliseconds 100}}}
try {
 New-Item -ItemType Directory -Path $testRoot -Force | Out-Null
 $saved=@{Apps=@(@{Path='C:\Apps\Example.exe';Show=$false});Folders=@();HideOwnTaskbar=$true;StartupEnabled=$false;ThemeMode='light'}
 [IO.File]::WriteAllText($config,($saved | ConvertTo-Json -Depth 5))
 RunSetup '/STARTUP=1 /DESKTOP=1 /STARTMENU=1'
 Check ((Get-FileHash -LiteralPath (Join-Path $install 'TaskbarControl.exe')).Hash -eq (Get-FileHash -LiteralPath $App).Hash) 'Custom-directory installation matches the tested app byte for byte'
 Check ((ReadValue 'Install' 'InstallLocation') -eq $install) 'The custom installation directory is registered'
 Check ((ReadValue 'Uninstall' 'DisplayName') -eq 'Taskbar Control') 'The uninstaller registration has the correct display name'
 Check ((ReadValue 'Uninstall' 'DisplayVersion') -eq $expectedVersion) ('Windows registers the updated release as version '+$expectedVersion)
 Check ((Get-Item -LiteralPath (Join-Path $install 'TaskbarControl.exe')).VersionInfo.FileVersion -eq $expectedFileVersion) ('The installed executable uses internal version '+$expectedFileVersion)
 Check ((ReadValue 'Run' 'TaskbarControl') -eq ('"'+$install+'\TaskbarControl.exe" --tray')) 'Startup command quotes the chosen path and starts quietly in the tray'
 $prefs=Get-Content -LiteralPath $config -Raw | ConvertFrom-Json
 Check ($prefs.StartupEnabled -eq $true) 'The installer enables the saved in-app startup toggle'
 Check ($prefs.Apps.Count -eq 1 -and $prefs.Apps[0].Show -eq $false -and $prefs.ThemeMode -eq 'light') 'Existing app rules and theme survive installation'
 $shell=New-Object -ComObject WScript.Shell
 $localUninstall=Join-Path $install 'Uninstall Taskbar Control.lnk'
 Check ((Test-Path -LiteralPath (Join-Path $install 'Uninstaller.exe')) -and $shell.CreateShortcut($localUninstall).TargetPath -eq (Join-Path $install 'Uninstaller.exe')) 'The installed folder has Uninstaller.exe and a working uninstall shortcut'
 Check ((Test-Path -LiteralPath (Join-Path $install 'README.txt')) -and (Get-Content -LiteralPath (Join-Path $install 'README.txt') -Raw).Contains('ADDING APPS')) 'The installed folder includes the plain-text controls guide'
 $retired=@('README.md','VALIDATION.md','SHA256SUMS.txt')
 foreach($name in $retired){Check (-not (Test-Path -LiteralPath (Join-Path $install $name))) ('Fresh installation excludes '+$name)}
 Check ((Get-Content -LiteralPath (Join-Path $install 'Estimated System Resource Use.txt') -Raw).Contains('41 MB')) 'The resource note includes the measured memory baseline'
 Check (-not (Select-String -LiteralPath (Join-Path $install 'START HERE.txt'),(Join-Path $install 'README.txt') -Pattern 'portable ZIP|README\.md' -Quiet)) 'Customer instructions have no portable ZIP or duplicate README references'
 $changelog=Get-Content -LiteralPath (Join-Path $install 'CHANGELOG.md') -Raw
 $shortVersion=([version]$expectedFileVersion).ToString(2)
 Check ($changelog.Contains('## '+$expectedVersion) -or (([version]$expectedFileVersion).Build -eq 0 -and $changelog -match ('(?m)^## '+[regex]::Escape($shortVersion)+'\s*$'))) 'The changelog describes the current public update'
 $desktop=Join-Path $install 'TestShortcuts\Desktop.lnk'
 $menu=Join-Path $install 'TestShortcuts\StartMenu\Taskbar Control.lnk'
 Check ((Test-Path -LiteralPath $desktop) -and $shell.CreateShortcut($desktop).TargetPath -eq (Join-Path $install 'TaskbarControl.exe')) 'Desktop shortcut points to the chosen directory'
 Check ((Test-Path -LiteralPath $menu) -and $shell.CreateShortcut($menu).TargetPath -eq (Join-Path $install 'TaskbarControl.exe')) 'Start menu shortcut points to the chosen directory'
 Check (Test-Path -LiteralPath (Join-Path $install 'TestShortcuts\StartMenu\Uninstall Taskbar Control.lnk')) 'Start menu includes the uninstaller shortcut'
 Copy-Item -LiteralPath (Join-Path $install 'Uninstaller.exe') -Destination (Join-Path $install 'Uninstall.exe')
 foreach($name in $retired){[IO.File]::WriteAllText((Join-Path $install $name),'Legacy installed document')}
 RunSetup '/STARTUP=0 /DESKTOP=0 /STARTMENU=0'
 foreach($name in $retired){Check (-not (Test-Path -LiteralPath (Join-Path $install $name))) ('Updating the registered folder removes legacy '+$name)}
 Check (-not (Test-Path -LiteralPath (Join-Path $install 'Uninstall.exe'))) 'Upgrading a registered folder removes the old uninstaller filename'
 Check (Test-Path -LiteralPath $localUninstall) 'The local uninstall shortcut stays available when optional shortcuts are disabled'
 Check ($null -eq (ReadValue 'Run' 'TaskbarControl')) 'Unchecked startup removes the startup registration'
 Check ((Get-Content -LiteralPath $config -Raw | ConvertFrom-Json).StartupEnabled -eq $false) 'Unchecked startup also updates the app preference'
 Check (-not (Test-Path -LiteralPath $desktop) -and -not (Test-Path -LiteralPath $menu)) 'Unchecked shortcut options do not leave previous shortcuts behind'
 $beforeUpdate=(Get-FileHash -LiteralPath $config).Hash
 RunSetup '/UPDATE=1'
 Check ((Get-FileHash -LiteralPath $config).Hash -eq $beforeUpdate) 'Updater leaves the entire configuration file byte-for-byte unchanged'
 Check ($null -eq (ReadValue 'Run' 'TaskbarControl')) 'Updater preserves startup disabled'
 Check (-not (Test-Path -LiteralPath $desktop) -and -not (Test-Path -LiteralPath $menu)) 'Updater preserves disabled shortcut options'
 RunSetup '/STARTUP=1 /DESKTOP=1 /STARTMENU=1'
 Check ((Get-Content -LiteralPath $config -Raw | ConvertFrom-Json).Apps[0].Show -eq $false) 'Repeated installation keeps existing rules'
 $beforeUpdate=(Get-FileHash -LiteralPath $config).Hash
 RunSetup '/UPDATE=1'
 Check ((Get-FileHash -LiteralPath $config).Hash -eq $beforeUpdate) 'Updater preserves settings with startup enabled too'
 Check ((ReadValue 'Run' 'TaskbarControl') -eq ('"'+$install+'\TaskbarControl.exe" --tray')) 'Updater preserves startup enabled'
 Check ((Test-Path -LiteralPath $desktop) -and (Test-Path -LiteralPath $menu)) 'Updater preserves existing desktop and Start menu shortcuts'
 $moved=Join-Path $testRoot 'Moved uninstaller.exe';Copy-Item -LiteralPath (Join-Path $install 'Uninstaller.exe') -Destination $moved
 $p=Start-Process -FilePath $moved -ArgumentList '/S' -WindowStyle Hidden -Wait -PassThru
 Start-Sleep -Milliseconds 300
 Check (Test-Path -LiteralPath (Join-Path $install 'TaskbarControl.exe')) 'A moved uninstaller does not remove the registered app'
 [IO.File]::WriteAllText((Join-Path $install 'keep-me.txt'),'Unrelated user file')
 Uninstall
 Check (-not (Test-Path -LiteralPath (Join-Path $install 'TaskbarControl.exe'))) 'Uninstall removes the installed application'
 Check (-not (Test-Path -LiteralPath (Join-Path $install 'Uninstaller.exe'))) 'Uninstall removes its own executable'
 Check (-not (Test-Path -LiteralPath $localUninstall) -and -not (Test-Path -LiteralPath (Join-Path $install 'README.txt'))) 'Uninstall removes its local shortcut and installed guide'
 Check (-not (Test-Path -LiteralPath (Join-Path $install 'Estimated System Resource Use.txt'))) 'Uninstall removes the resource note'
 Check ($null -eq (ReadValue 'Uninstall' 'DisplayName') -and $null -eq (ReadValue 'Install' 'InstallLocation')) 'Uninstall removes its installation registration'
 Check ($null -eq (ReadValue 'Run' 'TaskbarControl')) 'Uninstall removes startup for this installation'
 Check (-not (Test-Path -LiteralPath $desktop) -and -not (Test-Path -LiteralPath $menu)) 'Uninstall removes its shortcuts'
 Check ((Get-Content -LiteralPath (Join-Path $install 'keep-me.txt') -Raw) -eq 'Unrelated user file') 'Uninstall preserves unrelated files in the chosen folder'
 Check ((Get-Content -LiteralPath $config -Raw | ConvertFrom-Json).Apps.Count -eq 1) 'Uninstall preserves saved app rules'
 $results.Add('PASS: Completed. A separately compiled fixture uses a file-backed registration double and workspace-only shortcuts/settings. Real HKCU writes are denied by the sandbox and were not integration-tested. No live installation or user startup entry was changed.')
} catch {$results.Add('FAIL: '+$_);throw} finally {
 [IO.File]::WriteAllLines((Join-Path $testRoot 'installer-results.txt'),$results)
 $results | Write-Output
}
