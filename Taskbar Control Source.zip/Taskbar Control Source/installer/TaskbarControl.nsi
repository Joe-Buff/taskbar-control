Unicode true
ManifestDPIAware true
RequestExecutionLevel user
SetCompressor /SOLID zlib
!include "MUI2.nsh"
!include "LogicLib.nsh"
!include "FileFunc.nsh"
!include "Sections.nsh"
!include "x64.nsh"
!include "WinVer.nsh"

; Test builds use an INI registration double because the sandbox denies HKCU
; writes. Production uses the real per-user registry with the same keys/values.
!macro StoreString KEY NAME VALUE
  !ifdef TEST_MODE
    WriteINIStr "${TEST_CONFIG}.registration.ini" "${KEY}" "${NAME}" "${VALUE}"
  !else
    WriteRegStr HKCU "${KEY}" "${NAME}" "${VALUE}"
  !endif
!macroend
!macro StoreNumber KEY NAME VALUE
  !ifdef TEST_MODE
    WriteINIStr "${TEST_CONFIG}.registration.ini" "${KEY}" "${NAME}" "${VALUE}"
  !else
    WriteRegDWORD HKCU "${KEY}" "${NAME}" ${VALUE}
  !endif
!macroend
!macro ReadSetting OUTPUT KEY NAME
  !ifdef TEST_MODE
    ReadINIStr ${OUTPUT} "${TEST_CONFIG}.registration.ini" "${KEY}" "${NAME}"
  !else
    ReadRegStr ${OUTPUT} HKCU "${KEY}" "${NAME}"
  !endif
!macroend
!macro RemoveSetting KEY NAME
  !ifdef TEST_MODE
    DeleteINIStr "${TEST_CONFIG}.registration.ini" "${KEY}" "${NAME}"
  !else
    DeleteRegValue HKCU "${KEY}" "${NAME}"
  !endif
!macroend
!macro RemoveGroup KEY
  !ifdef TEST_MODE
    DeleteINISec "${TEST_CONFIG}.registration.ini" "${KEY}"
  !else
    DeleteRegKey HKCU "${KEY}"
  !endif
!macroend

!ifndef PAYLOAD
  !error "Define PAYLOAD as the clean customer package folder."
!endif
!ifndef OUTPUT
  !define OUTPUT "Taskbar Control Setup.exe"
!endif
!ifdef TEST_MODE
  !define INSTALLKEY "Software\TaskbarControlInstallerTests\${TEST_MODE}\Install"
  !define UNINSTALLKEY "Software\TaskbarControlInstallerTests\${TEST_MODE}\Uninstall"
  !define RUNKEY "Software\TaskbarControlInstallerTests\${TEST_MODE}\Run"
!else
  !define INSTALLKEY "Software\TaskbarControl\Installation"
  !define UNINSTALLKEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\TaskbarControl"
  !define RUNKEY "Software\Microsoft\Windows\CurrentVersion\Run"
!endif
Name "Taskbar Control"
OutFile "${OUTPUT}"
InstallDir "$LOCALAPPDATA\Programs\Taskbar Control"
InstallDirRegKey HKCU "${INSTALLKEY}" "InstallLocation"
BrandingText "Taskbar Control"
VIProductVersion "1.10.0.0"
VIAddVersionKey /LANG=1033 "ProductName" "Taskbar Control"
VIAddVersionKey /LANG=1033 "FileDescription" "Taskbar Control installer"
VIAddVersionKey /LANG=1033 "FileVersion" "1.10.0"
VIAddVersionKey /LANG=1033 "LegalCopyright" ""
!define MUI_ICON "..\source\TaskbarControl.ico"
!define MUI_UNICON "..\source\TaskbarControl.ico"
!define MUI_ABORTWARNING
!define MUI_WELCOMEPAGE_TITLE "Install Taskbar Control"
!define MUI_WELCOMEPAGE_TEXT "Choose where Taskbar Control is installed and how you want to open it.$\r$\n$\r$\nYour existing app rules and preferences will be kept."
!define MUI_COMPONENTSPAGE_TEXT_TOP "Choose startup and shortcut options. You can still change Start with Windows inside the app."
!define MUI_COMPONENTSPAGE_TEXT_COMPLIST "Options:"
!define MUI_DIRECTORYPAGE_TEXT_TOP "Choose a folder you can write to. Taskbar Control is installed for your Windows account."
!define MUI_FINISHPAGE_RUN "$INSTDIR\TaskbarControl.exe"
!define MUI_FINISHPAGE_RUN_TEXT "Open Taskbar Control"
!define MUI_UNCONFIRMPAGE_TEXT_TOP "Taskbar Control will close and restore its hidden taskbar buttons. Its installed files and shortcuts will be removed. Your saved rules are kept for future use."
!insertmacro MUI_PAGE_WELCOME
!define MUI_PAGE_CUSTOMFUNCTION_PRE SkipUpdatePage
!insertmacro MUI_PAGE_COMPONENTS
!define MUI_PAGE_CUSTOMFUNCTION_PRE SkipUpdatePage
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_UNPAGE_FINISH
!insertmacro MUI_LANGUAGE "English"

Var DesktopLink
Var MenuFolder
Var Parameters
Var UpdateMode

Section "Taskbar Control (required)" SecCore
  SectionIn RO
  Call ValidateDirectory
  !ifndef TEST_MODE
    ExecWait '"$PLUGINSDIR\TaskbarControl.exe" --exit-for-setup' $0
    Call EnsureClosed
  !endif
  SetOutPath "$INSTDIR"
  File "${PAYLOAD}\TaskbarControl.exe"
  File "${PAYLOAD}\README.txt"
  File "${PAYLOAD}\START HERE.txt"
  File "${PAYLOAD}\CHANGELOG.md"
  File "${PAYLOAD}\PRIVACY.md"
  File "${PAYLOAD}\Estimated System Resource Use.txt"
  ClearErrors
  WriteUninstaller "$INSTDIR\Uninstaller.exe"
  CreateShortcut "$INSTDIR\Uninstall Taskbar Control.lnk" "$INSTDIR\Uninstaller.exe"
  IfErrors 0 +4
    MessageBox MB_OK|MB_ICONSTOP "The uninstaller or its shortcut could not be created. Check access to the selected folder, then run setup again." /SD IDOK
    SetErrorLevel 5
    Abort
  ; Remove retired release files only when upgrading this registered folder.
  !insertmacro ReadSetting $0 "${INSTALLKEY}" "InstallLocation"
  ${If} $0 == $INSTDIR
    Delete "$INSTDIR\Uninstall.exe"
    Delete "$INSTDIR\README.md"
    Delete "$INSTDIR\VALIDATION.md"
    Delete "$INSTDIR\SHA256SUMS.txt"
  ${EndIf}
  ClearErrors
  !insertmacro StoreString "${INSTALLKEY}" "InstallLocation" "$INSTDIR"
  !insertmacro StoreString "${UNINSTALLKEY}" "DisplayName" "Taskbar Control"
  !insertmacro StoreString "${UNINSTALLKEY}" "DisplayVersion" "1.10.0"
  !insertmacro StoreString "${UNINSTALLKEY}" "InstallLocation" "$INSTDIR"
  !insertmacro StoreString "${UNINSTALLKEY}" "DisplayIcon" "$INSTDIR\TaskbarControl.exe,0"
  !insertmacro StoreString "${UNINSTALLKEY}" "UninstallString" '$\"$INSTDIR\Uninstaller.exe$\"'
  !insertmacro StoreString "${UNINSTALLKEY}" "QuietUninstallString" '$\"$INSTDIR\Uninstaller.exe$\" /S'
  !insertmacro StoreNumber "${UNINSTALLKEY}" "NoModify" 1
  !insertmacro StoreNumber "${UNINSTALLKEY}" "NoRepair" 1
  !insertmacro StoreNumber "${UNINSTALLKEY}" "EstimatedSize" 1600
  IfErrors 0 +4
    MessageBox MB_OK|MB_ICONSTOP "Windows did not allow setup to register the installation. Check your account permissions, then run setup again." /SD IDOK
    SetErrorLevel 5
    Abort
SectionEnd

Section "Start with Windows" SecStartup
SectionEnd
Section "Create a desktop shortcut" SecDesktop
SectionEnd
Section "Create a Start menu shortcut" SecStartMenu
SectionEnd

Section -Configure
  Call ShortcutLocations
  ${If} ${SectionIsSelected} ${SecStartup}
    StrCpy $1 "on"
  ${Else}
    StrCpy $1 "off"
  ${EndIf}
  StrCpy $0 0
  ; In-place updates must not rewrite the settings file at all.
  ${If} $UpdateMode != "1"
    !ifdef TEST_MODE
      ExecWait '"$INSTDIR\TaskbarControl.exe" --setup-test-preference "${TEST_CONFIG}" $1' $0
    !else
      ExecWait '"$INSTDIR\TaskbarControl.exe" --setup-startup-preference $1' $0
    !endif
  ${EndIf}
  ${If} $0 != 0
    MessageBox MB_OK|MB_ICONSTOP "Your saved preferences could not be updated. They have been preserved. Check access to your local app-data folder, then run setup again." /SD IDOK
    SetErrorLevel 3
    Abort
  ${EndIf}
  ${If} $1 == "on"
    ClearErrors
    !insertmacro StoreString "${RUNKEY}" "TaskbarControl" '$\"$INSTDIR\TaskbarControl.exe$\" --tray'
    IfErrors 0 +4
      MessageBox MB_OK|MB_ICONSTOP "Windows did not allow setup to enable startup. You can retry setup or enable Start with Windows inside the app." /SD IDOK
      SetErrorLevel 5
      Abort
  ${Else}
    !insertmacro RemoveSetting "${RUNKEY}" "TaskbarControl"
  ${EndIf}
  ClearErrors
  ${If} ${SectionIsSelected} ${SecDesktop}
    !ifdef TEST_MODE
      CreateDirectory "$INSTDIR\TestShortcuts"
    !endif
    CreateShortcut "$DesktopLink" "$INSTDIR\TaskbarControl.exe" "" "$INSTDIR\TaskbarControl.exe" 0
  ${Else}
    Delete "$DesktopLink"
    ClearErrors
  ${EndIf}
  ${If} ${SectionIsSelected} ${SecStartMenu}
    CreateDirectory "$MenuFolder"
    CreateShortcut "$MenuFolder\Taskbar Control.lnk" "$INSTDIR\TaskbarControl.exe" "" "$INSTDIR\TaskbarControl.exe" 0
    CreateShortcut "$MenuFolder\Uninstall Taskbar Control.lnk" "$INSTDIR\Uninstaller.exe"
  ${Else}
    Delete "$MenuFolder\Taskbar Control.lnk"
    Delete "$MenuFolder\Uninstall Taskbar Control.lnk"
    RMDir "$MenuFolder"
    ClearErrors
  ${EndIf}
  IfErrors 0 +4
    MessageBox MB_OK|MB_ICONEXCLAMATION "A shortcut could not be created. Taskbar Control is installed; you can open it from the install folder or rerun setup." /SD IDOK
    SetErrorLevel 4
    Abort
SectionEnd

!insertmacro MUI_FUNCTION_DESCRIPTION_BEGIN
  !insertmacro MUI_DESCRIPTION_TEXT ${SecCore} "The standalone app, help files, and uninstaller. Existing rules are preserved."
  !insertmacro MUI_DESCRIPTION_TEXT ${SecStartup} "Start quietly in the tray when you sign in. The app's Start with Windows toggle will match this choice."
  !insertmacro MUI_DESCRIPTION_TEXT ${SecDesktop} "Put an app shortcut on your desktop. Opening it again focuses the running app."
  !insertmacro MUI_DESCRIPTION_TEXT ${SecStartMenu} "Add Taskbar Control and its uninstaller to your Start menu."
!insertmacro MUI_FUNCTION_DESCRIPTION_END

Function .onInit
  SetRegView 64
  SetShellVarContext current
  ${GetParameters} $Parameters
  ${GetOptions} $Parameters "/UPDATE=" $UpdateMode
  ${IfNot} ${RunningX64}
    MessageBox MB_OK|MB_ICONSTOP "Taskbar Control requires Windows 11 x64." /SD IDOK
    SetErrorLevel 1
    Abort
  ${EndIf}
  ${IfNot} ${AtLeastWin11}
    MessageBox MB_OK|MB_ICONSTOP "Taskbar Control requires Windows 11." /SD IDOK
    SetErrorLevel 1
    Abort
  ${EndIf}
  !ifndef TEST_MODE
    InitPluginsDir
    SetOutPath "$PLUGINSDIR"
    File /oname=TaskbarControl.exe "${PAYLOAD}\TaskbarControl.exe"
    ExecWait '"$PLUGINSDIR\TaskbarControl.exe" --setup-startup-query' $0
    ${If} $0 == 10
      !insertmacro UnselectSection ${SecStartup}
    ${EndIf}
  !endif
  ; Preserve actual shortcut choices during upgrades (including deletions).
  !insertmacro ReadSetting $0 "${INSTALLKEY}" "InstallLocation"
  ${If} $0 != ""
    Call ShortcutLocations
    ${IfNot} ${FileExists} "$DesktopLink"
      !insertmacro UnselectSection ${SecDesktop}
    ${EndIf}
    ${IfNot} ${FileExists} "$MenuFolder\Taskbar Control.lnk"
      !insertmacro UnselectSection ${SecStartMenu}
    ${EndIf}
  ${EndIf}
  ${If} $UpdateMode == "1"
    !insertmacro ReadSetting $0 "${RUNKEY}" "TaskbarControl"
    ${If} $0 == ""
      !insertmacro UnselectSection ${SecStartup}
    ${Else}
      !insertmacro SelectSection ${SecStartup}
    ${EndIf}
    Return
  ${EndIf}
  ${GetOptions} $Parameters "/STARTUP=" $0
  ${If} $0 == "0"
    !insertmacro UnselectSection ${SecStartup}
  ${ElseIf} $0 == "1"
    !insertmacro SelectSection ${SecStartup}
  ${EndIf}
  ${GetOptions} $Parameters "/DESKTOP=" $0
  ${If} $0 == "0"
    !insertmacro UnselectSection ${SecDesktop}
  ${ElseIf} $0 == "1"
    !insertmacro SelectSection ${SecDesktop}
  ${EndIf}
  ${GetOptions} $Parameters "/STARTMENU=" $0
  ${If} $0 == "0"
    !insertmacro UnselectSection ${SecStartMenu}
  ${ElseIf} $0 == "1"
    !insertmacro SelectSection ${SecStartMenu}
  ${EndIf}
FunctionEnd

Function SkipUpdatePage
  ${If} $UpdateMode == "1"
    Abort
  ${EndIf}
FunctionEnd

Function ValidateDirectory
  ${GetRoot} "$INSTDIR" $0
  ${If} $INSTDIR == $0
  ${OrIf} $INSTDIR == "$0\"
  ${OrIf} $INSTDIR == "$WINDIR"
  ${OrIf} $INSTDIR == "$SYSDIR"
    MessageBox MB_OK|MB_ICONSTOP "Choose a dedicated Taskbar Control folder, not a drive root or Windows system folder." /SD IDOK
    SetErrorLevel 2
    Abort
  ${EndIf}
FunctionEnd

!macro ShortcutPaths PREFIX
Function ${PREFIX}ShortcutLocations
  !ifdef TEST_MODE
    StrCpy $DesktopLink "$INSTDIR\TestShortcuts\Desktop.lnk"
    StrCpy $MenuFolder "$INSTDIR\TestShortcuts\StartMenu"
  !else
    StrCpy $DesktopLink "$DESKTOP\Taskbar Control.lnk"
    StrCpy $MenuFolder "$SMPROGRAMS\Taskbar Control"
  !endif
FunctionEnd
!macroend
!insertmacro ShortcutPaths ""
!insertmacro ShortcutPaths "un."

!macro WaitForExit PREFIX
Function ${PREFIX}EnsureClosed
  StrCpy $1 0
  check:
    System::Call 'kernel32::OpenMutexW(i 0x100000, i 0, w "Local\TaskbarControl.Utility.1") p .r0'
    ${If} $0 == 0
      Return
    ${EndIf}
    System::Call 'kernel32::CloseHandle(p r0)'
    IntOp $1 $1 + 1
    ${If} $1 < 20
      Sleep 250
      Goto check
    ${EndIf}
    MessageBox MB_RETRYCANCEL|MB_ICONINFORMATION "Please choose 'Exit and restore taskbar buttons' from Taskbar Control's tray menu, then click Retry. Setup will not force-close it." /SD IDCANCEL IDRETRY check
    SetErrorLevel 2
    Abort
FunctionEnd
!macroend
!ifndef TEST_MODE
  !insertmacro WaitForExit ""
  !insertmacro WaitForExit "un."
!endif

Function un.onInit
  SetRegView 64
  SetShellVarContext current
  !insertmacro ReadSetting $0 "${INSTALLKEY}" "InstallLocation"
  ${If} $0 != $INSTDIR
    MessageBox MB_OK|MB_ICONSTOP "This uninstaller is not in the registered installation folder. Run the uninstaller from the current Taskbar Control folder." /SD IDOK
    SetErrorLevel 2
    Abort
  ${EndIf}
FunctionEnd

Section "Uninstall"
  !ifndef TEST_MODE
    IfFileExists "$INSTDIR\TaskbarControl.exe" 0 +2
      ExecWait '"$INSTDIR\TaskbarControl.exe" --exit-for-setup' $0
    Call un.EnsureClosed
  !endif
  Call un.ShortcutLocations
  !insertmacro ReadSetting $0 "${RUNKEY}" "TaskbarControl"
  ${If} $0 == '$\"$INSTDIR\TaskbarControl.exe$\" --tray'
    !insertmacro RemoveSetting "${RUNKEY}" "TaskbarControl"
  ${EndIf}
  Delete "$DesktopLink"
  Delete "$MenuFolder\Taskbar Control.lnk"
  Delete "$MenuFolder\Uninstall Taskbar Control.lnk"
  RMDir "$MenuFolder"
  !ifdef TEST_MODE
    RMDir "$INSTDIR\TestShortcuts"
  !endif
  ; Only known installed files are removed. Never recursively delete the folder.
  Delete "$INSTDIR\TaskbarControl.exe"
  Delete "$INSTDIR\README.md"
  Delete "$INSTDIR\README.txt"
  Delete "$INSTDIR\START HERE.txt"
  Delete "$INSTDIR\CHANGELOG.md"
  Delete "$INSTDIR\PRIVACY.md"
  Delete "$INSTDIR\VALIDATION.md"
  Delete "$INSTDIR\Estimated System Resource Use.txt"
  Delete "$INSTDIR\SHA256SUMS.txt"
  Delete "$INSTDIR\Uninstaller.exe"
  Delete "$INSTDIR\Uninstall Taskbar Control.lnk"
  RMDir "$INSTDIR"
  !insertmacro RemoveGroup "${INSTALLKEY}"
  !insertmacro RemoveGroup "${UNINSTALLKEY}"
SectionEnd
