# Privacy

Taskbar Control runs on your PC. Your app rules, settings, and diagnostics stay local. There are no accounts, analytics, telemetry, or uploads of your personal data.

Update checks happen only when you press **Check for updates** in Settings. The app contacts the public GitHub releases API for Joe-Buff/taskbar-control. It downloads an installer from GitHub only after you choose **Download and install**. These requests include normal connection information, such as your IP address, and the Taskbar Control version. They do not include your app list, rules, saved folders, or personal files. There are no automatic update checks.

On some Windows builds, the app downloads public compatibility data from Microsoft's symbol server. That request includes the Windows taskbar build identifier and normal connection information. It does not send your rules, app list, or personal files. Compatibility data is cached locally. This existing Windows-compatibility download is separate from the manual update checker.

Settings are stored in %LOCALAPPDATA%\TaskbarControl. Downloaded update installers are stored in a temporary folder. Diagnostics stay local unless you choose to copy or share them yourself.