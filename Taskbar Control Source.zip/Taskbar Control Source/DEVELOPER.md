# Taskbar Control 1.10 - source and build guide

This package contains the C# application, C++ taskbar helper, prebuilt native helper, icons, installer source, packaging scripts, and tests. Public release changes are summarized in CHANGELOG.md. No saved user configuration is included.

The public release is 1.10; the internal assembly and installer version is 1.10.0.0. Use GitHub tag v1.10 and release title Version 1.10.

## Build on Windows 11 x64

Open PowerShell in this extracted folder and run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\source\build.ps1 -UseExistingNative
```

This uses the .NET Framework compiler included with Windows and the included TaskbarVisual.dll. It produces TaskbarControl.exe in this folder. UI-only builds do not require Visual Studio or package downloads. SHA256SUMS.txt records the included files' hashes.

To rebuild the native helper, use a Clang/MinGW C++23 toolchain with C++/WinRT headers and Windows import libraries:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\source\build.ps1 -CppCompiler <path-to-clang++.exe>
```

The native DLL is embedded in TaskbarControl.exe and extracted to a content-hashed per-user cache at runtime.

## Build the installer and source ZIP

Install the NSIS Unicode compiler, then run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\source\package.ps1 -SkipBuild -Destination .\release -InstallerCompiler "C:\Program Files (x86)\NSIS\makensis.exe"
```

Use an empty destination. Packaging uses explicit file allowlists, privacy scans, and SHA-256 manifests. The source ZIP is for inspection and development; customers only need the installer. See installer/README.md for setup options and compiler details.

## Publish an update

1. Keep source/AssemblyInfo.cs, source/app.manifest, and installer/TaskbarControl.nsi version values in sync.
2. Summarize changes since the previous public release in CHANGELOG.md, then rebuild and verify the release. Preserve the settings schema and local app-data location.
3. Create a stable GitHub release at https://github.com/Joe-Buff/taskbar-control using a versioned tag and title.
4. Attach exactly one installer named Taskbar.Control.Setup.exe or Taskbar Control Setup.exe. The updater requires the SHA-256 digest supplied in GitHub's asset metadata.
5. Attach the source ZIP separately if desired. Exclude user settings, diagnostics, test outputs, and signing credentials.

Version 1.0 users install the current release manually to gain the update checker.

## Update behavior

Update checks run only from Settings > Check for updates. A confirmation precedes download. Requests are HTTPS-only and restricted to the configured repository and GitHub asset hosts. Downloads are bounded and checked against asset size and SHA-256 before installation. Release-title parsing supports version names when a tag is not a version number.

Setup receives /UPDATE=1 and /D=<the running app directory>. Update mode preserves startup and shortcut choices and does not write settings.json. It requests normal exit, waits for the app to close, then replaces installed files. It does not uninstall first. The finish page can reopen the app.

Checksums verify integrity against the release repository; they are not code-signing certificates. Publishers may sign the application and installer with their own certificate before uploading them.

## Verification tools and scope

Run the EXE with one switch and an output directory:

- --core-test: app identity, simulated taskbar engine, and isolated bridge protocol checks.
- --update-test: local release parsing, version comparison, asset validation, and checksum checks; no network.
- --dashboard-test: offscreen UI checks with an inactive taskbar backend. Covers themes, scrolling, whole-row visibility, resizing, sidebar bounds, search, and error reporting.
- --update-network-test: requests the GitHub release, downloads and verifies its installer, then deletes the download without running it. Requires working network/TLS access.
- --benchmark: measures an empty-rule UI/tray session.

The --self-test, --picker-test, --lifecycle-test, and --ui-preview tools can show windows or send test input. Run them on a dedicated test desktop. Compile VisualNativeTests.cpp with the native dependencies and -municode for native protocol and optional symbol-resolution tests.

Installer tests use workspace-only files and an INI-backed registry substitute. These tests do not verify production HKCU writes or Windows sign-in startup. Offscreen and simulated tests also do not establish live taskbar compatibility, every display/DPI combination, or end-to-end network installation. Verify those behaviors separately on the Windows configurations being supported.

## Taskbar integration

A short-lived, thread-specific Windows hook attaches the embedded DLL to Explorer. On the taskbar UI thread, it applies reversible local Visibility overrides to exact shell app identities. Rule expiry restores visuals and stops callbacks/timers. The DLL stays pinned until Explorer exits to avoid unloading code Windows/XAML may still reference. No permanent hook registry entries are installed.

Private Windows taskbar interfaces are build-dependent. Verify taskbar hiding, Alt+Tab, pause/resume, and exit restoration before publishing. Do not substitute a hiding method that removes windows from Alt+Tab. Diagnostic tools must not use the production bridge mapping.

Compatibility offsets are Windows build metadata verified against matching Microsoft symbols. They are not saved user configuration. Public compatibility data can be downloaded from Microsoft's symbol server and cached locally, as described in PRIVACY.md.

## Window lifecycle and interface

A named mutex enforces one instance. A message-only activation receiver survives main-window handle recreation and queues early requests. A second process grants foreground permission to the receiving process, requests activation, then exits. A duplicate --tray launch exits without opening the editor. Windows can still restrict foreground activation when launching was not user-initiated.

Minimize and close-to-tray preserve active rules. Reopening restores normal window placement while retaining modal-dialog behavior.

The app list reserves leftover vertical space below the viewport so only complete rows are painted and clickable. The grid and themed scrollbar share bounds. Sidebar navigation uses a percentage-sized column so collapsed controls remain within the sidebar. The log remains selectable read-only text.

## Error reporting

The footer preview and Activity notification are event-driven. The in-memory log holds up to 50 entries and excludes progress messages. Consecutive identical errors share an entry with a repeat count and latest timestamp. Clearing Activity also clears the preview.

Copied reports include the app/Windows versions, diagnostic category, suggested next step, original error codes, and available technical details. Reports are locally redacted. Diagnostic codes identify categories rather than guaranteed root causes.

| Code | Meaning |
| --- | --- |
| AE0001 | Required app, file, or folder missing |
| AE0002 | Access denied |
| AE0003 | Unsupported Windows taskbar version/layout |
| AE0004 | Taskbar button identity unavailable |
| AE0005 | Timeout |
| AE0006 | File in use |
| AE0007 | Settings could not be saved |
| AE0008 | Startup setting could not be changed |
| AE0009 | Compatibility information download failed |
| AE0010 | Folder scan failed |
| AE0011 | Shared Windows host rule |
| AE0012 | Taskbar operation/helper connection failed |
| AE0013 | Window picker could not start |
| AE0014 | Update check/download/launch failed |
| AE9999 | Unrecognized failure; consult original details |
